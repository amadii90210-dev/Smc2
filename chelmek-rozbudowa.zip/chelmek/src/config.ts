export const WORLD = {
  x0: -2600,
  x1: 2800,
  z0: -4140,
  z1: 4200,
};

// Exact WGS84 anchor for (0, 0) in Chełmek (32-660)
export const GPS_ORIGIN = {
  lat: 50.1003348,
  lon: 19.2542585,
  mPerLat: 111132,
  mPerLon: 71414,
};

export function xzToGps(x: number, z: number): { lat: number; lon: number } {
  return {
    lat: GPS_ORIGIN.lat - z / GPS_ORIGIN.mPerLat,
    lon: GPS_ORIGIN.lon + x / GPS_ORIGIN.mPerLon,
  };
}

export function gpsToXz(lat: number, lon: number): { x: number; z: number } {
  return {
    x: (lon - GPS_ORIGIN.lon) * GPS_ORIGIN.mPerLon,
    z: -(lat - GPS_ORIGIN.lat) * GPS_ORIGIN.mPerLat,
  };
}

export interface TeleportSpot {
  id: string;
  name: string;
  sub: string;
  x: number;
  z: number;
  yaw?: number;
}

export const TELEPORT_SPOTS: TeleportSpot[] = [
  {
    id: "centrum",
    name: "Centrum Chełmka & PKP",
    sub: "ul. Krakowska / Stacja Kolejowa",
    x: -18,
    z: 48,
    yaw: 0.4,
  },
  {
    id: "skala",
    name: "Wzgórze Skała (293 m)",
    sub: "Wieża widokowa rtm. W. Pileckiego",
    x: -1042,
    z: 56,
    yaw: -0.8,
  },
  {
    id: "bata",
    name: "Kolonia Fabryczna Bata",
    sub: "Zabytkowe osiedle, kawiarnie i park",
    x: -165,
    z: -42,
    yaw: 1.5,
  },
  {
    id: "moksir",
    name: "Park Rodzinny & MOKSiR",
    sub: "Place zabaw, korty i Urząd Miejski",
    x: 375,
    z: -195,
    yaw: 3.1,
  },
  {
    id: "stawy",
    name: "Stawy & Fabry Kafka",
    sub: "Staw Oko / Koło, ogródek nad wodą",
    x: -18,
    z: -955,
    yaw: 2.8,
  },
  {
    id: "most",
    name: "Most Galicyjski (Przemsza)",
    sub: "Rzeka Przemsza / granica z Chełmem Małym",
    x: -2010,
    z: 272,
    yaw: -1.3,
  },
  {
    id: "nowopole",
    name: "Nowopole & Paprotnik",
    sub: "Wschodnia część miasta, sklepy i osiedla",
    x: 685,
    z: 28,
    yaw: -1.5,
  },
  {
    id: "gorzow_centrum",
    name: "Sołectwo Gorzów — Centrum",
    sub: "ul. Oświęcimska / Kościół w Gorzowie",
    x: -1480,
    z: 2260,
    yaw: 0.2,
  },
  {
    id: "gorzow_pkp",
    name: "PKP Gorzów Chrzanowski",
    sub: "Przejazd kolejowy i nasyp linii nr 93",
    x: -480,
    z: 2150,
    yaw: 2.4,
  },
  {
    id: "bobrek_centrum",
    name: "Sołectwo Bobrek — Centrum",
    sub: "Południowo-wschodnia część gminy Chełmek",
    x: -290,
    z: 3780,
    yaw: 1.1,
  },
  {
    id: "bobrek_park",
    name: "Bobrek — Park Zamkowy & Pałac",
    sub: "Zabytkowy zespół pałacowo-parkowy",
    x: 240,
    z: 3420,
    yaw: -0.6,
  },
  {
    id: "dzieckowice",
    name: "Zbiornik Dziećkowice (Północ)",
    sub: "Przystań Yacht Club Opty i dolina Przemszy",
    x: -2480,
    z: -2860,
    yaw: 1.8,
  },
];
