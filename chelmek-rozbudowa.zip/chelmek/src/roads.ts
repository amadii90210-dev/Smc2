import { resample, segDist, SegGrid, segT } from "./geo";
import { Chunks, MB } from "./mb";
import { SF, Terrain } from "./terrain";
import { L } from "./tex";

const SURF: Record<string, number> = {
  asphalt: L.ASPHALT,
  paved: L.ASPHALT,
  concrete: L.CONCRETE,
  "concrete:plates": L.CONCRETE,
  paving_stones: L.PAVING,
  sett: L.PAVING,
  cobblestone: L.PAVING,
  gravel: L.GRAVEL,
  fine_gravel: L.GRAVEL,
  compacted: L.GRAVEL,
  pebblestone: L.GRAVEL,
  ground: L.DIRT,
  dirt: L.DIRT,
  earth: L.DIRT,
  mud: L.DIRT,
  grass: L.DIRT,
  unpaved: L.DIRT,
  sand: L.DIRT,
  wood: L.PLANKS,
};

const WHITE = [1, 1, 1];
const PAVE = [0.96, 0.95, 0.93];
const BRIDGE_CONC = [0.82, 0.81, 0.78];
const BRIDGE_RAIL = [0.32, 0.42, 0.52];
const BALLAST_TINT = [0.88, 0.85, 0.82];
const STEEL_TINT = [0.76, 0.78, 0.82];

export function prepRoads(w: any) {
  const roads: any[] = [];
  for (const r of w.roads) {
    const k = r.k;
    let half = 0,
      layer: number = L.ASPHALT,
      drive = false,
      yoff = 0.08,
      vlen = 4,
      full = false,
      val: number = SF.WALK,
      speed = 5;
    const sl = r.sf !== undefined ? SURF[r.sf] : undefined;
    if (k === "secondary" || k === "primary" || k === "trunk") {
      half = (r.ln && r.ln >= 3 ? 10 : 7) / 2;
      layer = L.ASPHALT_E;
      drive = true;
      yoff = 0.12;
      vlen = 8;
      full = true;
      val = SF.ROAD;
      speed = 14;
    } else if (k === "tertiary") {
      half = 3;
      layer = L.ASPHALT_C;
      drive = true;
      yoff = 0.11;
      vlen = 8;
      full = true;
      val = SF.ROAD;
      speed = 12.5;
    } else if (k === "residential" || k === "unclassified" || k === "living_street") {
      half = 2.5;
      layer = sl ?? L.ASPHALT;
      drive = true;
      yoff = 0.1;
      val = SF.ROAD;
      speed = 9;
    } else if (k === "service") {
      half = r.sv === "driveway" ? 1.4 : r.sv === "parking_aisle" ? 2.3 : 1.7;
      layer = sl ?? L.ASPHALT;
      drive = true;
      yoff = 0.09;
      val = SF.ROAD;
      speed = 5;
    } else if (k === "track") {
      half = 1.4;
      layer = sl ?? L.DIRT;
      drive = true;
      yoff = 0.07;
      val = SF.DIRT;
      speed = 5;
    } else if (k === "pedestrian") {
      half = 2.5;
      layer = sl ?? L.PAVING;
      yoff = 0.085;
    } else if (k === "footway") {
      if (r.ft === "crossing") continue;
      half = (r.w || 1.9) / 2;
      layer = sl ?? L.PAVING;
    } else if (k === "path" || k === "bridleway") {
      half = (r.w || 1.3) / 2;
      layer = sl ?? L.DIRT;
      yoff = 0.07;
      val = SF.DIRT;
    } else if (k === "cycleway") {
      half = 1.2;
      layer = sl ?? L.CYCLE;
      yoff = 0.085;
    } else if (k === "steps") {
      half = 0.9;
      layer = L.STEPS;
      yoff = 0.09;
      vlen = 2.4;
      full = true;
    } else if (k === "platform") {
      half = 1.5;
      layer = L.CONCRETE;
      yoff = 0.45;
    } else if (k === "pier") {
      half = 1.2;
      layer = L.PLANKS;
      yoff = 0.5;
    } else continue;
    if (half < 0.35) half = 0.35;
    if (layer === L.DIRT) {
      full = true;
      vlen = 4;
      if (val === SF.ROAD) val = SF.DIRT;
    }
    const p = resample(r.p, 6);
    const n = p.length / 2;
    if (n < 2) continue;
    const g = 0.9 + 0.2 * (((roads.length * 37) % 10) / 10);
    roads.push({
      id: roads.length,
      p,
      y: new Float32Array(n),
      cum: new Float32Array(n),
      half,
      k,
      name: r.n,
      drive,
      bridge: !!r.br || k === "pier",
      ow: !!r.ow,
      speed: r.ms ? r.ms / 3.6 : speed,
      layer,
      yoff,
      vlen,
      full,
      val,
      tint: [g, g, g],
    });
  }
  const strokes: any[] = [];
  for (const r of roads) if (!r.drive) strokes.push({ p: r.p, half: r.half, val: r.val, bridge: r.bridge });
  for (const l of w.rails) strokes.push({ p: l.p, half: 2.8, val: SF.RAIL, bridge: !!l.br });
  for (const r of roads) if (r.drive) strokes.push({ p: r.p, half: r.half, val: r.val, bridge: r.bridge });
  return {
    roads,
    drive: new SegGrid(48),
    all: new SegGrid(48),
    walk: new SegGrid(48),
    decks: [] as any[],
    deckGrid: new SegGrid(48),
    strokes,
  };
}

function ribbon(
  ch: Chunks,
  p: number[],
  y: Float32Array,
  half: number,
  layer: number,
  tint: number[],
  vlen: number,
  full: boolean,
  t: Terrain | null,
  yoff: number,
  cum: Float32Array
) {
  const n = p.length / 2;
  if (n < 2) return;
  let plx = 0,
    plz = 0,
    prx = 0,
    prz = 0,
    ply = 0,
    pry = 0;
  const u1 = full ? 1 : (2 * half) / 4;
  for (let i = 0; i < n; i++) {
    const x = p[i * 2],
      z = p[i * 2 + 1];
    const ax = i > 0 ? p[i * 2 - 2] : x,
      az = i > 0 ? p[i * 2 - 1] : z,
      bx = i < n - 1 ? p[i * 2 + 2] : x,
      bz = i < n - 1 ? p[i * 2 + 3] : z;
    let tx = bx - ax,
      tz = bz - az;
    const l = Math.hypot(tx, tz) || 1;
    tx /= l;
    tz /= l;
    let s = 1;
    if (i > 0 && i < n - 1) {
      let sx = x - ax,
        sz = z - az;
      const sl = Math.hypot(sx, sz) || 1;
      sx /= sl;
      sz /= sl;
      s = 1 / Math.max(0.5, sx * tx + sz * tz);
    }
    const ox = -tz * half * s,
      oz = tx * half * s;
    const lx = x + ox,
      lz = z + oz,
      rx = x - ox,
      rz = z - oz;
    const ly = t ? t.hu(lx, lz) + yoff : y[i],
      ry = t ? t.hu(rx, rz) + yoff : y[i];
    if (i > 0)
      ch.at((x + ax) / 2, (z + az) / 2).quad(
        plx,
        ply,
        plz,
        prx,
        pry,
        prz,
        rx,
        ry,
        rz,
        lx,
        ly,
        lz,
        0,
        1,
        0,
        0,
        cum[i - 1] / vlen,
        u1,
        cum[i] / vlen,
        layer,
        tint
      );
    plx = lx;
    plz = lz;
    prx = rx;
    prz = rz;
    ply = ly;
    pry = ry;
  }
}

function buildBridgeStructure(
  ch: Chunks,
  p: number[],
  y: Float32Array,
  half: number,
  cum: Float32Array,
  t: Terrain,
  isRail = false
) {
  const n = p.length / 2;
  if (n < 2) return;
  const deckH = isRail ? 0.75 : 0.58;
  const railH = isRail ? 1.15 : 1.05;
  const wOut = half + 0.32;
  for (let i = 1; i < n; i++) {
    const ax = p[(i - 1) * 2],
      az = p[(i - 1) * 2 + 1],
      bx = p[i * 2],
      bz = p[i * 2 + 1];
    const ya = y[i - 1],
      yb = y[i];
    let tx = bx - ax,
      tz = bz - az;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    const nx = -tz,
      nz = tx;
    const mb = ch.at((ax + bx) / 2, (az + bz) / 2);
    const v0 = cum[i - 1] / 3,
      v1 = cum[i] / 3;

    for (const side of [1, -1]) {
      const sx = nx * wOut * side,
        sz = nz * wOut * side;
      // Concrete deck side fascia beam
      mb.quad(
        ax + sx,
        ya - deckH,
        az + sz,
        bx + sx,
        yb - deckH,
        bz + sz,
        bx + sx,
        yb + 0.08,
        bz + sz,
        ax + sx,
        ya + 0.08,
        az + sz,
        nx * side,
        0,
        nz * side,
        0,
        v0,
        0.3,
        v1,
        L.CONCRETE,
        BRIDGE_CONC
      );
      // Bridge safety parapet / steel railing (top & mid rail + posts)
      mb.quad(
        ax + sx,
        ya + railH - 0.12,
        az + sz,
        bx + sx,
        yb + railH - 0.12,
        bz + sz,
        bx + sx,
        yb + railH,
        bz + sz,
        ax + sx,
        ya + railH,
        az + sz,
        nx * side,
        0,
        nz * side,
        0,
        v0,
        0.1,
        v1,
        L.CONCRETE,
        BRIDGE_RAIL
      );
      mb.quad(
        ax + sx,
        ya + railH - 0.12,
        az + sz,
        ax + sx,
        ya + railH,
        az + sz,
        bx + sx,
        yb + railH,
        bz + sz,
        bx + sx,
        yb + railH - 0.12,
        bz + sz,
        -nx * side,
        0,
        -nz * side,
        0,
        v0,
        0.1,
        v1,
        L.CONCRETE,
        BRIDGE_RAIL
      );
      mb.quad(
        ax + sx,
        ya + 0.05,
        az + sz,
        bx + sx,
        yb + 0.05,
        bz + sz,
        bx + sx,
        yb + 0.28,
        bz + sz,
        ax + sx,
        ya + 0.28,
        az + sz,
        nx * side,
        0,
        nz * side,
        0,
        v0,
        0.15,
        v1,
        L.CONCRETE,
        BRIDGE_CONC
      );
    }
    // Underside of bridge deck
    mb.quad(
      ax - nx * wOut,
      ya - deckH,
      az - nz * wOut,
      ax + nx * wOut,
      ya - deckH,
      az + nz * wOut,
      bx + nx * wOut,
      yb - deckH,
      bz + nz * wOut,
      bx - nx * wOut,
      yb - deckH,
      bz - nz * wOut,
      0,
      -1,
      0,
      0,
      v0,
      1,
      v1,
      L.CONCRETE,
      BRIDGE_CONC
    );
  }

  // Concrete bridge piers / pillars reaching into riverbed
  const tot = cum[n - 1];
  const step = tot > 28 ? 16 : 10;
  let nextPier = Math.min(8, tot * 0.35);
  for (let i = 0; i < n; i++) {
    if (i > 0 && i < n - 1 && cum[i] < nextPier) continue;
    if (i > 0 && i < n - 1) nextPier = cum[i] + step;
    const x = p[i * 2],
      z = p[i * 2 + 1],
      topY = y[i] - deckH + 0.05;
    const botY = t.h(x, z) - 1.5;
    if (topY - botY < 0.4) continue;
    const ax = i > 0 ? p[i * 2 - 2] : x,
      az = i > 0 ? p[i * 2 - 1] : z,
      bx = i < n - 1 ? p[i * 2 + 2] : x,
      bz = i < n - 1 ? p[i * 2 + 3] : z;
    let tx = bx - ax,
      tz = bz - az;
    const l = Math.hypot(tx, tz) || 1;
    tx /= l;
    tz /= l;
    const nx = -tz,
      nz = tx;
    const pw = Math.max(0.45, half * 0.65),
      pd = 0.42;
    const mb = ch.at(x, z);
    const c0x = x - nx * pw - tx * pd,
      c0z = z - nz * pw - tz * pd;
    const c1x = x + nx * pw - tx * pd,
      c1z = z + nz * pw - tz * pd;
    const c2x = x + nx * pw + tx * pd,
      c2z = z + nz * pw + tz * pd;
    const c3x = x - nx * pw + tx * pd,
      c3z = z - nz * pw + tz * pd;
    mb.quad(c0x, botY, c0z, c1x, botY, c1z, c1x, topY, c1z, c0x, topY, c0z, -tx, 0, -tz, 0, 0, 1, 1, L.CONCRETE, BRIDGE_CONC);
    mb.quad(c1x, botY, c1z, c2x, botY, c2z, c2x, topY, c2z, c1x, topY, c1z, nx, 0, nz, 0, 0, 1, 1, L.CONCRETE, BRIDGE_CONC);
    mb.quad(c2x, botY, c2z, c3x, botY, c3z, c3x, topY, c3z, c2x, topY, c2z, tx, 0, tz, 0, 0, 1, 1, L.CONCRETE, BRIDGE_CONC);
    mb.quad(c3x, botY, c3z, c0x, botY, c0z, c0x, topY, c0z, c3x, topY, c3z, -nx, 0, -nz, 0, 0, 1, 1, L.CONCRETE, BRIDGE_CONC);
  }
}

function buildRailEmbankment(ch: Chunks, p: number[], y: Float32Array, cum: Float32Array, t: Terrain, isBridge: boolean) {
  const n = p.length / 2;
  if (n < 2) return;
  const topHalf = 1.75;
  const botHalf = 4.2;
  for (let i = 1; i < n; i++) {
    const ax = p[(i - 1) * 2],
      az = p[(i - 1) * 2 + 1],
      bx = p[i * 2],
      bz = p[i * 2 + 1];
    let tx = bx - ax,
      tz = bz - az;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    const nx = -tz,
      nz = tx;
    const ya = isBridge ? y[i - 1] : t.hu(ax, az) + 0.34;
    const yb = isBridge ? y[i] : t.hu(bx, bz) + 0.34;
    const mb = ch.at((ax + bx) / 2, (az + bz) / 2);
    const v0 = cum[i - 1] / 3,
      v1 = cum[i] / 3;

    if (!isBridge) {
      // Trapezoidal gravel ballast embankment side slopes (skarpy nasypu kolejowego)
      for (const side of [1, -1]) {
        const tx0 = ax + nx * topHalf * side,
          tz0 = az + nz * topHalf * side;
        const tx1 = bx + nx * topHalf * side,
          tz1 = bz + nz * topHalf * side;
        const bx0 = ax + nx * botHalf * side,
          bz0 = az + nz * botHalf * side;
        const bx1 = bx + nx * botHalf * side,
          bz1 = bz + nz * botHalf * side;
        const by0 = Math.min(ya - 0.3, t.hu(bx0, bz0) - 0.15);
        const by1 = Math.min(yb - 0.3, t.hu(bx1, bz1) - 0.15);
        mb.quad(
          bx0,
          by0,
          bz0,
          bx1,
          by1,
          bz1,
          tx1,
          yb - 0.02,
          tz1,
          tx0,
          ya - 0.02,
          tz0,
          nx * side * 0.6,
          0.8,
          nz * side * 0.6,
          0,
          v0,
          1,
          v1,
          L.BALLAST,
          BALLAST_TINT
        );
      }
    }

    // 3D Steel Rails (UIC60 standard gauge 1.435m -> ±0.72m from center)
    for (const rOff of [-0.72, 0.72]) {
      const rx0 = ax + nx * rOff,
        rz0 = az + nz * rOff;
      const rx1 = bx + nx * rOff,
        rz1 = bz + nz * rOff;
      const rw = 0.045,
        rh = 0.09;
      mb.quad(
        rx0 - nx * rw,
        ya + rh,
        rz0 - nz * rw,
        rx0 + nx * rw,
        ya + rh,
        rz0 + nz * rw,
        rx1 + nx * rw,
        yb + rh,
        rz1 + nz * rw,
        rx1 - nx * rw,
        yb + rh,
        rz1 - nz * rw,
        0,
        1,
        0,
        0,
        v0,
        0.1,
        v1,
        L.CONCRETE,
        STEEL_TINT
      );
    }
  }
}

function lengths(p: number[]): Float32Array {
  const n = p.length / 2,
    c = new Float32Array(n);
  let s = 0;
  for (let i = 1; i < n; i++) {
    s += Math.hypot(p[i * 2] - p[i * 2 - 2], p[i * 2 + 1] - p[i * 2 - 1]);
    c[i] = s;
  }
  return c;
}

const URBAN: Record<number, number> = {
  [SF.YARD]: 1,
  [SF.PAVED]: 1,
  [SF.PARKING]: 1,
  [SF.BUILDING]: 1,
  [SF.PARK]: 1,
  [SF.PLAY]: 1,
  [SF.PITCH]: 1,
  [SF.CEMETERY]: 1,
};

export function buildRoads(net: any, w: any, t: Terrain, ch: Chunks) {
  const drive = net.drive,
    all = net.all,
    walk = net.walk;
  for (const r of net.roads) {
    const n = r.p.length / 2;
    r.cum = lengths(r.p);
    const tot = r.cum[n - 1];
    const ya = t.hu(r.p[0], r.p[1]),
      yb = t.hu(r.p[n * 2 - 2], r.p[n * 2 - 1]);
    // Slight arch on bridges for visual realism & clearance over rivers
    for (let i = 0; i < n; i++) {
      const f = tot > 0 ? r.cum[i] / tot : 0;
      const arch = r.bridge ? Math.sin(f * Math.PI) * Math.min(1.4, tot * 0.03) + 0.45 : 0;
      r.y[i] = (r.bridge ? ya + (yb - ya) * f + arch : t.hu(r.p[i * 2], r.p[i * 2 + 1])) + r.yoff;
    }
    for (let i = 0; i + 1 < n; i++) {
      const o = i * 2,
        id = r.id * 4096 + i;
      all.add(r.p[o], r.p[o + 1], r.p[o + 2], r.p[o + 3], id);
      if (r.drive) drive.add(r.p[o], r.p[o + 1], r.p[o + 2], r.p[o + 3], id);
      else walk.add(r.p[o], r.p[o + 1], r.p[o + 2], r.p[o + 3], id);
      if (r.bridge) {
        net.decks.push({
          ax: r.p[o],
          az: r.p[o + 1],
          bx: r.p[o + 2],
          bz: r.p[o + 3],
          ya: r.y[i],
          yb: r.y[i + 1],
          half: r.half + 0.35,
        });
        net.deckGrid.add(r.p[o], r.p[o + 1], r.p[o + 2], r.p[o + 3], net.decks.length - 1);
      }
    }
    ribbon(ch, r.p, r.y, r.half, r.layer, r.tint, r.vlen, r.full, r.bridge ? null : t, r.yoff, r.cum);
    if (r.bridge) {
      buildBridgeStructure(ch, r.p, r.y, r.half, r.cum, t, false);
    }
  }

  for (const r of net.roads) {
    if (!r.drive || r.bridge || (r.layer !== L.ASPHALT && r.layer !== L.ASPHALT_C && r.layer !== L.ASPHALT_E)) continue;
    for (const e of [0, r.p.length / 2 - 1]) {
      const cx = r.p[e * 2],
        cz = r.p[e * 2 + 1],
        cy = t.hu(cx, cz) + r.yoff - 0.004,
        mb = ch.at(cx, cz);
      for (let k = 0; k < 12; k++) {
        const a0 = (k / 12) * 6.2832,
          a1 = ((k + 1) / 12) * 6.2832;
        const x0 = cx + Math.cos(a0) * r.half,
          z0 = cz + Math.sin(a0) * r.half,
          x1 = cx + Math.cos(a1) * r.half,
          z1 = cz + Math.sin(a1) * r.half;
        mb.tri(
          cx,
          cy,
          cz,
          x0,
          t.hu(x0, z0) + r.yoff - 0.004,
          z0,
          x1,
          t.hu(x1, z1) + r.yoff - 0.004,
          z1,
          0,
          1,
          0,
          cx / 4,
          cz / 4,
          x0 / 4,
          z0 / 4,
          x1 / 4,
          z1 / 4,
          L.ASPHALT,
          r.tint
        );
      }
    }
  }

  // Sidewalks & concrete curbs along urban streets
  const SW = 1.85,
    H = 0.15;
  for (const r of net.roads) {
    if (
      r.bridge ||
      !(
        r.k === "secondary" ||
        r.k === "tertiary" ||
        r.k === "residential" ||
        r.k === "living_street" ||
        r.k === "unclassified"
      )
    )
      continue;
    const n = r.p.length / 2;
    for (const side of [1, -1]) {
      let prev: number[] | null = null;
      for (let i = 0; i < n; i++) {
        const x = r.p[i * 2],
          z = r.p[i * 2 + 1];
        const ax = i > 0 ? r.p[i * 2 - 2] : x,
          az = i > 0 ? r.p[i * 2 - 1] : z,
          bx = i < n - 1 ? r.p[i * 2 + 2] : x,
          bz = i < n - 1 ? r.p[i * 2 + 3] : z;
        let tx = bx - ax,
          tz = bz - az;
        const l = Math.hypot(tx, tz) || 1;
        tx /= l;
        tz /= l;
        const nx = -tz * side,
          nz = tx * side;
        const ix = x + nx * r.half,
          iz = z + nz * r.half,
          ox = x + nx * (r.half + SW),
          oz = z + nz * (r.half + SW),
          mx = x + nx * (r.half + SW / 2),
          mz = z + nz * (r.half + SW / 2);
        let ok = !!(
          URBAN[t.surf(x + nx * (r.half + 9), z + nz * (r.half + 9))] ||
          URBAN[t.surf(x + nx * (r.half + 4.5), z + nz * (r.half + 4.5))]
        );
        if (ok && walk.nearest(mx, mz, 3.2) >= 0) ok = false;
        if (ok)
          drive.near(mx, mz, 8, (si: number) => {
            if (!ok) return;
            const o = si * 5,
              rid = Math.floor(drive.s[o + 4] / 4096);
            if (rid === r.id) return;
            if (segDist(mx, mz, drive.s[o], drive.s[o + 1], drive.s[o + 2], drive.s[o + 3]) < net.roads[rid].half + 0.5)
              ok = false;
          });
        if (!ok) {
          prev = null;
          continue;
        }
        const iy = t.hu(ix, iz) + r.yoff,
          oy = t.hu(ox, oz) + r.yoff + H;
        if (prev) {
          const mb = ch.at(x, z),
            v0 = r.cum[i - 1] / 2,
            v1 = r.cum[i] / 2;
          mb.quad(
            prev[0],
            prev[2] + H,
            prev[1],
            prev[3],
            prev[5],
            prev[4],
            ox,
            oy,
            oz,
            ix,
            iy + H,
            iz,
            0,
            1,
            0,
            0,
            v0,
            SW / 2,
            v1,
            L.PAVING,
            PAVE
          );
          mb.quad(
            prev[0],
            prev[2],
            prev[1],
            prev[0],
            prev[2] + H,
            prev[1],
            ix,
            iy + H,
            iz,
            ix,
            iy,
            iz,
            -nx,
            0,
            -nz,
            0,
            v0,
            0.1,
            v1,
            L.CONCRETE,
            WHITE
          );
        }
        prev = [ix, iz, iy, ox, oz, oy];
      }
    }
  }

  // Pedestrian zebra crossings
  for (const pt of w.points) {
    if (pt.k !== "crossing") continue;
    const si = drive.nearest(pt.x, pt.z, 5);
    if (si < 0) continue;
    const s = drive.s,
      o = si * 5,
      r = net.roads[Math.floor(s[o + 4] / 4096)];
    if (r.layer === L.DIRT) continue;
    let tx = s[o + 2] - s[o],
      tz = s[o + 3] - s[o + 1];
    const l = Math.hypot(tx, tz) || 1;
    tx /= l;
    tz /= l;
    const cx = s[o] + (s[o + 2] - s[o]) * drive.nt,
      cz = s[o + 1] + (s[o + 3] - s[o + 1]) * drive.nt;
    const nx = -tz * r.half,
      nz = tx * r.half,
      hx = tx * 1.8,
      hz = tz * 1.8,
      y = t.hu(cx, cz) + r.yoff + 0.02;
    ch.at(cx, cz).quad(
      cx + nx - hx,
      y,
      cz + nz - hz,
      cx - nx - hx,
      y,
      cz - nz - hz,
      cx - nx + hx,
      y,
      cz - nz + hz,
      cx + nx + hx,
      y,
      cz + nz + hz,
      0,
      1,
      0,
      0,
      0,
      1,
      1,
      L.ZEBRA,
      WHITE
    );
  }

  // Railway tracks with 3D trapezoidal embankment & viaducts
  for (const ln of w.rails) {
    const p = resample(ln.p, 8),
      n = p.length / 2;
    if (n < 2) continue;
    const cum = lengths(p),
      y = new Float32Array(n);
    const ya = t.hu(p[0], p[1]),
      yb = t.hu(p[n * 2 - 2], p[n * 2 - 1]);
    if (ln.br) {
      for (let i = 0; i < n; i++) y[i] = ya + (yb - ya) * (cum[i] / (cum[n - 1] || 1)) + 0.4;
      for (let i = 0; i + 1 < n; i++) {
        const o = i * 2;
        net.decks.push({
          ax: p[o],
          az: p[o + 1],
          bx: p[o + 2],
          bz: p[o + 3],
          ya: y[i],
          yb: y[i + 1],
          half: 2.2,
        });
        net.deckGrid.add(p[o], p[o + 1], p[o + 2], p[o + 3], net.decks.length - 1);
      }
      buildBridgeStructure(ch, p, y, 1.8, cum, t, true);
    }
    ribbon(ch, p, y, 1.75, L.RAIL, WHITE, 2.4, true, ln.br ? null : t, 0.34, cum);
    buildRailEmbankment(ch, p, y, cum, t, !!ln.br);
  }
}

export function streamBuilder(w: any, t: Terrain): MB {
  const mb = new MB();
  for (const s of w.streams) {
    if (s.tn) continue;
    const half = s.k === "stream" ? 1.15 : s.k === "ditch" || s.k === "drain" ? 0.55 : 2.8;
    const p = resample(s.p, 6),
      n = p.length / 2;
    let px = 0,
      pz = 0,
      qx = 0,
      qz = 0,
      okPrev = false;
    for (let i = 0; i < n; i++) {
      const x = p[i * 2],
        z = p[i * 2 + 1];
      const ax = i > 0 ? p[i * 2 - 2] : x,
        az = i > 0 ? p[i * 2 - 1] : z,
        bx = i < n - 1 ? p[i * 2 + 2] : x,
        bz = i < n - 1 ? p[i * 2 + 3] : z;
      let tx = bx - ax,
        tz = bz - az;
      const l = Math.hypot(tx, tz) || 1;
      tx /= l;
      tz /= l;
      const lx = x - tz * half,
        lz = z + tx * half,
        rx = x + tz * half,
        rz = z - tx * half;
      const sf = t.surf(x, z),
        ok = sf !== SF.WATER && sf !== SF.ROAD && sf !== SF.BUILDING;
      if (i > 0 && ok && okPrev)
        mb.quad(
          px,
          t.h(px, pz) + 0.06,
          pz,
          qx,
          t.h(qx, qz) + 0.06,
          qz,
          rx,
          t.h(rx, rz) + 0.06,
          rz,
          lx,
          t.h(lx, lz) + 0.06,
          lz,
          0,
          1,
          0,
          0,
          0,
          1,
          1,
          0,
          WHITE
        );
      px = lx;
      pz = lz;
      qx = rx;
      qz = rz;
      okPrev = ok;
    }
  }
  return mb;
}

export function deckAt(net: any, x: number, z: number, curY: number): number {
  let best = -1e9;
  const g = net.deckGrid,
    s = g.s;
  g.near(x, z, 1.5, (si: number) => {
    const d = net.decks[s[si * 5 + 4]];
    const dist = segDist(x, z, d.ax, d.az, d.bx, d.bz);
    if (dist <= d.half + 0.35) {
      const y = d.ya + (d.yb - d.ya) * segT;
      if (y > best && curY > y - 2.4) best = y;
    }
  });
  return best;
}
