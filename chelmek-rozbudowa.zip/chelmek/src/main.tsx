import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

declare global {
  interface Window {
    __INITIAL_HTML__?: string;
  }
}

try {
  window.__INITIAL_HTML__ = "<!doctype html>\n" + document.documentElement.outerHTML;
} catch {
  // ignore
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
