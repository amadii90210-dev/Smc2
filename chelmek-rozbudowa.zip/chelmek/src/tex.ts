import {
  DataArrayTexture,
  DataTexture,
  LinearFilter,
  LinearMipmapLinearFilter,
  RepeatWrapping,
  RGBAFormat,
  SRGBColorSpace,
  UnsignedByteType,
} from "three";
import { hash01 } from "./geo";

export const L = {
  PLASTER: 0,
  H_WIN: 1,
  H_DOOR: 2,
  B_WIN: 3,
  SHOP: 4,
  SHOP_DOOR: 5,
  IND: 6,
  IND_GATE: 7,
  BRICK: 8,
  BRICK_WIN: 9,
  GARAGE: 10,
  WOOD: 11,
  CIVIC_WIN: 12,
  CHURCH_WIN: 13,
  CONCRETE: 14,
  ROOF_TILE: 15,
  ROOF_FLAT: 16,
  ROOF_SHEET: 17,
  ASPHALT: 18,
  ASPHALT_C: 19,
  ASPHALT_E: 20,
  PAVING: 21,
  DIRT: 22,
  GRAVEL: 23,
  ZEBRA: 24,
  RAIL: 25,
  CYCLE: 26,
  PLANKS: 27,
  PARKING: 28,
  STEPS: 29,
  FENCE_WOOD: 30,
  FENCE_METAL: 31,
  BALLAST: 32,
  COUNT: 33,
} as const;

const gray = (v: number) => "rgb(" + v + "," + v + "," + v + ")";

function noiseField(S: number, period: number, seed: number): Float32Array {
  const P = Math.max(2, Math.round(period));
  const g = new Float32Array(P * P);
  for (let i = 0; i < g.length; i++) g[i] = hash01(i, seed, 91);
  const out = new Float32Array(S * S);
  for (let y = 0; y < S; y++) {
    const fy = (y / S) * P,
      y0 = Math.floor(fy),
      ty = fy - y0,
      sy = ty * ty * (3 - 2 * ty),
      ya = (y0 % P) * P,
      yb = ((y0 + 1) % P) * P;
    for (let x = 0; x < S; x++) {
      const fx = (x / S) * P,
        x0 = Math.floor(fx),
        tx = fx - x0,
        sx = tx * tx * (3 - 2 * tx),
        xa = x0 % P,
        xb = (x0 + 1) % P;
      const a = g[ya + xa],
        b = g[ya + xb],
        c = g[yb + xa],
        d = g[yb + xb];
      out[y * S + x] = (a + (b - a) * sx) * (1 - sy) + (c + (d - c) * sx) * sy;
    }
  }
  return out;
}

class Painter {
  S: number;
  c: CanvasRenderingContext2D;
  m: CanvasRenderingContext2D;
  n1: Float32Array;
  n2: Float32Array;
  n3: Float32Array;
  constructor(S: number) {
    this.S = S;
    const mk = () => {
      const cv = document.createElement("canvas");
      cv.width = cv.height = S;
      return cv.getContext("2d", { willReadFrequently: true })!;
    };
    this.c = mk();
    this.m = mk();
    this.n1 = noiseField(S, S / 2, 1);
    this.n2 = noiseField(S, 12, 2);
    this.n3 = noiseField(S, 4, 3);
  }
  base(r: number, g: number, b: number, a1: number, a2: number, a3: number, mask: number) {
    const S = this.S,
      img = this.c.createImageData(S, S),
      d = img.data;
    for (let i = 0; i < S * S; i++) {
      const f = 1 + a1 * (this.n1[i] - 0.5) + a2 * (this.n2[i] - 0.5) + a3 * (this.n3[i] - 0.5);
      d[i * 4] = Math.max(0, Math.min(255, r * f));
      d[i * 4 + 1] = Math.max(0, Math.min(255, g * f));
      d[i * 4 + 2] = Math.max(0, Math.min(255, b * f));
      d[i * 4 + 3] = 255;
    }
    this.c.putImageData(img, 0, 0);
    this.m.fillStyle = gray(mask);
    this.m.fillRect(0, 0, S, S);
  }
  r(x: number, y: number, w: number, h: number, col2: string, mask: number) {
    const S = this.S;
    this.c.fillStyle = col2;
    this.c.fillRect(x * S, y * S, w * S, h * S);
    this.m.fillStyle = gray(mask);
    this.m.fillRect(x * S, y * S, w * S, h * S);
  }
  tone(x: number, y: number, w: number, h: number, col2: string) {
    const S = this.S;
    this.c.fillStyle = col2;
    this.c.fillRect(x * S, y * S, w * S, h * S);
  }
  shade(x: number, y: number, w: number, h: number, a: number) {
    this.tone(x, y, w, h, "rgba(0,0,0," + a + ")");
  }
  glass(x: number, y: number, w: number, h: number) {
    const S = this.S,
      c = this.c;
    const g = c.createLinearGradient(0, y * S, 0, (y + h) * S);
    g.addColorStop(0, "#5e7a94");
    g.addColorStop(0.45, "#364b61");
    g.addColorStop(1, "#1e2a38");
    c.fillStyle = g;
    c.fillRect(x * S, y * S, w * S, h * S);
    // Subtle interior curtain / room reflection hint
    c.fillStyle = "rgba(245, 238, 222, 0.16)";
    c.fillRect((x + 0.01) * S, (y + 0.01) * S, w * 0.24 * S, (h - 0.02) * S);
    c.fillStyle = "rgba(255, 255, 255, 0.12)";
    c.fillRect((x + w * 0.15) * S, (y + h * 0.1) * S, w * 0.7 * S, h * 0.08 * S);
    this.m.fillStyle = "#000";
    this.m.fillRect(x * S, y * S, w * S, h * S);
  }
  win(x: number, y: number, w: number, h: number, panes: number) {
    const f = 0.022;
    // Deep recessed reveal shadow
    this.shade(x - 0.018, y - 0.018, w + 0.036, h + 0.04, 0.28);
    // Outer frame
    this.r(x, y, w, h, "#eceae2", 128);
    const pw = (w - f * (panes + 1)) / panes;
    for (let i = 0; i < panes; i++) {
      this.glass(x + f + i * (pw + f), y + f, pw, h - 2 * f);
      // Horizontal transom bar
      this.r(x + f + i * (pw + f), y + h * 0.34, pw, 0.014, "#e2dfd5", 128);
    }
    // Window sill (parapet zewnętrzny) + drip shadow
    this.r(x - 0.025, y + h, w + 0.05, 0.026, "#c8c5bc", 128);
    this.shade(x - 0.025, y + h + 0.026, w + 0.05, 0.036, 0.24);
  }
  pack(dst: Uint8Array, layer: number) {
    const S = this.S,
      a = this.c.getImageData(0, 0, S, S).data,
      b = this.m.getImageData(0, 0, S, S).data,
      off = layer * S * S * 4;
    for (let y = 0; y < S; y++) {
      const sy = S - 1 - y;
      for (let x = 0; x < S; x++) {
        const s = (sy * S + x) * 4,
          d = off + (y * S + x) * 4;
        dst[d] = a[s];
        dst[d + 1] = a[s + 1];
        dst[d + 2] = a[s + 2];
        dst[d + 3] = b[s];
      }
    }
  }
}

function bricks(p: Painter) {
  // Authentic red clinker brick (charakterystyczna cegła Kolonii Bata w Chełmku)
  p.base(152, 144, 134, 0.09, 0.06, 0.05, 128);
  const cols = ["#94432e", "#a24e37", "#843b28", "#ad573f", "#8d4330", "#9c4934", "#7c3725"];
  const rows = 40,
    per = 12;
  for (let r = 0; r < rows; r++)
    for (let k = -1; k < per; k++) {
      const x = (k + (r % 2) * 0.5) / per;
      p.r(x + 0.004, r / rows + 0.003, 1 / per - 0.008, 1 / rows - 0.006, cols[(hash01(r, k, 5) * cols.length) | 0], 128);
      p.shade(x + 0.004, r / rows + 1 / rows - 0.006, 1 / per - 0.008, 0.003, 0.22);
    }
}

function arch(p: Painter) {
  const S = p.S;
  const shape = (c: CanvasRenderingContext2D, col2: string) => {
    c.fillStyle = col2;
    c.beginPath();
    c.arc(0.5 * S, 0.3 * S, 0.11 * S, Math.PI, 0);
    c.rect(0.39 * S, 0.3 * S, 0.22 * S, 0.5 * S);
    c.fill();
  };
  shape(p.c, "#34495e");
  shape(p.m, "#000");
  p.c.strokeStyle = "#d8d2c2";
  p.c.lineWidth = 0.02 * S;
  p.c.beginPath();
  p.c.arc(0.5 * S, 0.3 * S, 0.11 * S, Math.PI, 0);
  p.c.lineTo(0.61 * S, 0.8 * S);
  p.c.lineTo(0.39 * S, 0.8 * S);
  p.c.closePath();
  p.c.stroke();
}

function draw(p: Painter, id: number) {
  const plaster = () => {
    p.base(230, 228, 222, 0.07, 0.08, 0.09, 255);
    // Subtle weathering at top and bottom of facade story
    p.shade(0, 0, 1, 0.04, 0.08);
    p.shade(0, 0.92, 1, 0.08, 0.12);
  };
  const asphalt = () => {
    p.base(62, 65, 70, 0.22, 0.12, 0.1, 255);
    // Subtle tire wear tracks
    p.shade(0.18, 0, 0.16, 1, 0.08);
    p.shade(0.66, 0, 0.16, 1, 0.08);
  };
  const line = "#e2dfd4";
  switch (id) {
    case L.PLASTER:
      plaster();
      break;
    case L.H_WIN:
      plaster();
      p.win(0.28, 0.23, 0.44, 0.42, 2);
      break;
    case L.H_DOOR:
      plaster();
      p.shade(0.31, 0.22, 0.38, 0.78, 0.25);
      p.r(0.28, 0.2, 0.44, 0.035, "#7d7d78", 128);
      p.r(0.34, 0.26, 0.32, 0.74, "#5c3d28", 128);
      p.r(0.37, 0.48, 0.26, 0.21, "#6e4b33", 128);
      p.r(0.37, 0.73, 0.26, 0.21, "#6e4b33", 128);
      p.glass(0.39, 0.3, 0.22, 0.14);
      p.r(0.6, 0.62, 0.022, 0.065, "#d8c38a", 128);
      p.r(0.28, 0.965, 0.44, 0.035, "#8f8f8a", 128);
      break;
    case L.B_WIN:
      plaster();
      p.shade(0, 0, 1, 0.015, 0.22);
      p.shade(0.495, 0, 0.012, 1, 0.18);
      p.win(0.06, 0.25, 0.38, 0.4, 3);
      p.win(0.56, 0.19, 0.38, 0.62, 2);
      // Balcony slab & balustrade
      p.shade(0.51, 0.835, 0.47, 0.045, 0.26);
      p.r(0.51, 0.795, 0.47, 0.04, "#a8a8a2", 128);
      p.r(0.52, 0.55, 0.45, 0.245, "#ddd8ca", 128);
      for (let b = 0; b < 8; b++) p.shade(0.53 + b * 0.055, 0.56, 0.012, 0.23, 0.25);
      p.r(0.51, 0.535, 0.47, 0.02, "#5a5e63", 128);
      break;
    case L.SHOP:
      plaster();
      p.r(0.03, 0.28, 0.94, 0.65, "#2d3238", 128);
      p.glass(0.05, 0.31, 0.43, 0.59);
      p.glass(0.52, 0.31, 0.43, 0.59);
      p.tone(0.07, 0.58, 0.39, 0.03, "rgba(255,255,255,0.24)");
      p.tone(0.54, 0.64, 0.39, 0.03, "rgba(255,255,255,0.22)");
      p.r(0, 0.92, 1, 0.08, "#5e5e5a", 128);
      break;
    case L.SHOP_DOOR:
      plaster();
      p.r(0.03, 0.18, 0.94, 0.75, "#2d3238", 128);
      p.glass(0.07, 0.22, 0.4, 0.68);
      p.glass(0.53, 0.22, 0.4, 0.68);
      p.r(0.44, 0.54, 0.016, 0.13, "#d8d8d2", 128);
      p.r(0.544, 0.54, 0.016, 0.13, "#d8d8d2", 128);
      p.r(0, 0.92, 1, 0.08, "#5e5e5a", 128);
      break;
    case L.IND:
    case L.IND_GATE:
      p.base(220, 224, 228, 0.04, 0.05, 0.06, 255);
      for (let i = 0; i < 24; i++) p.shade(i / 24, 0, 0.5 / 24, 1, 0.11);
      p.r(0, 0.1, 1, 0.15, "#3f454b", 128);
      for (let i = 0; i < 4; i++) p.glass(0.01 + i * 0.25, 0.115, 0.23, 0.12);
      p.r(0, 0.88, 1, 0.12, "#7d7d78", 128);
      if (id === L.IND_GATE) {
        p.r(0.1, 0.28, 0.8, 0.72, "#8b949c", 128);
        for (let k = 0; k < 11; k++) p.shade(0.1, 0.28 + k * 0.064, 0.8, 0.014, 0.28);
      }
      break;
    case L.BRICK:
      bricks(p);
      break;
    case L.BRICK_WIN:
      bricks(p);
      p.r(0.25, 0.18, 0.5, 0.045, "#c5c0b4", 128);
      p.win(0.28, 0.23, 0.44, 0.42, 2);
      break;
    case L.GARAGE:
      plaster();
      p.shade(0.08, 0.24, 0.84, 0.76, 0.22);
      p.r(0.1, 0.26, 0.8, 0.74, "#b8bdc2", 128);
      for (let k = 0; k < 9; k++) p.shade(0.1, 0.26 + k * 0.08, 0.8, 0.012, 0.32);
      break;
    case L.WOOD:
      p.base(142, 102, 66, 0.12, 0.12, 0.09, 128);
      for (let i = 0; i < 10; i++) {
        p.shade(i / 10, 0, 0.1, 1, hash01(i, 77) * 0.16);
        p.shade(i / 10, 0, 0.01, 1, 0.44);
      }
      break;
    case L.CIVIC_WIN:
      plaster();
      p.win(0.09, 0.19, 0.82, 0.5, 4);
      break;
    case L.CHURCH_WIN:
      plaster();
      arch(p);
      break;
    case L.CONCRETE:
      p.base(152, 150, 145, 0.1, 0.09, 0.08, 128);
      break;
    case L.ROOF_TILE:
      p.base(204, 200, 196, 0.06, 0.07, 0.06, 255);
      for (let r = 0; r < 7; r++) {
        p.shade(0, r / 7 + 0.1, 1, 0.042, 0.36);
        for (let k = 0; k < 9; k++) {
          const x = (k + (r % 2) * 0.5) / 9;
          p.shade(x, r / 7, 0.008, 1 / 7, 0.28);
          p.shade(x, r / 7, 1 / 9, 1 / 7, hash01(r, k, 3) * 0.12);
        }
      }
      break;
    case L.ROOF_FLAT:
      p.base(62, 64, 68, 0.14, 0.1, 0.08, 128);
      p.shade(0, 0.5, 1, 0.008, 0.32);
      p.shade(0.5, 0, 0.008, 1, 0.32);
      break;
    case L.ROOF_SHEET:
      p.base(198, 202, 206, 0.04, 0.04, 0.05, 255);
      for (let i = 0; i < 6; i++) {
        p.shade(i / 6, 0, 0.014, 1, 0.34);
        p.tone(i / 6 + 0.014, 0, 0.01, 1, "rgba(255,255,255,0.28)");
      }
      break;
    case L.ASPHALT:
      asphalt();
      break;
    case L.ASPHALT_C:
      asphalt();
      p.r(0.485, 0.24, 0.03, 0.52, line, 128);
      break;
    case L.ASPHALT_E:
      asphalt();
      p.r(0.486, 0.24, 0.028, 0.52, line, 128);
      p.r(0.035, 0, 0.024, 1, line, 128);
      p.r(0.941, 0, 0.024, 1, line, 128);
      break;
    case L.PAVING:
      p.base(172, 169, 162, 0.08, 0.07, 0.06, 255);
      for (let r = 0; r < 10; r++) {
        p.shade(0, r / 10, 1, 0.008, 0.34);
        for (let k = 0; k < 10; k++) p.shade((k + (r % 2) * 0.5) / 10, r / 10, 0.007, 0.1, 0.28);
      }
      break;
    case L.DIRT:
      p.base(126, 106, 78, 0.18, 0.16, 0.14, 128);
      p.shade(0.2, 0, 0.14, 1, 0.14);
      p.shade(0.66, 0, 0.14, 1, 0.14);
      p.tone(0.43, 0, 0.14, 1, "rgba(86,118,56,0.52)");
      p.tone(0, 0, 0.08, 1, "rgba(86,118,56,0.58)");
      p.tone(0.92, 0, 0.08, 1, "rgba(86,118,56,0.58)");
      break;
    case L.GRAVEL:
      p.base(146, 140, 130, 0.3, 0.1, 0.08, 128);
      break;
    case L.ZEBRA:
      asphalt();
      for (let k = 0; k < 6; k++) p.r((2 * k + 0.5) / 12, 0.08, 1 / 12, 0.84, "#e8e6de", 128);
      break;
    case L.RAIL:
      p.base(114, 106, 98, 0.32, 0.12, 0.08, 128);
      for (let k = 0; k < 4; k++) {
        p.r(0.1, k / 4 + 0.06, 0.8, 0.12, "#544030", 128);
        p.shade(0.1, k / 4 + 0.16, 0.8, 0.025, 0.35);
      }
      p.r(0.275, 0, 0.028, 1, "#c4c8cc", 128);
      p.r(0.697, 0, 0.028, 1, "#c4c8cc", 128);
      break;
    case L.CYCLE:
      p.base(148, 74, 62, 0.16, 0.08, 0.06, 128);
      break;
    case L.PLANKS:
      p.base(146, 114, 80, 0.12, 0.1, 0.08, 128);
      for (let k = 0; k < 10; k++) p.shade(0, k / 10, 1, 0.014, 0.44);
      break;
    case L.PARKING:
      asphalt();
      p.r(0, 0, 1, 0.04, line, 128);
      break;
    case L.STEPS:
      p.base(154, 152, 146, 0.09, 0.08, 0.07, 128);
      for (let k = 0; k < 8; k++) p.shade(0, k / 8, 1, 0.04, 0.42);
      break;
    case L.FENCE_WOOD:
      // Realistic Polish homestead fence: clinker/concrete post + concrete plinth + stained wood slats
      p.base(118, 82, 52, 0.1, 0.08, 0.06, 128);
      for (let s = 0; s < 5; s++) {
        p.r(0.12, 0.08 + s * 0.135, 0.88, 0.105, s % 2 ? "#7d5434" : "#895c3a", 128);
        p.shade(0.12, 0.17 + s * 0.135, 0.88, 0.018, 0.36);
      }
      // Concrete plinth (podmurówka) at bottom (y = 0.76..1.0)
      p.r(0, 0.76, 1, 0.24, "#9a9890", 128);
      p.shade(0, 0.76, 1, 0.03, 0.3);
      // Clinker brick post on left edge (x = 0..0.13)
      p.r(0, 0.02, 0.13, 0.98, "#8c422f", 128);
      p.r(0, 0, 0.145, 0.045, "#6b6a65", 128);
      break;
    case L.FENCE_METAL:
      // Modern anthracite palisade fence + concrete plinth + stone/concrete post
      p.base(54, 58, 64, 0.06, 0.05, 0.04, 128);
      for (let b = 0; b < 10; b++) {
        p.r(0.13 + b * 0.086, 0.08, 0.048, 0.68, "#2e333a", 128);
        p.shade(0.13 + b * 0.086 + 0.048, 0.08, 0.038, 0.68, 0.32);
      }
      p.r(0.12, 0.14, 0.88, 0.04, "#24282e", 128);
      p.r(0.12, 0.68, 0.88, 0.04, "#24282e", 128);
      p.r(0, 0.75, 1, 0.25, "#a4a29a", 128);
      p.r(0, 0.02, 0.13, 0.98, "#9c9a92", 128);
      p.r(0, 0, 0.145, 0.045, "#4a4e54", 128);
      break;
    case L.BALLAST:
      // Crushed stone railway embankment ballast
      p.base(118, 112, 104, 0.36, 0.22, 0.18, 128);
      break;
  }
}

export function makeArrayTexture(S: number, aniso: number): DataArrayTexture {
  const p = new Painter(S);
  const data = new Uint8Array(S * S * 4 * L.COUNT);
  for (let id = 0; id < L.COUNT; id++) {
    draw(p, id);
    p.pack(data, id);
  }
  const t = new DataArrayTexture(data, S, S, L.COUNT);
  t.format = RGBAFormat;
  t.type = UnsignedByteType;
  t.colorSpace = SRGBColorSpace;
  t.wrapS = t.wrapT = RepeatWrapping;
  t.minFilter = LinearMipmapLinearFilter;
  t.magFilter = LinearFilter;
  t.generateMipmaps = true;
  t.anisotropy = aniso;
  t.needsUpdate = true;
  return t;
}

export function detailTexture(): DataTexture {
  const S = 256;
  const a = noiseField(S, 96, 11),
    b = noiseField(S, 24, 12),
    c = noiseField(S, 7, 13);
  const d = new Uint8Array(S * S * 4);
  for (let i = 0; i < S * S; i++) {
    d[i * 4] = a[i] * 255;
    d[i * 4 + 1] = b[i] * 255;
    d[i * 4 + 2] = c[i] * 255;
    d[i * 4 + 3] = 255;
  }
  const t = new DataTexture(d, S, S, RGBAFormat);
  t.wrapS = t.wrapT = RepeatWrapping;
  t.minFilter = LinearMipmapLinearFilter;
  t.magFilter = LinearFilter;
  t.generateMipmaps = true;
  t.needsUpdate = true;
  return t;
}
