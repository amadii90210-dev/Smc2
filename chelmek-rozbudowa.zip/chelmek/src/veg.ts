import {
  BufferAttribute,
  BufferGeometry,
  Color,
  ConeGeometry,
  CylinderGeometry,
  Group,
  IcosahedronGeometry,
  InstancedMesh,
  Matrix4,
  MeshStandardMaterial,
  Quaternion,
  Vector3,
} from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { WORLD } from "./config";
import { U } from "./env";
import { hash01, resample } from "./geo";
import { SF, Terrain } from "./terrain";

const C = (h: string) => {
  const c = new Color(h);
  return [c.r, c.g, c.b];
};

const BARK = C("#4a3828");
const PBARK = C("#7c4e32");
const WBARK = C("#e4e0d5");
const LT = C("#568832");
const LB = C("#23471a");
const PT = C("#386332");
const PB = C("#18331d");
const BT = C("#7ca63e");
const BB = C("#3e6924");
const ST = C("#295632");
const SB = C("#122e1b");
const UT = C("#5e8f3a");
const UB = C("#294d1e");
const RT = C("#a8a398");
const RB = C("#5c5850");

function blob(
  r: number,
  detail: number,
  sx: number,
  sy: number,
  sz: number,
  ox: number,
  oy: number,
  oz: number,
  top: number[],
  bot: number[],
  seed: number
): BufferGeometry {
  const g = new IcosahedronGeometry(r, detail),
    pos = g.getAttribute("position"),
    nor = g.getAttribute("normal"),
    col2 = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i),
      y = pos.getY(i),
      z = pos.getZ(i);
    const l = Math.hypot(x, y, z) || 1,
      ax = x / l,
      ay = y / l,
      az = z / l;
    const n1 = hash01(Math.round(x * 40), Math.round(y * 40) + seed, Math.round(z * 40)) - 0.5;
    const n2 = Math.sin(x * 3.5 + seed) * Math.cos(z * 3.5 - seed) * 0.12;
    const k = 1 + 0.26 * n1 + n2;
    x *= k * sx;
    y *= k * sy;
    z *= k * sz;
    pos.setXYZ(i, x + ox, y + oy, z + oz);
    // Smooth outward foliage normal for realistic UE-style canopy shading
    const nx = ax + 0.25 * n1,
      ny = ay + 0.35,
      nz = az - 0.25 * n1;
    const nl = Math.hypot(nx, ny, nz) || 1;
    nor.setXYZ(i, nx / nl, ny / nl, nz / nl);
    const ao = Math.min(1, 0.55 + 0.45 * (l / r));
    const f = Math.max(0, Math.min(1, 0.5 + 0.5 * ay)) * ao;
    col2[i * 3] = bot[0] + (top[0] - bot[0]) * f;
    col2[i * 3 + 1] = bot[1] + (top[1] - bot[1]) * f;
    col2[i * 3 + 2] = bot[2] + (top[2] - bot[2]) * f;
  }
  g.setAttribute("color", new BufferAttribute(col2, 3));
  g.deleteAttribute("uv");
  return g;
}

function flat(g0: BufferGeometry, fn: (y: number) => number[]): BufferGeometry {
  const g = g0.index ? g0.toNonIndexed() : g0,
    pos = g.getAttribute("position"),
    col2 = new Float32Array(pos.count * 3);
  for (let i = 0; i < pos.count; i++) {
    const c = fn(pos.getY(i));
    col2[i * 3] = c[0];
    col2[i * 3 + 1] = c[1];
    col2[i * 3 + 2] = c[2];
  }
  g.setAttribute("color", new BufferAttribute(col2, 3));
  g.deleteAttribute("uv");
  return g;
}

function trunk(r0: number, r1: number, h: number, seg: number, c: number[]): BufferGeometry {
  const g = new CylinderGeometry(r1, r0, h, seg, 2, true);
  g.translate(0, h / 2, 0);
  return flat(g, (y) => {
    const shade = 0.78 + 0.22 * Math.min(1, y / h);
    return [c[0] * shade, c[1] * shade, c[2] * shade];
  });
}

function branch(
  x0: number,
  y0: number,
  z0: number,
  x1: number,
  y1: number,
  z1: number,
  r0: number,
  r1: number,
  c: number[]
): BufferGeometry {
  const dx = x1 - x0,
    dy = y1 - y0,
    dz = z1 - z0,
    len = Math.hypot(dx, dy, dz);
  const g = new CylinderGeometry(r1, r0, len, 5, 1, true);
  const q = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), new Vector3(dx / len, dy / len, dz / len));
  const m = new Matrix4().compose(new Vector3((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), q, new Vector3(1, 1, 1));
  g.applyMatrix4(m);
  return flat(g, () => c);
}

function cone(r: number, h: number, seg: number, oy: number, top: number[], bot: number[]): BufferGeometry {
  const g = new ConeGeometry(r, h, seg, 2, true);
  const pos = g.getAttribute("position");
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i),
      y = pos.getY(i),
      z = pos.getZ(i);
    const a = Math.atan2(z, x);
    const wave = 1 + 0.12 * Math.sin(a * 5 + y * 2);
    pos.setXYZ(i, x * wave, y - 0.08 * Math.hypot(x, z), z * wave);
  }
  g.computeVertexNormals();
  g.translate(0, oy, 0);
  return flat(g, (y) => {
    const f = Math.max(0, Math.min(1, (y - (oy - h / 2)) / h));
    return [bot[0] + (top[0] - bot[0]) * f, bot[1] + (top[1] - bot[1]) * f, bot[2] + (top[2] - bot[2]) * f];
  });
}

const mg = (a: BufferGeometry[]) => mergeGeometries(a)!;

function geos(): [BufferGeometry, BufferGeometry][] {
  return [
    // 0: Oak / Maple broad-leaved tree with branches & layered canopy
    [
      mg([
        trunk(0.28, 0.16, 3.8, 8, BARK),
        branch(0, 2.6, 0, 1.2, 4.2, 0.5, 0.11, 0.06, BARK),
        branch(0, 2.8, 0, -1.0, 4.4, -0.7, 0.1, 0.05, BARK),
        blob(2.25, 2, 1.05, 0.88, 1.05, 0, 5.5, 0, LT, LB, 1),
        blob(1.75, 2, 1, 0.85, 1, 1.35, 4.5, 0.65, LT, LB, 2),
        blob(1.65, 2, 1, 0.85, 1, -1.15, 4.7, -0.8, LT, LB, 3),
        blob(1.45, 1, 1, 0.8, 1, -0.4, 6.4, 0.6, LT, LB, 19),
      ]),
      mg([trunk(0.26, 0.15, 3.6, 5, BARK), blob(2.85, 1, 1, 0.92, 1, 0, 5.2, 0, LT, LB, 4)]),
    ],
    // 1: Scots Pine (Sosna zwyczajna — Puszczy Dulowskiej / Chełmka)
    [
      mg([
        trunk(0.22, 0.11, 10.6, 7, PBARK),
        branch(0, 8.8, 0, 0.85, 9.8, 0.3, 0.08, 0.04, PBARK),
        blob(2.35, 2, 1.1, 0.52, 1.1, 0, 11.4, 0, PT, PB, 5),
        blob(1.7, 2, 1.05, 0.48, 1.05, 0.95, 9.9, 0.35, PT, PB, 6),
        blob(1.5, 1, 1, 0.46, 1, -0.85, 10.3, -0.45, PT, PB, 21),
      ]),
      mg([trunk(0.2, 0.11, 10.5, 4, PBARK), blob(2.55, 1, 1, 0.58, 1, 0, 11.1, 0, PT, PB, 7)]),
    ],
    // 2: Silver Birch (Brzoza brodawkowata)
    [
      mg([
        trunk(0.15, 0.07, 7.8, 7, WBARK),
        branch(0, 4.6, 0, 0.45, 5.9, 0.2, 0.06, 0.03, WBARK),
        blob(1.55, 2, 0.92, 1.5, 0.92, 0, 7.8, 0, BT, BB, 8),
        blob(1.15, 2, 0.9, 1.25, 0.9, 0.45, 5.9, 0.25, BT, BB, 9),
        blob(1.05, 1, 0.85, 1.2, 0.85, -0.4, 6.3, -0.3, BT, BB, 23),
      ]),
      mg([trunk(0.14, 0.07, 7.6, 4, WBARK), blob(1.75, 1, 0.9, 1.5, 0.9, 0, 7.3, 0, BT, BB, 10)]),
    ],
    // 3: Norway Spruce / Conifer (Świerk / Tuje ogrodowe)
    [
      mg([
        trunk(0.17, 0.1, 1.8, 6, BARK),
        cone(2.15, 3.2, 10, 2.8, ST, SB),
        cone(1.75, 2.9, 10, 4.5, ST, SB),
        cone(1.3, 2.6, 10, 6.1, ST, SB),
        cone(0.85, 2.2, 8, 7.5, ST, SB),
      ]),
      mg([trunk(0.16, 0.1, 1.6, 4, BARK), cone(2.05, 7.2, 7, 4.8, ST, SB)]),
    ],
    // 4: Multi-clustered Shrub / Garden Hedge Bush
    [
      mg([
        blob(0.95, 2, 1.25, 0.78, 1.25, 0, 0.62, 0, UT, UB, 11),
        blob(0.7, 1, 1.15, 0.72, 1.15, 0.55, 0.5, 0.3, UT, UB, 25),
      ]),
      blob(1, 1, 1.25, 0.75, 1.25, 0, 0.6, 0, UT, UB, 12),
    ],
    // 5: Jurassic Limestone Boulder (Skała wapienna)
    [
      blob(0.85, 2, 1.25, 0.72, 1.05, 0, 0.28, 0, RT, RB, 13),
      blob(0.85, 1, 1.25, 0.72, 1.05, 0, 0.28, 0, RT, RB, 14),
    ],
  ];
}

export function buildVegetation(w: any, t: Terrain, q: { near: number; far: number; density: number }) {
  const CS = 320,
    NT = 6,
    cells = new Map<number, number[][]>();
  const key = (x: number, z: number) => (Math.floor(x / CS) + 64) * 256 + Math.floor(z / CS) + 64;
  let count = 0;
  const add = (type: number, x: number, z: number, s: number) => {
    if (x < WORLD.x0 + 5 || x > WORLD.x1 - 5 || z < WORLD.z0 + 5 || z > WORLD.z1 - 5) return;
    const k = key(x, z);
    let c = cells.get(k);
    if (!c) {
      c = [];
      for (let i = 0; i < NT; i++) c.push([]);
      cells.set(k, c);
    }
    c[type].push(x, t.h(x, z) - 0.12, z, s, hash01(Math.round(x * 7), Math.round(z * 3), 5) * 6.283);
    count++;
  };

  const BAD: Record<number, number> = {
    [SF.BUILDING]: 1,
    [SF.ROAD]: 1,
    [SF.WALK]: 1,
    [SF.RAIL]: 1,
    [SF.DIRT]: 1,
    [SF.WATER]: 1,
    [SF.PARKING]: 1,
  };
  const NAT: Record<number, number> = {
    [SF.FOREST]: 1,
    [SF.MEADOW]: 1,
    [SF.FIELD]: 1,
    [SF.SCRUB]: 1,
    [SF.GRASS]: 1,
  };
  const clear = (x: number, z: number, d: number) =>
    !(BAD[t.surf(x + d, z)] || BAD[t.surf(x - d, z)] || BAD[t.surf(x, z + d)] || BAD[t.surf(x, z - d)]);

  const G2 = 6;
  for (let gz = WORLD.z0 + G2; gz < WORLD.z1 - G2; gz += G2)
    for (let gx = WORLD.x0 + G2; gx < WORLD.x1 - G2; gx += G2) {
      const x = gx + (hash01(gx, gz, 1) - 0.5) * G2 * 0.9,
        z = gz + (hash01(gx, gz, 2) - 0.5) * G2 * 0.9,
        s = t.surf(x, z);
      if (s === SF.FARM || s === SF.ROAD || s === SF.BUILDING || s === SF.WATER) continue;
      const r = hash01(gx, gz, 3),
        r2 = hash01(gx, gz, 4),
        r3 = hash01(gx, gz, 8),
        sc = 0.8 + 0.55 * hash01(gx, gz, 6);
      if (s === SF.FOREST) {
        if (r < 0.42 * q.density && clear(x, z, 2.5)) add(r2 < 0.62 ? 1 : r2 < 0.82 ? 2 : 0, x, z, sc);
        else if (r3 > 0.99) add(5, x, z, 0.6 + r2 * 1.2);
      } else if (s === SF.SCRUB) {
        if (r < 0.3) add(4, x, z, sc);
        else if (r < 0.38) add(2, x, z, sc * 0.8);
      } else if (s === SF.YARD) {
        if (r < 0.085 && clear(x, z, 3.5)) add(r2 < 0.38 ? 0 : r2 < 0.65 ? 3 : r2 < 0.8 ? 2 : 4, x, z, sc * 0.85);
      } else if (s === SF.PARK || s === SF.CEMETERY) {
        if (r < 0.18 && clear(x, z, 3)) add(r2 < 0.65 ? 0 : r2 < 0.85 ? 2 : 3, x, z, sc);
      } else if (s === SF.ALLOT) {
        if (r < 0.22 && clear(x, z, 2.5)) add(r2 < 0.6 ? 0 : 4, x, z, r2 < 0.6 ? 0.55 : 0.9);
      } else if (s === SF.WETLAND) {
        if (r < 0.11) add(r2 < 0.5 ? 4 : 0, x, z, sc * 0.78);
      } else if (s === SF.MEADOW || s === SF.FIELD || s === SF.GRASS) {
        if (r < 0.0075 && clear(x, z, 3)) add(r2 < 0.5 ? 0 : 4, x, z, sc);
        else if (r3 > 0.997) add(5, x, z, 0.5 + r2);
      }
      if (NAT[s] && r3 < 0.35) {
        const sl = Math.abs(t.h(x + 3, z) - t.h(x - 3, z)) + Math.abs(t.h(x, z + 3) - t.h(x, z - 3));
        if (sl > 1.8) add(5, x, z, 0.75 + r2 * 1.6);
      }
    }

  for (const pt of w.points) if (pt.k === "tree") add(pt.v === "needleleaved" ? 3 : 0, pt.x, pt.z, 1.05);
  for (const row of w.treeRows) {
    const rp = resample(row, 9);
    for (let i = 0; i < rp.length; i += 2) add(0, rp[i], rp[i + 1], 0.95);
  }

  const G22 = geos(),
    mat = new MeshStandardMaterial({ vertexColors: true, roughness: 0.86, metalness: 0.02 });
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = U.time;
    sh.uniforms.uWind = U.wind;
    sh.uniforms.uSunDir = U.sunDir;
    sh.vertexShader = sh.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
uniform float uTime;
uniform float uWind;
varying float vFoliageY;`
      )
      .replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
vFoliageY = clamp((position.y - 1.5) * 0.18, 0.0, 1.0);
#ifdef USE_INSTANCING
float wPh = uTime * 1.25 + instanceMatrix[3].x * 0.11 + instanceMatrix[3].z * 0.13;
float wK = max( 0.0, position.y - 1.2 ) * 0.045 * uWind;
transformed.x += ( sin( wPh ) + 0.35 * sin( wPh * 2.7 + position.y ) ) * wK;
transformed.z += ( cos( wPh * 0.83 ) + 0.3 * sin( wPh * 3.1 + position.x * 2.0 ) ) * wK * 0.8;
#endif`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
uniform vec3 uSunDir;
varying float vFoliageY;`
      )
      .replace(
        "#include <emissivemap_fragment>",
        `#include <emissivemap_fragment>
// UE5-style warm Subsurface Scattering (SSS) when foliage is backlit by the sun
vec3 viewDirW = normalize(vViewPosition);
float sss = pow(clamp(dot(viewDirW, uSunDir), 0.0, 1.0), 3.0) * vFoliageY;
totalEmissiveRadiance += diffuseColor.rgb * vec3(1.15, 0.95, 0.35) * (sss * 0.55);`
      );
  };
  mat.customProgramCacheKey = () => "veg_ue5";

  const group = new Group(),
    m4 = new Matrix4(),
    qt = new Quaternion(),
    ps = new Vector3(),
    sv = new Vector3(),
    up = new Vector3(0, 1, 0),
    col2 = new Color();
  const chunks: any[] = [];
  cells.forEach((c, k) => {
    const ck: any = {
      x: (Math.floor(k / 256) - 64 + 0.5) * CS,
      z: ((k % 256) - 64 + 0.5) * CS,
      near: [],
      far: [],
      n: [],
    };
    for (let ty = 0; ty < NT; ty++) {
      const a = c[ty],
        n = a.length / 5;
      if (!n) continue;
      const near = new InstancedMesh(G22[ty][0], mat, n),
        far = new InstancedMesh(G22[ty][1], mat, n);
      for (let i = 0; i < n; i++) {
        const o = i * 5;
        ps.set(a[o], a[o + 1], a[o + 2]);
        qt.setFromAxisAngle(up, a[o + 4]);
        sv.setScalar(a[o + 3]);
        m4.compose(ps, qt, sv);
        near.setMatrixAt(i, m4);
        far.setMatrixAt(i, m4);
        const v = 0.8 + 0.38 * hash01(i, ty, k);
        col2.setRGB(v * (0.94 + 0.14 * hash01(i, k, 7)), v * (0.94 + 0.12 * hash01(i, k, 9)), v * 0.88);
        near.setColorAt(i, col2);
        far.setColorAt(i, col2);
      }
      near.castShadow = true;
      near.receiveShadow = true;
      near.visible = false;
      near.computeBoundingSphere();
      far.computeBoundingSphere();
      group.add(near, far);
      ck.near.push(near);
      ck.far.push(far);
      ck.n.push(n);
    }
    chunks.push(ck);
  });

  const half = CS * 0.7071;
  const update = (cx: number, cz: number) => {
    for (const ck of chunks) {
      const d = Math.max(0, Math.hypot(ck.x - cx, ck.z - cz) - half),
        nearOn = d < q.near;
      for (let i = 0; i < ck.near.length; i++) {
        ck.near[i].visible = nearOn;
        const f = ck.far[i];
        f.visible = !nearOn;
        f.count = d < q.far ? ck.n[i] : Math.ceil(ck.n[i] / 3);
      }
    }
  };

  const SOLID = [0, 1, 2, 3, 5];
  const push = (x: number, z: number, r: number, out: number[]): boolean => {
    const c = cells.get(key(x, z));
    let hit = false;
    if (c)
      for (const ty of SOLID) {
        const a = c[ty],
          rad = ty === 5 ? 0.75 : 0.26;
        for (let o = 0; o < a.length; o += 5) {
          const dx = x - a[o],
            dz = z - a[o + 2];
          if (dx > 3.5 || dx < -3.5 || dz > 3.5 || dz < -3.5) continue;
          const rr = r + rad * a[o + 3],
            d2 = dx * dx + dz * dz;
          if (d2 < rr * rr && d2 > 1e-6) {
            const d = Math.sqrt(d2);
            x = a[o] + (dx / d) * rr;
            z = a[o + 2] + (dz / d) * rr;
            hit = true;
          }
        }
      }
    out[0] = x;
    out[1] = z;
    return hit;
  };

  return { group, count, update, push };
}
