export function hash01(a: number, b = 0, c = 0): number {
  let h = (Math.imul(a | 0, 374761393) ^ Math.imul(b | 0, 668265263) ^ Math.imul(c | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1103515245);
  h ^= h >>> 16;
  h = Math.imul(h, 2246822519);
  h ^= h >>> 13;
  return (h >>> 0) / 4294967296;
}

export function polyArea(p: number[]): number {
  let a = 0;
  const n = p.length;
  for (let i = 0; i < n; i += 2) {
    const j = (i + 2) % n;
    a += p[i] * p[j + 1] - p[j] * p[i + 1];
  }
  return a / 2;
}

export function polyCentroid(p: number[]): [number, number] {
  let a = 0,
    cx = 0,
    cz = 0;
  const n = p.length;
  for (let i = 0; i < n; i += 2) {
    const j = (i + 2) % n;
    const f = p[i] * p[j + 1] - p[j] * p[i + 1];
    a += f;
    cx += (p[i] + p[j]) * f;
    cz += (p[i + 1] + p[j + 1]) * f;
  }
  if (Math.abs(a) < 1e-6) {
    let sx = 0,
      sz = 0;
    for (let i = 0; i < n; i += 2) {
      sx += p[i];
      sz += p[i + 1];
    }
    return [sx / (n / 2), sz / (n / 2)];
  }
  return [cx / (3 * a), cz / (3 * a)];
}

export function pointInPoly(x: number, z: number, p: number[]): boolean {
  let c = false;
  const n = p.length;
  for (let i = 0, j = n - 2; i < n; j = i, i += 2) {
    const xi = p[i],
      zi = p[i + 1],
      xj = p[j],
      zj = p[j + 1];
    if (zi > z !== zj > z && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) c = !c;
  }
  return c;
}

export let segT = 0;
export function segDist(px: number, pz: number, ax: number, az: number, bx: number, bz: number): number {
  const dx = bx - ax,
    dz = bz - az;
  const l2 = dx * dx + dz * dz;
  let t = l2 > 0 ? ((px - ax) * dx + (pz - az) * dz) / l2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  segT = t;
  return Math.hypot(px - (ax + dx * t), pz - (az + dz * t));
}

export interface OBB {
  cx: number;
  cz: number;
  ux: number;
  uz: number;
  a: number;
  b: number;
  area: number;
}

export function obb(p: number[]): OBB {
  let best: OBB | null = null,
    bestArea = Infinity;
  const n = p.length;
  for (let i = 0; i < n; i += 2) {
    const j = (i + 2) % n;
    let ex = p[j] - p[i],
      ez = p[j + 1] - p[i + 1];
    const l = Math.hypot(ex, ez);
    if (l < 0.01) continue;
    ex /= l;
    ez /= l;
    let mnU = Infinity,
      mxU = -Infinity,
      mnV = Infinity,
      mxV = -Infinity;
    for (let k = 0; k < n; k += 2) {
      const u = p[k] * ex + p[k + 1] * ez,
        v = -p[k] * ez + p[k + 1] * ex;
      if (u < mnU) mnU = u;
      if (u > mxU) mxU = u;
      if (v < mnV) mnV = v;
      if (v > mxV) mxV = v;
    }
    const area2 = (mxU - mnU) * (mxV - mnV);
    if (area2 < bestArea) {
      bestArea = area2;
      const cu = (mnU + mxU) / 2,
        cv = (mnV + mxV) / 2;
      let a = (mxU - mnU) / 2,
        b = (mxV - mnV) / 2;
      let ux = ex,
        uz = ez;
      const cx = cu * ex - cv * ez,
        cz = cu * ez + cv * ex;
      if (b > a) {
        const t = a;
        a = b;
        b = t;
        const tx = ux;
        ux = -uz;
        uz = tx;
      }
      best = { cx, cz, ux, uz, a, b, area: area2 };
    }
  }
  return best || { cx: p[0], cz: p[1], ux: 1, uz: 0, a: 0.5, b: 0.5, area: 1 };
}

export function offsetPoly(p: number[], d: number): number[] {
  const n = p.length,
    out: number[] = [];
  for (let i = 0; i < n; i += 2) {
    const h = (i - 2 + n) % n,
      j = (i + 2) % n;
    let ax = p[i] - p[h],
      az = p[i + 1] - p[h + 1],
      bx = p[j] - p[i],
      bz = p[j + 1] - p[i + 1];
    const la = Math.hypot(ax, az) || 1,
      lb = Math.hypot(bx, bz) || 1;
    ax /= la;
    az /= la;
    bx /= lb;
    bz /= lb;
    const n1x = -az,
      n1z = ax,
      n2x = -bz,
      n2z = bx;
    let k = 1 + n1x * n2x + n1z * n2z;
    if (k < 0.35) k = 0.35;
    out.push(p[i] + (d * (n1x + n2x)) / k, p[i + 1] + (d * (n1z + n2z)) / k);
  }
  return out;
}

export function resample(p: number[], maxSeg: number): number[] {
  const out = [p[0], p[1]];
  for (let i = 2; i < p.length; i += 2) {
    const ax = p[i - 2],
      az = p[i - 1],
      bx = p[i],
      bz = p[i + 1];
    const l = Math.hypot(bx - ax, bz - az);
    const k = Math.max(1, Math.ceil(l / maxSeg));
    for (let s = 1; s <= k; s++) out.push(ax + ((bx - ax) * s) / k, az + ((bz - az) * s) / k);
  }
  return out;
}

export class SegGrid {
  cell: number;
  map = new Map<number, number[]>();
  s: number[] = [];
  nd = 0;
  nt = 0;
  constructor(cell: number) {
    this.cell = cell;
  }
  add(ax: number, az: number, bx: number, bz: number, id: number) {
    const idx = this.s.length / 5;
    this.s.push(ax, az, bx, bz, id);
    const c = this.cell;
    const i0 = Math.floor(Math.min(ax, bx) / c),
      i1 = Math.floor(Math.max(ax, bx) / c),
      j0 = Math.floor(Math.min(az, bz) / c),
      j1 = Math.floor(Math.max(az, bz) / c);
    for (let i = i0; i <= i1; i++)
      for (let j = j0; j <= j1; j++) {
        const k = (i + 32768) * 65536 + (j + 32768);
        let a = this.map.get(k);
        if (!a) {
          a = [];
          this.map.set(k, a);
        }
        a.push(idx);
      }
  }
  near(x: number, z: number, r: number, fn: (idx: number) => void) {
    const c = this.cell;
    const i0 = Math.floor((x - r) / c),
      i1 = Math.floor((x + r) / c),
      j0 = Math.floor((z - r) / c),
      j1 = Math.floor((z + r) / c);
    for (let i = i0; i <= i1; i++)
      for (let j = j0; j <= j1; j++) {
        const a = this.map.get((i + 32768) * 65536 + (j + 32768));
        if (a) for (let k = 0; k < a.length; k++) fn(a[k]);
      }
  }
  nearest(x: number, z: number, r: number): number {
    let best = -1,
      bd = r,
      bt = 0;
    const s = this.s;
    this.near(x, z, r, (idx) => {
      const o = idx * 5;
      const d = segDist(x, z, s[o], s[o + 1], s[o + 2], s[o + 3]);
      if (d < bd) {
        bd = d;
        best = idx;
        bt = segT;
      }
    });
    this.nd = bd;
    this.nt = bt;
    return best;
  }
}
