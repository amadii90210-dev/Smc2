import { TELEPORT_SPOTS, WORLD, xzToGps } from "./config";

export function makeUI(
  root: HTMLElement,
  input: any,
  mobile: boolean,
  world: any,
  onTeleport: (x: number, z: number, yaw?: number, label?: string) => void
) {
  const st = document.createElement("style");
  st.textContent = `
#ui{position:fixed;inset:0;pointer-events:none;z-index:10;color:#f3ead7;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
#ui>*{position:absolute}
#hud-loc{left:14px;top:12px;background:rgba(12,16,22,.76);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid rgba(243,234,215,.16);box-shadow:0 8px 24px rgba(0,0,0,.38);padding:9px 14px;border-radius:12px;max-width:56vw}
#hud-loc b{display:block;font-size:15px;letter-spacing:.03em;color:#f7efe0}
#hud-loc span{display:block;font-size:12px;color:#d6c7ad;margin-top:1px}
#hud-loc small{display:block;font-size:10px;color:#e2a04a;font-family:ui-monospace,monospace;margin-top:3px;opacity:.92}

#hud-speed{right:14px;top:12px;background:rgba(12,16,22,.76);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid rgba(243,234,215,.16);box-shadow:0 8px 24px rgba(0,0,0,.38);padding:7px 14px;border-radius:12px;text-align:right;min-width:92px}
#hud-speed b{font-size:27px;font-weight:800;letter-spacing:-.02em;color:#f7efe0}
#hud-speed span{font-size:11px;opacity:.75;margin-left:4px}
#hud-speed i{display:block;font-style:normal;font-size:11px;color:#e2a04a;font-weight:600}

#hud-gps{left:14px;top:92px;width:168px;background:rgba(12,16,22,.82);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid rgba(226,160,74,.38);box-shadow:0 10px 28px rgba(0,0,0,.45);border-radius:13px;padding:6px;pointer-events:auto;touch-action:manipulation;user-select:none}
#hud-gps-head{display:flex;align-items:center;justify-content:space-between;font-size:10px;font-weight:700;letter-spacing:.06em;color:#e2a04a;margin-bottom:4px;padding:0 2px}
#hud-gps-head button{background:rgba(226,160,74,.2);border:1px solid rgba(226,160,74,.45);color:#f7efe0;border-radius:6px;padding:2px 6px;font-size:10px;font-weight:700;cursor:pointer}
#hud-gps-head button:hover{background:rgba(226,160,74,.38)}
#hud-gps-cv{display:block;width:156px;height:126px;border-radius:8px;background:#111922;cursor:crosshair;border:1px solid rgba(255,255,255,.1)}
#hud-gps-foot{font-size:9.5px;color:#cbbba0;text-align:center;margin-top:4px;line-height:1.2}

#hud-hint{left:50%;bottom:20%;transform:translateX(-50%);background:rgba(226,160,74,.95);color:#12151b;font-weight:800;padding:9px 16px;border-radius:11px;font-size:14px;display:none;white-space:nowrap;box-shadow:0 6px 20px rgba(0,0,0,.4)}
#hud-toast{left:50%;top:14%;transform:translateX(-50%);background:rgba(12,16,22,.86);backdrop-filter:blur(8px);border:1px solid rgba(226,160,74,.35);padding:10px 18px;border-radius:12px;text-align:center;opacity:0;transition:opacity .3s;box-shadow:0 8px 24px rgba(0,0,0,.45)}
#hud-toast b{display:block;font-size:16px;color:#e2a04a}
#hud-keys{left:50%;bottom:10px;transform:translateX(-50%);font-size:12px;opacity:.88;background:rgba(12,16,22,.68);backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.12);padding:6px 12px;border-radius:9px;white-space:nowrap}

#joy{left:22px;bottom:24px;width:126px;height:126px;border-radius:50%;background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.32);pointer-events:auto;touch-action:none}
#knob{position:absolute;left:38px;top:38px;width:50px;height:50px;border-radius:50%;background:rgba(226,160,74,.88);box-shadow:0 4px 12px rgba(0,0,0,.4)}
#btns{right:14px;bottom:20px;display:grid;grid-template-columns:62px 62px;gap:9px;pointer-events:auto}
#btns button{width:62px;height:62px;border-radius:50%;border:2px solid rgba(255,255,255,.35);background:rgba(12,16,22,.65);color:#f3ead7;font-weight:800;font-size:12px;touch-action:none}
#btns button:active{background:rgba(226,160,74,.85);color:#12151b}

#gps-modal{position:fixed;inset:0;background:rgba(8,11,15,.82);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);display:none;align-items:center;justify-content:center;z-index:40;pointer-events:auto;padding:12px}
#gps-box{width:min(920px,96vw);max-height:92vh;background:#131922;border:1px solid rgba(226,160,74,.42);border-radius:16px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.65)}
#gps-top{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.1);background:#171f2b}
#gps-top h2{margin:0;font-size:16px;color:#e2a04a;letter-spacing:.03em}
#gps-top p{margin:2px 0 0;font-size:12px;color:#b8aa92}
#gps-close{background:#e2a04a;color:#12151b;border:0;border-radius:8px;padding:7px 14px;font-weight:800;font-size:13px;cursor:pointer}
#gps-body{display:grid;grid-template-columns:1fr 290px;gap:12px;padding:12px;overflow-y:auto}
#gps-map-wrap{position:relative;background:#0d131a;border-radius:12px;border:1px solid rgba(255,255,255,.12);overflow:hidden;min-height:340px;display:flex;align-items:center;justify-content:center}
#gps-full-cv{display:block;width:100%;height:auto;max-height:68vh;cursor:crosshair;touch-action:none}
#gps-list{display:flex;flex-direction:column;gap:6px;max-height:68vh;overflow-y:auto;padding-right:2px}
.gps-item{text-align:left;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:8px 10px;color:#f3ead7;cursor:pointer;transition:background .15s,border-color .15s}
.gps-item:hover{background:rgba(226,160,74,.18);border-color:#e2a04a}
.gps-item b{display:block;font-size:13px;color:#f7efe0}
.gps-item span{display:block;font-size:11px;color:#b8aa92;margin-top:2px}
@media (max-width:700px){
  #hud-gps{width:136px;top:84px;padding:5px}
  #hud-gps-cv{width:126px;height:96px}
  #gps-body{grid-template-columns:1fr}
  #gps-list{max-height:28vh}
}
`;
  document.head.appendChild(st);

  root.innerHTML =
    `<div id='hud-loc'><b id='hud-place'></b><span id='hud-street'></span><small id='hud-coords'></small></div>` +
    `<div id='hud-speed'><b id='hud-kmh'>0</b><span>km/h</span><i id='hud-veh'></i></div>` +
    `<div id='hud-gps'>` +
    `<div id='hud-gps-head'><span>GPS CHEŁMEK</span><button id='b-gps-open'>MAPA [M]</button></div>` +
    `<canvas id='hud-gps-cv' width='240' height='194' title='Kliknij na radarze GPS, aby teleportować się w wybrane miejsce'></canvas>` +
    `<div id='hud-gps-foot'>Kliknij radar lub MAPA, by teleportować</div>` +
    `</div>` +
    `<div id='hud-hint'></div><div id='hud-toast'></div>` +
    `<div id='gps-modal'>` +
    `<div id='gps-box'>` +
    `<div id='gps-top'><div><h2>NAWIGACJA GPS — CAŁA GMINA CHEŁMEK (32-660)</h2><p>Kliknij dowolny punkt na mapie (Chełmek, Gorzów, Bobrek) lub wybierz lokalizację z listy, aby przenieść się natychmiast</p></div><button id='gps-close'>ZAMKNIJ [ESC]</button></div>` +
    `<div id='gps-body'>` +
    `<div id='gps-map-wrap'><canvas id='gps-full-cv' width='640' height='820'></canvas></div>` +
    `<div id='gps-list'></div>` +
    `</div></div></div>` +
    (mobile
      ? `<div id='joy'><i id='knob'></i></div><div id='btns'><button id='b-time'>PORA</button><button id='b-cam'>CAM</button><button id='b-act'>E</button><button id='b-brake'>STOP</button><button id='b-gps-m'>GPS</button><button id='b-gas'>GAZ</button></div>`
      : `<div id='hud-keys'>WASD — ruch · Shift — bieg · Spacja — skok / hamulec · E — wsiądź / wysiądź / wieża · M — mapa GPS i teleport · C — kamera · T — pora dnia · P — efekty</div>`);

  const $2 = (id: string) => document.getElementById(id)!;
  const miniCv = $2("hud-gps-cv") as HTMLCanvasElement;
  const miniCtx = miniCv.getContext("2d")!;
  const fullCv = $2("gps-full-cv") as HTMLCanvasElement;
  const fullCtx = fullCv.getContext("2d")!;
  const modal = $2("gps-modal");
  const listEl = $2("gps-list");

  // Populate quick-teleport list across Gmina Chełmek
  TELEPORT_SPOTS.forEach((spot) => {
    const btn = document.createElement("button");
    btn.className = "gps-item";
    btn.innerHTML = `<b>${spot.name}</b><span>${spot.sub}</span>`;
    btn.addEventListener("click", () => {
      modal.style.display = "none";
      onTeleport(spot.x, spot.z, spot.yaw, spot.name);
    });
    listEl.appendChild(btn);
  });

  // Pre-render static overview map of the entire Gmina Chełmek onto an offscreen canvas
  const offCv = document.createElement("canvas");
  offCv.width = 640;
  offCv.height = 820;
  const octx = offCv.getContext("2d")!;
  const wx0 = WORLD.x0,
    wx1 = WORLD.x1,
    wz0 = WORLD.z0,
    wz1 = WORLD.z1;
  const toMapX = (x: number) => ((x - wx0) / (wx1 - wx0)) * offCv.width;
  const toMapY = (z: number) => ((z - wz0) / (wz1 - wz0)) * offCv.height;
  const fromMapX = (px: number) => wx0 + (px / offCv.width) * (wx1 - wx0);
  const fromMapY = (py: number) => wz0 + (py / offCv.height) * (wz1 - wz0);

  function renderStaticBaseMap() {
    octx.fillStyle = "#162219";
    octx.fillRect(0, 0, offCv.width, offCv.height);

    // Draw forests, parks, water bodies
    for (const a of world.areas || []) {
      const p = a.p;
      if (!p || p.length < 6) continue;
      if (a.k === "forest" || a.k === "scrub") octx.fillStyle = "#1d3320";
      else if (a.k === "park" || a.k === "meadow" || a.k === "grass") octx.fillStyle = "#243d24";
      else if (a.k === "water") octx.fillStyle = "#164e63";
      else if (a.k === "industrial" || a.k === "residential") octx.fillStyle = "#252930";
      else continue;
      octx.beginPath();
      octx.moveTo(toMapX(p[0]), toMapY(p[1]));
      for (let i = 2; i < p.length; i += 2) octx.lineTo(toMapX(p[i]), toMapY(p[i + 1]));
      octx.closePath();
      octx.fill();
    }

    // Rivers & streams (Przemsza, Wisła)
    octx.strokeStyle = "#1d6fa5";
    octx.lineWidth = 2.2;
    for (const s of world.streams || []) {
      const p = s.p;
      if (!p || p.length < 4) continue;
      octx.beginPath();
      octx.moveTo(toMapX(p[0]), toMapY(p[1]));
      for (let i = 2; i < p.length; i += 2) octx.lineTo(toMapX(p[i]), toMapY(p[i + 1]));
      octx.stroke();
    }

    // Roads
    for (const r of world.roads || []) {
      const p = r.p;
      if (!p || p.length < 4) continue;
      const major = r.k === "secondary" || r.k === "primary" || r.k === "tertiary";
      octx.strokeStyle = major ? "#d99b43" : "rgba(210,205,195,0.42)";
      octx.lineWidth = major ? 1.8 : 0.8;
      octx.beginPath();
      octx.moveTo(toMapX(p[0]), toMapY(p[1]));
      for (let i = 2; i < p.length; i += 2) octx.lineTo(toMapX(p[i]), toMapY(p[i + 1]));
      octx.stroke();
    }

    // Railway lines
    octx.strokeStyle = "#a855f7";
    octx.lineWidth = 1.6;
    octx.setLineDash([4, 3]);
    for (const rl of world.rails || []) {
      const p = rl.p;
      if (!p || p.length < 4) continue;
      octx.beginPath();
      octx.moveTo(toMapX(p[0]), toMapY(p[1]));
      for (let i = 2; i < p.length; i += 2) octx.lineTo(toMapX(p[i]), toMapY(p[i + 1]));
      octx.stroke();
    }
    octx.setLineDash([]);

    // Buildings
    octx.fillStyle = "rgba(235,220,195,0.65)";
    for (const b of world.buildings || []) {
      const p = b.p;
      if (!p || p.length < 6) continue;
      octx.fillRect(toMapX(p[0]) - 1, toMapY(p[1]) - 1, 2.2, 2.2);
    }

    // District & village names
    octx.font = "bold 12px system-ui, sans-serif";
    octx.textAlign = "center";
    const labels = [
      { n: "CHEŁMEK", x: 0, z: -20, col: "#fbbf24" },
      { n: "WZGÓRZE SKAŁA", x: -1050, z: 30, col: "#fde68a" },
      { n: "KOLONIA BATA", x: -180, z: -80, col: "#fde68a" },
      { n: "NOWOPOLE", x: 940, z: 120, col: "#e2e8f0" },
      { n: "PAPROTNIK", x: 1310, z: -80, col: "#e2e8f0" },
      { n: "STAWY CHEŁMEK", x: -250, z: -1200, col: "#7dd3fc" },
      { n: "ZBIORNIK DZIEĆKOWICE", x: -1550, z: -2850, col: "#7dd3fc" },
      { n: "SOŁECTWO GORZÓW", x: -1350, z: 2260, col: "#fbbf24" },
      { n: "SOŁECTWO BOBREK", x: -150, z: 3750, col: "#fbbf24" },
      { n: "PARK ZAMKOWY BOBREK", x: 420, z: 3420, col: "#86efac" },
    ];
    for (const lb of labels) {
      const lx = toMapX(lb.x),
        ly = toMapY(lb.z);
      octx.fillStyle = "rgba(0,0,0,0.72)";
      octx.fillText(lb.n, lx + 1, ly + 1);
      octx.fillStyle = lb.col;
      octx.fillText(lb.n, lx, ly);
    }
  }
  renderStaticBaseMap();

  let curPx = 0,
    curPz = 0,
    curYaw = 0;

  function drawFullMap() {
    fullCtx.drawImage(offCv, 0, 0);
    // Draw teleport spots
    for (const sp of TELEPORT_SPOTS) {
      const sx = toMapX(sp.x),
        sy = toMapY(sp.z);
      fullCtx.fillStyle = "#e2a04a";
      fullCtx.beginPath();
      fullCtx.arc(sx, sy, 5, 0, Math.PI * 2);
      fullCtx.fill();
      fullCtx.strokeStyle = "#12151b";
      fullCtx.lineWidth = 1.5;
      fullCtx.stroke();
    }
    // Draw player arrow
    const px = toMapX(curPx),
      py = toMapY(curPz);
    fullCtx.save();
    fullCtx.translate(px, py);
    fullCtx.rotate(-curYaw + Math.PI);
    fullCtx.fillStyle = "#22c55e";
    fullCtx.strokeStyle = "#ffffff";
    fullCtx.lineWidth = 2;
    fullCtx.beginPath();
    fullCtx.moveTo(0, -9);
    fullCtx.lineTo(6.5, 7);
    fullCtx.lineTo(0, 3.5);
    fullCtx.lineTo(-6.5, 7);
    fullCtx.closePath();
    fullCtx.fill();
    fullCtx.stroke();
    fullCtx.restore();
  }

  function openGpsModal() {
    modal.style.display = "flex";
    drawFullMap();
  }
  function closeGpsModal() {
    modal.style.display = "none";
  }

  $2("b-gps-open").addEventListener("pointerdown", (e) => {
    e.stopPropagation();
    openGpsModal();
  });
  $2("gps-close").addEventListener("click", () => closeGpsModal());
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeGpsModal();
  });
  window.addEventListener("keydown", (e) => {
    if (e.code === "KeyM") {
      if (modal.style.display === "flex") closeGpsModal();
      else openGpsModal();
    } else if (e.code === "Escape" && modal.style.display === "flex") {
      closeGpsModal();
    }
  });

  // Click anywhere on full Gmina Chełmek map canvas to teleport
  fullCv.addEventListener("pointerdown", (e) => {
    const r = fullCv.getBoundingClientRect();
    const cx = ((e.clientX - r.left) / r.width) * offCv.width;
    const cy = ((e.clientY - r.top) / r.height) * offCv.height;
    const tx = Math.max(WORLD.x0 + 25, Math.min(WORLD.x1 - 25, fromMapX(cx)));
    const tz = Math.max(WORLD.z0 + 25, Math.min(WORLD.z1 - 25, fromMapY(cy)));
    closeGpsModal();
    onTeleport(tx, tz, undefined, "Punkt GPS na mapie");
  });

  // Click directly on corner GPS radar to teleport within local area (range ±420m)
  const RADAR_RANGE = 420;
  miniCv.addEventListener("pointerdown", (e) => {
    e.stopPropagation();
    const r = miniCv.getBoundingClientRect();
    const nx = (e.clientX - r.left) / r.width - 0.5;
    const nz = (e.clientY - r.top) / r.height - 0.5;
    const tx = Math.max(WORLD.x0 + 25, Math.min(WORLD.x1 - 25, curPx + nx * RADAR_RANGE * 2));
    const tz = Math.max(WORLD.z0 + 25, Math.min(WORLD.z1 - 25, curPz + nz * RADAR_RANGE * 2));
    onTeleport(tx, tz, undefined, "Teleport z radaru GPS");
  });

  if (mobile) {
    const joy = $2("joy"),
      knob = $2("knob");
    let jid = -1;
    const mv = (e: PointerEvent) => {
      const r = joy.getBoundingClientRect();
      let dx = e.clientX - (r.left + r.width / 2),
        dy = e.clientY - (r.top + r.height / 2);
      const l = Math.hypot(dx, dy),
        m = 46;
      if (l > m) {
        dx *= m / l;
        dy *= m / l;
      }
      knob.style.transform = "translate(" + dx + "px," + dy + "px)";
      input.mx = dx / m;
      input.my = -dy / m;
    };
    joy.addEventListener("pointerdown", (e) => {
      jid = e.pointerId;
      joy.setPointerCapture(jid);
      mv(e);
      e.preventDefault();
    });
    joy.addEventListener("pointermove", (e) => {
      if (e.pointerId === jid) mv(e);
    });
    const end = (e: PointerEvent) => {
      if (e.pointerId !== jid) return;
      jid = -1;
      input.mx = 0;
      input.my = 0;
      knob.style.transform = "";
    };
    joy.addEventListener("pointerup", end);
    joy.addEventListener("pointercancel", end);
    const hold = (id: string, k: string) => {
      const b = $2(id);
      const up = () => {
        input[k] = 0;
      };
      b.addEventListener("pointerdown", (e) => {
        input[k] = 1;
        e.preventDefault();
      });
      b.addEventListener("pointerup", up);
      b.addEventListener("pointercancel", up);
      b.addEventListener("pointerleave", up);
    };
    hold("b-gas", "gas");
    hold("b-brake", "brake");
    const tap = (id: string, k: string) =>
      $2(id).addEventListener("pointerdown", (e) => {
        input[k] = true;
        e.preventDefault();
      });
    tap("b-act", "act");
    tap("b-cam", "camNext");
    tap("b-time", "timeNext");
    $2("b-gps-m").addEventListener("pointerdown", (e) => {
      e.preventDefault();
      openGpsModal();
    });
  }

  const last: Record<string, string> = {};
  let tt = 0;
  const put = (id: string, v: string) => {
    if (last[id] !== v) {
      last[id] = v;
      $2(id).textContent = v;
    }
  };

  function drawCornerRadar(px: number, pz: number, yaw: number, vehs: any[]) {
    curPx = px;
    curPz = pz;
    curYaw = yaw;
    const W = miniCv.width,
      H = miniCv.height;
    // Crop corresponding region from pre-rendered offscreen base map
    const sx = toMapX(px - RADAR_RANGE),
      sy = toMapY(pz - RADAR_RANGE);
    const sw = (RADAR_RANGE * 2 * offCv.width) / (wx1 - wx0),
      sh = (RADAR_RANGE * 2 * offCv.height) / (wz1 - wz0);
    miniCtx.fillStyle = "#111922";
    miniCtx.fillRect(0, 0, W, H);
    miniCtx.drawImage(offCv, sx, sy, sw, sh, 0, 0, W, H);

    // Radar grid rings
    miniCtx.strokeStyle = "rgba(226,160,74,0.18)";
    miniCtx.lineWidth = 1;
    miniCtx.beginPath();
    miniCtx.arc(W / 2, H / 2, W * 0.32, 0, Math.PI * 2);
    miniCtx.stroke();

    // Nearby vehicles
    miniCtx.fillStyle = "#38bdf8";
    for (const v of vehs) {
      const vx = ((v.x - px) / (RADAR_RANGE * 2) + 0.5) * W;
      const vz = ((v.z - pz) / (RADAR_RANGE * 2) + 0.5) * H;
      if (vx >= 2 && vx <= W - 2 && vz >= 2 && vz <= H - 2) {
        miniCtx.fillRect(vx - 2.5, vz - 2.5, 5, 5);
      }
    }

    // View cone & Player arrow at center
    miniCtx.save();
    miniCtx.translate(W / 2, H / 2);
    miniCtx.rotate(Math.atan2(Math.sin(yaw), Math.cos(yaw)));
    miniCtx.fillStyle = "rgba(226,160,74,0.22)";
    miniCtx.beginPath();
    miniCtx.moveTo(0, 0);
    miniCtx.arc(0, 0, 34, Math.PI * 0.3, Math.PI * 0.7);
    miniCtx.closePath();
    miniCtx.fill();

    miniCtx.fillStyle = "#22c55e";
    miniCtx.strokeStyle = "#ffffff";
    miniCtx.lineWidth = 1.5;
    miniCtx.beginPath();
    miniCtx.moveTo(0, 7);
    miniCtx.lineTo(-5, -6);
    miniCtx.lineTo(0, -3);
    miniCtx.lineTo(5, -6);
    miniCtx.closePath();
    miniCtx.fill();
    miniCtx.stroke();
    miniCtx.restore();
  }

  return {
    set(
      place: string,
      street: string,
      kmh: number,
      veh: string,
      hint: string,
      px: number,
      py: number,
      pz: number,
      yaw: number,
      vehs: any[]
    ) {
      put("hud-place", place);
      put("hud-street", street || "Gmina Chełmek (32-660)");
      const gps = xzToGps(px, pz);
      put(
        "hud-coords",
        `GPS: ${gps.lat.toFixed(4)}°N, ${gps.lon.toFixed(4)}°E · ${Math.round(py)} m n.p.m.`
      );
      put("hud-kmh", String(kmh));
      put("hud-veh", veh);
      if (last.hint !== hint) {
        last.hint = hint;
        const h = $2("hud-hint");
        h.textContent = hint;
        h.style.display = hint ? "block" : "none";
      }
      drawCornerRadar(px, pz, yaw, vehs);
    },
    toast(t: string, s: string) {
      const el = $2("hud-toast");
      el.innerHTML = "";
      const b = document.createElement("b");
      b.textContent = t;
      el.appendChild(b);
      el.appendChild(document.createTextNode(s));
      el.style.opacity = "1";
      clearTimeout(tt);
      tt = window.setTimeout(() => {
        el.style.opacity = "0";
      }, 2600);
    },
  };
}
