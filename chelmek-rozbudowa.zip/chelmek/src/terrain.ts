import {
  BufferAttribute,
  BufferGeometry,
  DataTexture,
  DataUtils,
  Float32BufferAttribute,
  Group,
  LinearFilter,
  LinearMipmapLinearFilter,
  Mesh,
  MeshStandardMaterial,
  RedFormat,
  RGBAFormat,
  ShapeUtils,
  SRGBColorSpace,
  HalfFloatType,
  Vector2,
  Vector4,
} from "three";
import { WORLD } from "./config";
import { U } from "./env";
import { hash01, polyArea, segDist } from "./geo";

export const SF = {
  FIELD: 0,
  FARM: 1,
  MEADOW: 2,
  GRASS: 3,
  FOREST: 4,
  SCRUB: 5,
  YARD: 6,
  PAVED: 7,
  PARK: 8,
  CEMETERY: 9,
  ALLOT: 10,
  PITCH: 11,
  SAND: 12,
  WETLAND: 13,
  WATER: 14,
  ROAD: 15,
  WALK: 16,
  PARKING: 17,
  BUILDING: 18,
  RAIL: 19,
  DIRT: 20,
  PLAY: 21,
} as const;

const KIND: Record<string, number> = {
  forest: 4,
  meadow: 2,
  residential: 6,
  parking: 17,
  scrub: 5,
  wetland: 13,
  grass: 3,
  farm: 1,
  playground: 21,
  pitch: 11,
  industrial: 7,
  paved: 7,
  park: 8,
  institution: 3,
  commercial: 7,
  sand: 12,
  rock: 20,
  railway: 19,
  cemetery: 9,
  allotments: 10,
  farmyard: 20,
  flowerbed: 3,
  orchard: 10,
  dirt: 20,
  sports: 3,
  pedestrian: 16,
  platform: 16,
};

// Rich, natural European / Polish landscape palette (realistic chlorophyll & soil tones)
const COL: number[][] = [
  [108, 134, 68],  // FIELD
  [138, 126, 78],  // FARM (plowed / Golden wheat stubble)
  [98, 136, 62],   // MEADOW
  [88, 132, 58],   // GRASS
  [50, 74, 38],    // FOREST (deep humus & moss floor)
  [78, 108, 52],   // SCRUB
  [94, 132, 66],   // YARD (homestead lawn)
  [136, 134, 128], // PAVED
  [82, 130, 56],   // PARK
  [96, 124, 74],   // CEMETERY
  [92, 128, 62],   // ALLOT (allotment gardens)
  [72, 142, 64],   // PITCH (sport turf)
  [196, 178, 132], // SAND
  [78, 108, 72],   // WETLAND
  [64, 78, 68],    // WATER bed
  [72, 74, 78],    // ROAD
  [144, 142, 136], // WALK
  [78, 80, 84],    // PARKING
  [112, 110, 104], // BUILDING
  [106, 98, 90],   // RAIL ballast
  [128, 110, 84],  // DIRT
  [172, 142, 98],  // PLAY (playground sand/tartans)
];

const GRASSW = [255, 45, 255, 240, 165, 210, 225, 0, 240, 200, 220, 40, 0, 235, 0, 0, 0, 0, 0, 0, 0, 0];
const NAMP = [0.38, 0.14, 0.38, 0.16, 0.58, 0.48, 0.04, 0, 0.14, 0, 0.06, 0, 0.22, 0.28, 0, 0, 0, 0, 0, 0, 0.08, 0];

function vnoise(x: number, z: number, seed: number): number {
  const xi = Math.floor(x),
    zi = Math.floor(z),
    tx = x - xi,
    tz = z - zi,
    sx = tx * tx * (3 - 2 * tx),
    sz = tz * tz * (3 - 2 * tz);
  const a = hash01(xi, zi, seed),
    b = hash01(xi + 1, zi, seed),
    c = hash01(xi, zi + 1, seed),
    d = hash01(xi + 1, zi + 1, seed);
  return (a + (b - a) * sx) * (1 - sz) + (c + (d - c) * sx) * sz;
}

export class Terrain {
  x0 = WORLD.x0;
  z0 = WORLD.z0;
  cell = 10;
  nx: number;
  nz: number;
  hU: Float32Array;
  hC: Float32Array;
  hBase = 0;
  mc = 3;
  mw: number;
  mh: number;
  mask: Uint8Array;
  waters: { p: number[]; holes?: number[][]; level: number }[] = [];

  constructor(w: any) {
    this.nx = Math.round((WORLD.x1 - WORLD.x0) / this.cell) + 1;
    this.nz = Math.round((WORLD.z1 - WORLD.z0) / this.cell) + 1;
    this.hU = new Float32Array(this.nx * this.nz);
    const d = w.dem;
    for (let j = 0; j < this.nz; j++)
      for (let i = 0; i < this.nx; i++) {
        let fx = (this.x0 + i * this.cell - d.x0) / d.cell,
          fz = (this.z0 + j * this.cell - d.z0) / d.cell;
        fx = Math.max(0, Math.min(d.nx - 1.001, fx));
        fz = Math.max(0, Math.min(d.nz - 1.001, fz));
        const a = fx | 0,
          b = fz | 0,
          tx = fx - a,
          tz = fz - b,
          o = b * d.nx + a;
        this.hU[j * this.nx + i] =
          (d.h[o] * (1 - tx) + d.h[o + 1] * tx) * (1 - tz) +
          (d.h[o + d.nx] * (1 - tx) + d.h[o + d.nx + 1] * tx) * tz;
      }
    this.hC = new Float32Array(this.hU);
    this.mw = Math.ceil((WORLD.x1 - WORLD.x0) / this.mc);
    this.mh = Math.ceil((WORLD.z1 - WORLD.z0) / this.mc);
    this.mask = new Uint8Array(this.mw * this.mh);
  }

  raster(
    p: number[],
    holes: number[][] | undefined,
    c: number,
    nw: number,
    nh: number,
    off: number,
    fn: (idx: number) => void
  ) {
    let zmin = Infinity,
      zmax = -Infinity;
    for (let i = 1; i < p.length; i += 2) {
      if (p[i] < zmin) zmin = p[i];
      if (p[i] > zmax) zmax = p[i];
    }
    const j0 = Math.max(0, Math.ceil((zmin - this.z0) / c - off)),
      j1 = Math.min(nh - 1, Math.floor((zmax - this.z0) / c - off));
    const rings = holes ? [p, ...holes] : [p];
    const xs: number[] = [];
    for (let j = j0; j <= j1; j++) {
      const z = this.z0 + (j + off) * c;
      xs.length = 0;
      for (const q of rings) {
        const n = q.length;
        for (let i = 0, k = n - 2; i < n; k = i, i += 2) {
          const za = q[k + 1],
            zb = q[i + 1];
          if (za > z !== zb > z) xs.push(q[k] + ((z - za) / (zb - za)) * (q[i] - q[k]));
        }
      }
      xs.sort((a, b) => a - b);
      for (let s = 0; s + 1 < xs.length; s += 2) {
        const i0 = Math.max(0, Math.ceil((xs[s] - this.x0) / c - off)),
          i1 = Math.min(nw - 1, Math.floor((xs[s + 1] - this.x0) / c - off));
        for (let i = i0; i <= i1; i++) fn(j * nw + i);
      }
    }
  }

  strokeCells(p: number[], half: number, c: number, nw: number, nh: number, off: number, fn: (idx: number) => void) {
    for (let s = 0; s + 3 < p.length; s += 2) {
      const ax = p[s],
        az = p[s + 1],
        bx = p[s + 2],
        bz = p[s + 3];
      const i0 = Math.max(0, Math.floor((Math.min(ax, bx) - half - this.x0) / c)),
        i1 = Math.min(nw - 1, Math.ceil((Math.max(ax, bx) + half - this.x0) / c));
      const j0 = Math.max(0, Math.floor((Math.min(az, bz) - half - this.z0) / c)),
        j1 = Math.min(nh - 1, Math.ceil((Math.max(az, bz) + half - this.z0) / c));
      for (let j = j0; j <= j1; j++)
        for (let i = i0; i <= i1; i++)
          if (segDist(this.x0 + (i + off) * c, this.z0 + (j + off) * c, ax, az, bx, bz) <= half) fn(j * nw + i);
    }
  }

  buildMask(w: any, strokes: any[]) {
    const m = this.mask,
      c = this.mc,
      nw = this.mw,
      nh = this.mh;
    const areas = w.areas
      .filter((a: any) => a.k !== "water")
      .map((a: any) => ({ a, s: Math.abs(polyArea(a.p)) }))
      .sort((x: any, y: any) => y.s - x.s);
    for (const it of areas) {
      const v = KIND[it.a.k];
      if (v === undefined) continue;
      this.raster(it.a.p, it.a.holes, c, nw, nh, 0.5, (i) => {
        m[i] = v;
      });
    }
    for (const a of w.areas)
      if (a.k === "water")
        this.raster(a.p, a.holes, c, nw, nh, 0.5, (i) => {
          m[i] = SF.WATER;
        });
    for (const s of strokes)
      this.strokeCells(s.p, Math.max(s.half, 1.5), c, nw, nh, 0.5, (i) => {
        m[i] = s.val;
      });
    for (const b of w.buildings)
      this.raster(b.p, b.holes, c, nw, nh, 0.5, (i) => {
        m[i] = SF.BUILDING;
      });
  }

  carve(w: any, strokes: any[]) {
    const nx = this.nx,
      nz = this.nz,
      c = this.cell;
    const bed = new Float32Array(nx * nz).fill(1e9);
    const prot = new Uint8Array(nx * nz);
    for (const s of strokes)
      if (!s.bridge)
        this.strokeCells(s.p, s.half + 15, c, nx, nz, 0, (i) => {
          prot[i] = 1;
        });
    const np = new Uint8Array(prot);
    for (const b of w.buildings)
      this.strokeCells(b.p.concat([b.p[0], b.p[1]]), 14, c, nx, nz, 0, (i) => {
        np[i] = 1;
      });

    // Natural micro-topography + Wzgórze Skała limestone crags
    for (let j = 0; j < nz; j++)
      for (let i = 0; i < nx; i++) {
        const idx = j * nx + i;
        if (np[idx]) continue;
        const x = this.x0 + i * c,
          z = this.z0 + j * c,
          amp = NAMP[this.surf(x, z)] || 0;
        if (!amp) continue;
        // Extra limestone ridge relief on Wzgórze Skała (-1050, 55)
        const dSkala = Math.hypot(x - -1050, z - 55);
        const skalaBoost = dSkala < 280 ? (1 - dSkala / 280) * 1.15 : 0;
        const n =
          ((vnoise(x / 80, z / 80, 41) - 0.5) * 2 + (vnoise(x / 28, z / 28, 42) - 0.5)) * (amp + skalaBoost);
        this.hU[idx] += n;
        this.hC[idx] += n;
      }

    // Elevated Railway Embankment (podwyższenie terenu pod torami kolejowymi w Chełmku i Gorzowie)
    const railRaise = new Float32Array(nx * nz);
    const lcs = (w.points || []).filter((p: any) => p.k === "level_crossing");
    for (const rl of w.rails || []) {
      if (rl.br) continue;
      const p = rl.p;
      for (let s = 0; s + 3 < p.length; s += 2) {
        const ax = p[s],
          az = p[s + 1],
          bx = p[s + 2],
          bz = p[s + 3];
        const half = 12;
        const i0 = Math.max(0, Math.floor((Math.min(ax, bx) - half - this.x0) / c)),
          i1 = Math.min(nx - 1, Math.ceil((Math.max(ax, bx) + half - this.x0) / c));
        const j0 = Math.max(0, Math.floor((Math.min(az, bz) - half - this.z0) / c)),
          j1 = Math.min(nz - 1, Math.ceil((Math.max(az, bz) + half - this.z0) / c));
        for (let j = j0; j <= j1; j++)
          for (let i = i0; i <= i1; i++) {
            const gx = this.x0 + i * c,
              gz = this.z0 + j * c;
            const d = segDist(gx, gz, ax, az, bx, bz);
            if (d <= half) {
              // Taper near level crossings so roads cross smoothly
              let lcFactor = 1;
              for (const lc of lcs) {
                const dl = Math.hypot(gx - lc.x, gz - lc.z);
                if (dl < 32) lcFactor = Math.min(lcFactor, Math.max(0.15, dl / 32));
              }
              const profile = d < 3.5 ? 1 : Math.max(0, 1 - (d - 3.5) / (half - 3.5));
              const lift = 1.15 * profile * lcFactor;
              const idx = j * nx + i;
              if (lift > railRaise[idx]) railRaise[idx] = lift;
            }
          }
      }
    }
    for (let i = 0; i < railRaise.length; i++) {
      if (railRaise[i] > 0) {
        this.hU[i] += railRaise[i];
        this.hC[i] += railRaise[i];
      }
    }

    // Carve water bodies (Przemsza, Wisła, Staw Oko, Koło, Gruszka, Zbiornik Dziećkowice)
    for (const a of w.areas) {
      if (a.k !== "water") continue;
      let mn2 = Infinity;
      for (let i = 0; i < a.p.length; i += 2) {
        const h = this.hu(a.p[i], a.p[i + 1]);
        if (h < mn2) mn2 = h;
      }
      const level = mn2 - 0.15;
      this.waters.push({ p: a.p, holes: a.holes, level });
      this.raster(a.p, a.holes, c, nx, nz, 0, (i) => {
        if (level - 1.45 < bed[i]) bed[i] = level - 1.45;
      });
    }
    for (let i = 0; i < bed.length; i++) if (bed[i] < 1e8 && !prot[i] && bed[i] < this.hC[i]) this.hC[i] = bed[i];
    let mn = 1e9;
    for (let i = 0; i < this.hC.length; i++) if (this.hC[i] < mn) mn = this.hC[i];
    this.hBase = mn;
  }

  tri(h: Float32Array, x: number, z: number): number {
    let fx = (x - this.x0) / this.cell,
      fz = (z - this.z0) / this.cell;
    if (fx < 0) fx = 0;
    else if (fx > this.nx - 1.001) fx = this.nx - 1.001;
    if (fz < 0) fz = 0;
    else if (fz > this.nz - 1.001) fz = this.nz - 1.001;
    const i = fx | 0,
      j = fz | 0,
      tx = fx - i,
      tz = fz - j,
      o = j * this.nx + i;
    const h00 = h[o],
      h10 = h[o + 1],
      h01 = h[o + this.nx],
      h11 = h[o + this.nx + 1];
    return tx + tz <= 1
      ? h00 + (h10 - h00) * tx + (h01 - h00) * tz
      : h11 + (h01 - h11) * (1 - tx) + (h10 - h11) * (1 - tz);
  }

  h(x: number, z: number): number {
    return this.tri(this.hC, x, z);
  }
  hu(x: number, z: number): number {
    return this.tri(this.hU, x, z);
  }
  surf(x: number, z: number): number {
    const i = Math.floor((x - this.x0) / this.mc),
      j = Math.floor((z - this.z0) / this.mc);
    return i < 0 || j < 0 || i >= this.mw || j >= this.mh ? 0 : this.mask[j * this.mw + i];
  }

  meshes(mat: MeshStandardMaterial): Group {
    const CH = 64,
      g = new Group(),
      nx = this.nx,
      nz = this.nz,
      c = this.cell,
      H = this.hC;
    for (let cj = 0; cj < nz - 1; cj += CH)
      for (let ci = 0; ci < nx - 1; ci += CH) {
        const w = Math.min(CH, nx - 1 - ci),
          d = Math.min(CH, nz - 1 - cj),
          W = w + 1;
        const pos = new Float32Array(W * (d + 1) * 3),
          nor = new Float32Array(pos.length),
          idx = new Uint16Array(w * d * 6);
        let k = 0;
        for (let j = 0; j <= d; j++)
          for (let i = 0; i <= w; i++) {
            const gi = ci + i,
              gj = cj + j;
            pos[k] = this.x0 + gi * c;
            pos[k + 1] = H[gj * nx + gi];
            pos[k + 2] = this.z0 + gj * c;
            const hl = H[gj * nx + Math.max(0, gi - 1)],
              hr = H[gj * nx + Math.min(nx - 1, gi + 1)],
              hd = H[Math.max(0, gj - 1) * nx + gi],
              hu = H[Math.min(nz - 1, gj + 1) * nx + gi];
            const ax = hl - hr,
              ay = 2 * c,
              az = hd - hu,
              l = Math.hypot(ax, ay, az);
            nor[k] = ax / l;
            nor[k + 1] = ay / l;
            nor[k + 2] = az / l;
            k += 3;
          }
        let q = 0;
        for (let j = 0; j < d; j++)
          for (let i = 0; i < w; i++) {
            const a = j * W + i,
              b = a + 1,
              e = a + W,
              f = e + 1;
            idx[q++] = a;
            idx[q++] = e;
            idx[q++] = b;
            idx[q++] = b;
            idx[q++] = e;
            idx[q++] = f;
          }
        const geo = new BufferGeometry();
        geo.setAttribute("position", new BufferAttribute(pos, 3));
        geo.setAttribute("normal", new BufferAttribute(nor, 3));
        geo.setIndex(new BufferAttribute(idx, 1));
        geo.computeBoundingSphere();
        const mesh = new Mesh(geo, mat);
        mesh.receiveShadow = true;
        g.add(mesh);
      }
    return g;
  }

  groundTexture(): DataTexture {
    const n = this.mw * this.mh,
      d = new Uint8Array(n * 4);
    for (let i = 0; i < n; i++) {
      const m = this.mask[i],
        c = COL[m] || COL[0],
        v = 0.88 + 0.24 * hash01(i, 7);
      d[i * 4] = Math.min(255, c[0] * v);
      d[i * 4 + 1] = Math.min(255, c[1] * v);
      d[i * 4 + 2] = Math.min(255, c[2] * v);
      d[i * 4 + 3] = GRASSW[m] || 0;
    }
    const t = new DataTexture(d, this.mw, this.mh, RGBAFormat);
    t.colorSpace = SRGBColorSpace;
    t.magFilter = LinearFilter;
    t.minFilter = LinearMipmapLinearFilter;
    t.generateMipmaps = true;
    t.needsUpdate = true;
    return t;
  }

  heightTexture(): DataTexture {
    const d = new Uint16Array(this.nx * this.nz);
    for (let i = 0; i < d.length; i++) d[i] = DataUtils.toHalfFloat(this.hC[i] - this.hBase);
    const t = new DataTexture(d, this.nx, this.nz, RedFormat, HalfFloatType);
    t.magFilter = LinearFilter;
    t.minFilter = LinearFilter;
    t.needsUpdate = true;
    return t;
  }

  waterGeometry(): BufferGeometry {
    const pos: number[] = [];
    const ring = (q: number[]) => {
      const a: Vector2[] = [];
      for (let i = 0; i < q.length; i += 2) a.push(new Vector2(q[i], q[i + 1]));
      return a;
    };
    for (const w of this.waters) {
      const contour = ring(w.p),
        hs = (w.holes || []).map(ring);
      let faces: number[][] = [];
      try {
        faces = ShapeUtils.triangulateShape(contour, hs);
      } catch {
        faces = [];
      }
      let all = contour;
      for (const h of hs) all = all.concat(h);
      for (const f of faces) {
        const A = all[f[0]],
          B = all[f[1]],
          C2 = all[f[2]];
        if (!A || !B || !C2) continue;
        const up = (B.y - A.y) * (C2.x - A.x) - (B.x - A.x) * (C2.y - A.y) >= 0;
        pos.push(A.x, w.level, A.y);
        if (up) pos.push(B.x, w.level, B.y, C2.x, w.level, C2.y);
        else pos.push(C2.x, w.level, C2.y, B.x, w.level, B.y);
      }
    }
    const g = new BufferGeometry();
    g.setAttribute("position", new Float32BufferAttribute(pos, 3));
    const n = new Float32Array(pos.length);
    for (let i = 1; i < n.length; i += 3) n[i] = 1;
    g.setAttribute("normal", new BufferAttribute(n, 3));
    return g;
  }
}

export function terrainMaterial(t: Terrain, ground: DataTexture, detail: DataTexture): MeshStandardMaterial {
  const m = new MeshStandardMaterial({ color: 0xffffff, roughness: 0.88, metalness: 0.02 });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uGround = { value: ground };
    sh.uniforms.uDetail = { value: detail };
    sh.uniforms.uGO = { value: new Vector4(t.x0, t.z0, 1 / (t.mw * t.mc), 1 / (t.mh * t.mc)) };
    sh.vertexShader = sh.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
varying vec2 vGxz;
varying float vGy;
varying vec3 vWNor;`
      )
      .replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
vGxz = position.xz; vGy = position.y; vWNor = normal;`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
uniform sampler2D uGround;
uniform sampler2D uDetail;
uniform vec4 uGO;
varying vec2 vGxz;
varying float vGy;
varying vec3 vWNor;`
      )
      .replace(
        "#include <map_fragment>",
        `vec4 gCol = texture2D( uGround, ( vGxz - uGO.xy ) * uGO.zw );
float gd1 = texture2D( uDetail, vGxz * 0.27 ).r;
float gd2 = texture2D( uDetail, vGxz * 0.042 ).g;
float gd3 = texture2D( uDetail, vGxz * 0.0055 ).b;
float furrow = 0.94 + 0.06 * sin( vGxz.x * 1.8 + vGxz.y * 0.7 + gd2 * 3.0 );
vec3 gBase = gCol.rgb * ( 0.62 + 0.44 * gd1 + 0.34 * gd2 ) * ( 0.82 + 0.36 * gd3 ) * furrow;
// Jurassic limestone cliffs on steep slopes (Wzgórze Skała)
float gRock = smoothstep( 0.968, 0.885, vWNor.y ) * smoothstep( 0.15, 0.55, gCol.a );
vec3 limestone = mix( vec3( 0.44, 0.42, 0.38 ), vec3( 0.72, 0.69, 0.63 ), gd1 * 0.7 + gd2 * 0.3 );
gBase = mix( gBase, limestone, gRock );
// Shoreline / valley dampness
float gWet = smoothstep( 233.5, 229.8, vGy );
gBase *= mix( 1.0, 0.62, gWet );
diffuseColor.rgb *= gBase;`
      )
      .replace(
        "#include <normal_fragment_maps>",
        `#include <normal_fragment_maps>
float hBump = ( gd1 * 0.65 + gd2 * 0.35 + gRock * 0.85 );
vec2 dBump = vec2( dFdx( hBump ), dFdy( hBump ) );
normal = normalize( normal + vec3( -dBump.x * 2.4, 0.0, -dBump.y * 2.4 ) );`
      )
      .replace(
        "#include <roughnessmap_fragment>",
        `#include <roughnessmap_fragment>
roughnessFactor = mix( 0.86 - 0.16 * gd1, 0.62, gRock );
roughnessFactor = mix( roughnessFactor, 0.18, gWet * 0.85 );`
      );
  };
  m.customProgramCacheKey = () => "terrain_ue5";
  return m;
}

export function waterMaterial(polygonOffset = false): MeshStandardMaterial {
  const m = new MeshStandardMaterial({
    color: 0x1e4d58,
    roughness: 0.06,
    metalness: 0.78,
    polygonOffset,
    polygonOffsetFactor: polygonOffset ? -2 : 0,
    polygonOffsetUnits: polygonOffset ? -8 : 0,
  });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = U.time;
    sh.vertexShader = sh.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
uniform float uTime;
varying vec2 vWxz;`
      )
      .replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
vWxz = position.xz;
transformed.y += sin( position.x * 0.35 + uTime * 1.8 ) * 0.025 + cos( position.z * 0.42 - uTime * 1.4 ) * 0.02;`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
uniform float uTime;
varying vec2 vWxz;
float wWave(vec2 p, float t) {
  float w1 = sin(p.x * 0.85 + p.y * 0.45 + t * 2.1);
  float w2 = cos(p.x * 0.52 - p.y * 0.95 - t * 1.7);
  float w3 = sin((p.x - p.y) * 1.6 + t * 2.9) * 0.5;
  return (w1 + w2 + w3) * 0.33;
}`
      )
      .replace(
        "#include <map_fragment>",
        `float wv = wWave(vWxz, uTime);
vec3 deepCol = vec3(0.07, 0.22, 0.27);
vec3 shallowCol = vec3(0.14, 0.36, 0.38);
diffuseColor.rgb = mix(deepCol, shallowCol, 0.5 + 0.5 * wv);`
      )
      .replace(
        "#include <normal_fragment_maps>",
        `#include <normal_fragment_maps>
float eps = 0.18;
float h0 = wWave(vWxz, uTime);
float hx = wWave(vWxz + vec2(eps, 0.0), uTime) - h0;
float hz = wWave(vWxz + vec2(0.0, eps), uTime) - h0;
normal = normalize(normal + vec3(hx * 0.45, 0.0, hz * 0.45));`
      );
  };
  m.customProgramCacheKey = () => "water_ue5_" + (polygonOffset ? 1 : 0);
  return m;
}
