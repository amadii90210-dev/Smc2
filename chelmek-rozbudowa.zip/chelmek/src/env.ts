import { Vector3 } from "three";

export const U = {
  time: { value: 0 },
  night: { value: 0 },
  wind: { value: 1 },
  sunDir: { value: new Vector3(0.4, 0.5, 0.7).normalize() },
};
