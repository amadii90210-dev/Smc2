import {
  BoxGeometry,
  BufferAttribute,
  BufferGeometry,
  Color,
  ConeGeometry,
  CylinderGeometry,
  Group,
  InstancedMesh,
  Matrix4,
  Mesh,
  MeshStandardMaterial,
  PointLight,
  Quaternion,
  Vector3,
} from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { hash01, polyCentroid, segDist, segT } from "./geo";
import { SF, Terrain } from "./terrain";

const mg2 = (a: BufferGeometry[]) => mergeGeometries(a)!;

function col(g: BufferGeometry, hex: string): BufferGeometry {
  const c = new Color(hex),
    ng = g.index ? g.toNonIndexed() : g,
    n = ng.getAttribute("position").count,
    a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    a[i * 3] = c.r;
    a[i * 3 + 1] = c.g;
    a[i * 3 + 2] = c.b;
  }
  ng.setAttribute("color", new BufferAttribute(a, 3));
  ng.deleteAttribute("uv");
  return ng;
}

const bx = (w: number, h: number, d: number, x: number, y: number, z: number, hex: string) => {
  const g = new BoxGeometry(w, h, d);
  g.translate(x, y, z);
  return col(g, hex);
};

const cy = (r1: number, r2: number, h: number, x: number, y: number, z: number, hex: string, seg: number) => {
  const g = new CylinderGeometry(r1, r2, h, seg);
  g.translate(x, y, z);
  return col(g, hex);
};

const cn = (r: number, h: number, x: number, y: number, z: number, hex: string, seg: number) => {
  const g = new ConeGeometry(r, h, seg);
  g.translate(x, y, z);
  return col(g, hex);
};

function slideGeo(): BufferGeometry {
  const W = "#8a5a36",
    R = "#d63629",
    Y = "#eab308",
    B = "#2563eb";
  const chute = new BoxGeometry(0.65, 0.08, 2.5);
  chute.rotateX(0.58);
  chute.translate(0, 0.82, 1.35);
  const railL = new BoxGeometry(0.06, 0.16, 2.5);
  railL.rotateX(0.58);
  railL.translate(0.31, 0.88, 1.35);
  const railR = new BoxGeometry(0.06, 0.16, 2.5);
  railR.rotateX(0.58);
  railR.translate(-0.31, 0.88, 1.35);
  return mg2([
    // 4 tower posts
    bx(0.1, 2.5, 0.1, -0.55, 1.25, -0.55, W),
    bx(0.1, 2.5, 0.1, 0.55, 1.25, -0.55, W),
    bx(0.1, 2.5, 0.1, -0.55, 1.25, 0.35, W),
    bx(0.1, 2.5, 0.1, 0.55, 1.25, 0.35, W),
    // Platform & safety rails
    bx(1.25, 0.08, 1.05, 0, 1.45, -0.1, W),
    bx(0.06, 0.65, 0.95, -0.56, 1.8, -0.1, Y),
    bx(0.06, 0.65, 0.95, 0.56, 1.8, -0.1, Y),
    // Peaked roof
    cn(0.98, 0.75, 0, 2.82, -0.1, B, 4),
    // Slide chute
    col(chute, R),
    col(railL, Y),
    col(railR, Y),
    // Climbing ladder at back
    bx(0.6, 1.45, 0.08, 0, 0.72, -0.62, W),
  ]);
}

function swingGeo(): BufferGeometry {
  const S = "#334155",
    R = "#dc2626",
    B = "#2563eb";
  const leg1 = new CylinderGeometry(0.045, 0.045, 2.45, 6);
  leg1.rotateX(0.26);
  leg1.translate(-1.35, 1.15, 0.3);
  const leg2 = new CylinderGeometry(0.045, 0.045, 2.45, 6);
  leg2.rotateX(-0.26);
  leg2.translate(-1.35, 1.15, -0.3);
  const leg3 = new CylinderGeometry(0.045, 0.045, 2.45, 6);
  leg3.rotateX(0.26);
  leg3.translate(1.35, 1.15, 0.3);
  const leg4 = new CylinderGeometry(0.045, 0.045, 2.45, 6);
  leg4.rotateX(-0.26);
  leg4.translate(1.35, 1.15, -0.3);
  return mg2([
    col(leg1, S),
    col(leg2, S),
    col(leg3, S),
    col(leg4, S),
    bx(2.85, 0.08, 0.08, 0, 2.3, 0, R),
    // Two swing seats + chains
    cy(0.012, 0.012, 1.75, -0.68, 1.4, 0, "#94a3b8", 4),
    cy(0.012, 0.012, 1.75, -0.32, 1.4, 0, "#94a3b8", 4),
    bx(0.44, 0.04, 0.22, -0.5, 0.52, 0, B),
    cy(0.012, 0.012, 1.75, 0.32, 1.4, 0, "#94a3b8", 4),
    cy(0.012, 0.012, 1.75, 0.68, 1.4, 0, "#94a3b8", 4),
    bx(0.44, 0.04, 0.22, 0.5, 0.52, 0, R),
  ]);
}

function sandboxGeo(): BufferGeometry {
  const W = "#9a663d",
    SAND = "#e5c888",
    R = "#e11d48",
    Y = "#facc15";
  return mg2([
    bx(2.6, 0.24, 0.14, 0, 0.12, 1.23, W),
    bx(2.6, 0.24, 0.14, 0, 0.12, -1.23, W),
    bx(0.14, 0.24, 2.32, 1.23, 0.12, 0, W),
    bx(0.14, 0.24, 2.32, -1.23, 0.12, 0, W),
    bx(2.32, 0.14, 2.32, 0, 0.07, 0, SAND),
    // Carousel / spring toy next to sandbox
    cy(0.75, 0.75, 0.06, 2.3, 0.18, 0, R, 12),
    cy(0.06, 0.06, 0.65, 2.3, 0.35, 0, Y, 8),
    cy(0.32, 0.32, 0.04, 2.3, 0.66, 0, Y, 10),
  ]);
}

function cafeGardenGeo(): BufferGeometry {
  const W = "#6b472b",
    FABRIC = "#f5ebd6",
    ACC = "#991b1b",
    GREEN = "#2d5a36";
  return mg2([
    // Wooden patio platform
    bx(3.2, 0.08, 3.2, 0, 0.04, 0, "#7c5838"),
    // Cafe table
    cy(0.04, 0.04, 0.74, 0, 0.41, 0, "#27272a", 8),
    cy(0.55, 0.55, 0.04, 0, 0.78, 0, W, 12),
    // 4 Cafe chairs around table
    bx(0.42, 0.04, 0.42, 0.82, 0.45, 0, W),
    bx(0.04, 0.45, 0.42, 1.01, 0.68, 0, W),
    bx(0.42, 0.04, 0.42, -0.82, 0.45, 0, W),
    bx(0.04, 0.45, 0.42, -1.01, 0.68, 0, W),
    bx(0.42, 0.04, 0.42, 0, 0.45, 0.82, W),
    bx(0.42, 0.45, 0.04, 0, 0.68, 1.01, W),
    bx(0.42, 0.04, 0.42, 0, 0.45, -0.82, W),
    bx(0.42, 0.45, 0.04, 0, 0.68, -1.01, W),
    // Parasol mast & canopy
    cy(0.035, 0.035, 2.45, 0, 1.25, 0, W, 8),
    cn(1.55, 0.52, 0, 2.48, 0, FABRIC, 8),
    cn(1.58, 0.12, 0, 2.26, 0, ACC, 8),
    // Corner flower planters
    bx(0.9, 0.42, 0.32, 1.1, 0.25, 1.38, W),
    bx(0.8, 0.25, 0.24, 1.1, 0.52, 1.38, GREEN),
    bx(0.9, 0.42, 0.32, -1.1, 0.25, 1.38, W),
    bx(0.8, 0.25, 0.24, -1.1, 0.52, 1.38, GREEN),
  ]);
}

function gazeboGeo(): BufferGeometry {
  const W = "#734f32",
    ROOF = "#6e3426";
  return mg2([
    bx(3.0, 0.12, 3.0, 0, 0.06, 0, W),
    bx(0.12, 2.2, 0.12, -1.35, 1.16, -1.35, W),
    bx(0.12, 2.2, 0.12, 1.35, 1.16, -1.35, W),
    bx(0.12, 2.2, 0.12, -1.35, 1.16, 1.35, W),
    bx(0.12, 2.2, 0.12, 1.35, 1.16, 1.35, W),
    bx(2.7, 0.08, 0.7, 0, 0.78, 0, W),
    bx(2.7, 0.06, 0.35, 0, 0.46, -0.7, W),
    bx(2.7, 0.06, 0.35, 0, 0.46, 0.7, W),
    cn(2.35, 1.05, 0, 2.75, 0, ROOF, 4),
  ]);
}

function railCrossingGeo(): BufferGeometry {
  // St. Andrew's cross (Krzyż św. Andrzeja) + red/white barrier arm
  const c1 = new BoxGeometry(0.95, 0.11, 0.04);
  c1.rotateZ(0.78);
  c1.translate(0, 2.35, 0.06);
  const c2 = new BoxGeometry(0.95, 0.11, 0.04);
  c2.rotateZ(-0.78);
  c2.translate(0, 2.35, 0.06);
  return mg2([
    cy(0.06, 0.07, 2.7, 0, 1.35, 0, "#64748b", 8),
    col(c1, "#ffffff"),
    col(c2, "#dc2626"),
    bx(0.28, 0.45, 0.28, 0, 0.9, -0.15, "#334155"),
    // Red-white barrier boom
    bx(1.2, 0.09, 0.05, 0.6, 1.05, 0.12, "#dc2626"),
    bx(1.2, 0.09, 0.05, 1.8, 1.05, 0.12, "#ffffff"),
    bx(1.2, 0.09, 0.05, 3.0, 1.05, 0.12, "#dc2626"),
  ]);
}

function goalGeo(): BufferGeometry {
  const W = "#f8fafc",
    N = "#cbd5e1";
  return mg2([
    cy(0.05, 0.05, 2.2, -2.2, 1.1, 0, W, 8),
    cy(0.05, 0.05, 2.2, 2.2, 1.1, 0, W, 8),
    bx(4.5, 0.1, 0.1, 0, 2.2, 0, W),
    bx(0.05, 2.15, 1.1, -2.2, 1.08, -0.55, N),
    bx(0.05, 2.15, 1.1, 2.2, 1.08, -0.55, N),
    bx(4.4, 0.05, 1.1, 0, 2.15, -0.55, N),
  ]);
}

function geos2(): Record<string, BufferGeometry> {
  const W = "#8a5a36",
    D = "#2b2f33",
    S = "#3a3f45";
  return {
    lamp: mg2([cy(0.06, 0.09, 6.6, 0, 3.3, 0, S, 8), bx(0.07, 0.07, 1.3, 0, 6.56, 0.6, S)]),
    head: bx(0.26, 0.1, 0.62, 0, 6.5, 1.15, "#ffffff"),
    bench: mg2([
      bx(1.6, 0.05, 0.42, 0, 0.45, 0, W),
      bx(1.6, 0.38, 0.05, 0, 0.76, -0.2, W),
      bx(0.06, 0.45, 0.4, 0.7, 0.225, 0, D),
      bx(0.06, 0.45, 0.4, -0.7, 0.225, 0, D),
    ]),
    bin: mg2([cy(0.2, 0.17, 0.7, 0, 0.55, 0, "#2f5f3a", 10), cy(0.03, 0.03, 0.95, 0, 0.47, -0.22, D, 6)]),
    recycling: bx(1.2, 1.25, 0.9, 0, 0.63, 0, "#ffffff"),
    bus: mg2([
      bx(3.2, 0.08, 1.5, 0, 2.35, 0, S),
      bx(3.2, 1.9, 0.04, 0, 1.25, -0.72, "#9fb7c9"),
      bx(0.04, 1.9, 1.4, 1.58, 1.25, 0, "#9fb7c9"),
      bx(0.04, 1.9, 1.4, -1.58, 1.25, 0, "#9fb7c9"),
      bx(2.2, 0.06, 0.35, 0, 0.5, -0.45, W),
      cy(0.03, 0.03, 2.6, 2.1, 1.3, 0.5, D, 6),
      bx(0.45, 0.45, 0.04, 2.1, 2.4, 0.5, "#f2c300"),
    ]),
    info: mg2([
      bx(0.08, 1.9, 0.08, 0.55, 0.95, 0, "#5a4632"),
      bx(0.08, 1.9, 0.08, -0.55, 0.95, 0, "#5a4632"),
      bx(1.2, 0.8, 0.05, 0, 1.45, 0, "#e9e2cf"),
      bx(1.4, 0.06, 0.3, 0, 1.92, 0, "#5a4632"),
    ]),
    shrine: mg2([
      bx(0.6, 1.6, 0.6, 0, 0.8, 0, "#f1ede2"),
      bx(0.3, 0.4, 0.05, 0, 1.2, 0.31, "#3d4c63"),
      bx(0.8, 0.12, 0.8, 0, 1.66, 0, "#7a3b2e"),
      bx(0.05, 0.42, 0.05, 0, 1.93, 0, D),
      bx(0.22, 0.05, 0.05, 0, 2, 0, D),
    ]),
    cross: mg2([bx(0.12, 2.6, 0.12, 0, 1.3, 0, "#5a4632"), bx(1, 0.12, 0.12, 0, 2.1, 0, "#5a4632")]),
    pole: mg2([cy(0.1, 0.13, 8.5, 0, 4.25, 0, "#6a5a44", 6), bx(1.6, 0.1, 0.1, 0, 8, 0, "#6a5a44")]),
    catenary: mg2([bx(0.18, 7.5, 0.18, 0, 3.75, 0, "#6f757b"), bx(0.08, 0.08, 2.6, 0, 6.8, 1.3, "#6f757b")]),
    pylon: mg2([
      cy(0.25, 1.2, 24, 0, 12, 0, "#8f959b", 4),
      bx(9, 0.25, 0.25, 0, 20, 0, "#8f959b"),
      bx(6, 0.2, 0.2, 0, 23.5, 0, "#8f959b"),
    ]),
    locker: mg2([bx(3.2, 2.1, 0.65, 0, 1.05, 0, "#f4c400"), bx(3, 1.9, 0.02, 0, 1.05, 0.335, S)]),
    stone: bx(0.3, 0.6, 0.3, 0, 0.3, 0, "#9a968c"),
    playSlide: slideGeo(),
    playSwing: swingGeo(),
    playSandbox: sandboxGeo(),
    cafeGarden: cafeGardenGeo(),
    gazebo: gazeboGeo(),
    railCrossing: railCrossingGeo(),
    goal: goalGeo(),
  };
}

function towerGeo(): BufferGeometry {
  const P: BufferGeometry[] = [],
    S = "#7d858c",
    D = "#59616a",
    a = 2.3,
    H = 36,
    DK = 32;
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) P.push(bx(0.24, H - 0.5, 0.24, sx * a, (H - 0.5) / 2, sz * a, S));
  for (let y0 = 0, k = 0; y0 < DK; y0 += 4, k++) {
    const y = y0 + 4,
      dgn = k % 2 ? 0.716 : -0.716;
    for (const s of [-1, 1]) {
      P.push(bx(2 * a, 0.14, 0.14, 0, y, s * a, S), bx(0.14, 0.14, 2 * a, s * a, y, 0, S));
      const b1 = new BoxGeometry(6.1, 0.07, 0.07);
      b1.rotateZ(dgn * s);
      b1.translate(0, y0 + 2, s * a);
      P.push(col(b1, D));
      const b2 = new BoxGeometry(0.07, 0.07, 6.1);
      b2.rotateX(dgn * s);
      b2.translate(s * a, y0 + 2, 0);
      P.push(col(b2, D));
    }
    const st = new BoxGeometry(1, 0.1, 5.38);
    st.rotateX(k % 2 ? 0.838 : -0.838);
    st.translate(k % 2 ? 0.6 : -0.6, y0 + 2, 0);
    P.push(col(st, D));
  }
  P.push(bx(6, 0.14, 6, 0, DK, 0, D), bx(6.6, 0.14, 6.6, 0, H - 0.5, 0, "#4a5057"));
  for (const s of [-1, 1])
    P.push(
      bx(6, 1.1, 0.06, 0, DK + 0.62, s * 3, "#aab2b9"),
      bx(0.06, 1.1, 6, s * 3, DK + 0.62, 0, "#aab2b9")
    );
  return mg2(P);
}

export function buildProps(w: any, t: Terrain, net: any, nLights: number) {
  const group = new Group(),
    G2 = geos2(),
    mat = new MeshStandardMaterial({ vertexColors: true, roughness: 0.75, metalness: 0.12 });
  const headMat = new MeshStandardMaterial({
    color: "#e9e4d6",
    emissive: "#ffcf8a",
    emissiveIntensity: 0,
    roughness: 0.35,
  });
  const inst: Record<string, number[]> = {},
    counts: Record<string, number> = {};
  const put = (k: string, x: number, z: number, yaw: number, c = 0) => {
    (inst[k] = inst[k] || []).push(x, t.h(x, z), z, yaw, c);
  };
  const face = (x: number, z: number, def: number) => {
    const si = net.all.nearest(x, z, 35);
    if (si < 0) return def;
    const s = net.all.s,
      o = si * 5;
    const qx = s[o] + (s[o + 2] - s[o]) * net.all.nt,
      qz = s[o + 1] + (s[o + 3] - s[o + 1]) * net.all.nt;
    return Math.hypot(qx - x, qz - z) < 0.3 ? def : Math.atan2(qx - x, qz - z);
  };
  const faceRail = (x: number, z: number) => {
    let bd = 1e9,
      yaw = 0;
    for (const l of w.rails) {
      const p = l.p;
      for (let i = 0; i + 3 < p.length; i += 2) {
        const d = segDist(x, z, p[i], p[i + 1], p[i + 2], p[i + 3]);
        if (d < bd) {
          bd = d;
          yaw = Math.atan2(p[i] + (p[i + 2] - p[i]) * segT - x, p[i + 1] + (p[i + 3] - p[i + 1]) * segT - z);
        }
      }
    }
    return yaw;
  };

  const lampPts: number[] = [];
  const addPlaygroundSet = (cx: number, cz: number, seed: number) => {
    const a = hash01(Math.round(cx), Math.round(cz), seed) * 6.28;
    const ca = Math.cos(a),
      sa = Math.sin(a);
    put("playSlide", cx - ca * 2.6, cz - sa * 2.6, a);
    put("playSwing", cx + ca * 2.8, cz + sa * 2.8, a + 1.57);
    put("playSandbox", cx - sa * 2.8, cz + ca * 2.8, a + 0.5);
    put("bench", cx + sa * 3.8, cz - ca * 3.8, a + 3.14);
    put("bin", cx + sa * 3.8 + ca * 1.4, cz - ca * 3.8 + sa * 1.4, a + 3.14);
  };

  for (const p of w.points) {
    const k = p.k,
      r = hash01(Math.round(p.x * 10), Math.round(p.z * 10), 3);
    if (k === "lamp") lampPts.push(p.x, p.z);
    else if (k === "bench") {
      const y = face(p.x, p.z, r * 6.28);
      put("bench", p.x, p.z, y);
      if (r < 0.6) put("bin", p.x + Math.cos(y) * 1.25, p.z - Math.sin(y) * 1.25, y);
    } else if (k === "bin") put("bin", p.x, p.z, face(p.x, p.z, 0));
    else if (k === "recycling") put("recycling", p.x, p.z, face(p.x, p.z, 0), 1 + ((r * 3) | 0));
    else if (k === "bus_stop") {
      const y = face(p.x, p.z, 0);
      put("bus", p.x - Math.sin(y) * 2.2, p.z - Math.cos(y) * 2.2, y);
    } else if (k === "info") put("info", p.x, p.z, face(p.x, p.z, 0));
    else if (k === "shrine") put("shrine", p.x, p.z, face(p.x, p.z, 0));
    else if (k === "cross") put("cross", p.x, p.z, face(p.x, p.z, 0));
    else if (k === "power_pole") put("pole", p.x, p.z, r * 3.14);
    else if (k === "catenary") put("catenary", p.x, p.z, faceRail(p.x, p.z));
    else if (k === "power_tower") put("pylon", p.x, p.z, r * 3.14);
    else if (k === "parcel_locker") put("locker", p.x, p.z, face(p.x, p.z, 0));
    else if (k === "stone") put("stone", p.x, p.z, r * 6.28);
    else if (k === "playspot") addPlaygroundSet(p.x, p.z, 17);
    else if (k === "shelter" || k === "picnic") put("gazebo", p.x, p.z, r * 6.28);
    else if (k === "level_crossing") {
      const y = face(p.x, p.z, 0);
      put("railCrossing", p.x + Math.cos(y) * 2.8, p.z - Math.sin(y) * 2.8, y);
      put("railCrossing", p.x - Math.cos(y) * 2.8, p.z + Math.sin(y) * 2.8, y + Math.PI);
    } else if (
      k === "poi" &&
      (p.v === "cafe" ||
        p.v === "restaurant" ||
        p.v === "biergarten" ||
        p.v === "pub" ||
        p.v === "ice_cream" ||
        p.v === "fast_food" ||
        p.v === "shop:bakery")
    ) {
      // Outdoor Cafe / Restaurant Garden (kawiarnie i ogródki)
      const y = face(p.x, p.z, 0);
      const gx = p.x + Math.sin(y) * 4.2,
        gz = p.z + Math.cos(y) * 4.2;
      if (t.surf(gx, gz) !== SF.ROAD && t.surf(gx, gz) !== SF.BUILDING) {
        put("cafeGarden", gx, gz, y);
        put("cafeGarden", gx + Math.cos(y) * 3.6, gz - Math.sin(y) * 3.6, y);
      }
    }
  }

  // Populate all 25+ OSM playground areas, parks & allotment gardens
  for (let i = 0; i < w.areas.length; i++) {
    const a = w.areas[i];
    if (a.k === "playground") {
      const c = polyCentroid(a.p);
      addPlaygroundSet(c[0], c[1], i + 31);
    } else if (a.k === "park") {
      const c = polyCentroid(a.p);
      put("gazebo", c[0] + 6, c[1] - 4, (i * 1.3) % 6.28);
      put("bench", c[0] - 4, c[1] + 3, (i * 0.7) % 6.28);
    } else if (a.k === "allotments") {
      const c = polyCentroid(a.p);
      for (let g = -1; g <= 1; g++) {
        put("gazebo", c[0] + g * 24, c[1] + (g % 2) * 14, g * 1.1);
      }
    } else if (a.k === "pitch" && a.p.length >= 8) {
      const c = polyCentroid(a.p);
      const dx = a.p[2] - a.p[0],
        dz = a.p[3] - a.p[1],
        yaw = Math.atan2(dx, dz);
      put("goal", c[0] + Math.sin(yaw) * 14, c[1] + Math.cos(yaw) * 14, yaw + Math.PI);
      put("goal", c[0] - Math.sin(yaw) * 14, c[1] - Math.cos(yaw) * 14, yaw);
    } else if (a.k === "platform") {
      const c = polyCentroid(a.p);
      const yaw = faceRail(c[0], c[1]);
      put("bus", c[0], c[1], yaw);
      put("bench", c[0] + Math.cos(yaw) * 4.5, c[1] - Math.sin(yaw) * 4.5, yaw);
      put("info", c[0] - Math.cos(yaw) * 4.5, c[1] + Math.sin(yaw) * 4.5, yaw);
    }
  }

  const LC = 44,
    lgrid = new Map<number, number[]>(),
    lamps: number[] = [];
  const lkey = (x: number, z: number) => (Math.floor(x / LC) + 512) * 1024 + Math.floor(z / LC) + 512;
  const nearLamp = (x: number, z: number, d: number) => {
    for (let i = -1; i <= 1; i++)
      for (let j = -1; j <= 1; j++) {
        const a = lgrid.get(lkey(x + i * LC, z + j * LC));
        if (a) {
          for (let q = 0; q < a.length; q += 2) if (Math.hypot(a[q] - x, a[q + 1] - z) < d) return true;
        }
      }
    return false;
  };
  const addLamp = (x: number, z: number, yaw: number) => {
    put("lamp", x, z, yaw);
    const k = lkey(x, z);
    let a = lgrid.get(k);
    if (!a) {
      a = [];
      lgrid.set(k, a);
    }
    a.push(x, z);
    lamps.push(x + Math.sin(yaw) * 1.15, t.h(x, z) + 6.35, z + Math.cos(yaw) * 1.15);
  };
  for (let i = 0; i < lampPts.length; i += 2)
    addLamp(lampPts[i], lampPts[i + 1], face(lampPts[i], lampPts[i + 1], 0));

  const URB: Record<number, number> = {
    [SF.YARD]: 1,
    [SF.PAVED]: 1,
    [SF.PARKING]: 1,
    [SF.BUILDING]: 1,
    [SF.PARK]: 1,
    [SF.PLAY]: 1,
  };
  for (const r of net.roads) {
    if (r.bridge || !(r.k === "secondary" || r.k === "tertiary" || r.k === "residential" || r.k === "living_street"))
      continue;
    const n = r.p.length / 2;
    let next = 18,
      side = (r.id % 2) * 2 - 1;
    for (let i = 1; i < n; i++) {
      if (r.cum[i] < next) continue;
      next = r.cum[i] + 40;
      side = -side;
      const x = r.p[i * 2],
        z = r.p[i * 2 + 1];
      let tx = x - r.p[i * 2 - 2],
        tz = z - r.p[i * 2 - 1];
      const l = Math.hypot(tx, tz) || 1;
      tx /= l;
      tz /= l;
      const nx = -tz * side,
        nz = tx * side,
        lx = x + nx * (r.half + 2.5),
        lz = z + nz * (r.half + 2.5),
        s = t.surf(lx, lz);
      if (s === SF.BUILDING || s === SF.ROAD || s === SF.WATER || s === SF.RAIL) continue;
      if (!(r.k === "secondary" || URB[s] || URB[t.surf(x + nx * (r.half + 9), z + nz * (r.half + 9))])) continue;
      if (nearLamp(lx, lz, 24)) continue;
      addLamp(lx, lz, Math.atan2(-nx, -nz));
    }
  }

  const m4 = new Matrix4(),
    q4 = new Quaternion(),
    up = new Vector3(0, 1, 0),
    ps = new Vector3(),
    sc = new Vector3(1, 1, 1),
    cc = new Color();
  const RC = ["#ffffff", "#e2b400", "#2f8f4a", "#2a62b8"];
  const make = (k: string, src: string, m: MeshStandardMaterial, cast: boolean) => {
    const a = inst[src];
    if (!a || !a.length) return;
    const n = a.length / 5,
      im = new InstancedMesh(G2[k], m, n);
    for (let i = 0; i < n; i++) {
      const o = i * 5;
      ps.set(a[o], a[o + 1], a[o + 2]);
      q4.setFromAxisAngle(up, a[o + 3]);
      m4.compose(ps, q4, sc);
      im.setMatrixAt(i, m4);
      if (k === "recycling") {
        cc.set(RC[a[o + 4] | 0]);
        im.setColorAt(i, cc);
      }
    }
    im.castShadow = cast;
    im.receiveShadow = true;
    im.frustumCulled = false;
    group.add(im);
    counts[k] = n;
  };
  for (const k of Object.keys(G2)) if (k !== "head") make(k, k, mat, k !== "stone");
  make("head", "lamp", headMat, false);

  let tower: { x: number; z: number; deck: number; half: number } | null = null;
  const tp = w.points.find((p: any) => p.k === "tower");
  if (tp) {
    const base = t.h(tp.x, tp.z),
      mesh = new Mesh(towerGeo(), mat);
    mesh.position.set(tp.x, base, tp.z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    tower = { x: tp.x, z: tp.z, deck: base + 32.08, half: 2.75 };
  }

  const lights: PointLight[] = [];
  for (let i = 0; i < nLights; i++) {
    const L2 = new PointLight(0xffcf8a, 0, 38, 1.65);
    group.add(L2);
    lights.push(L2);
  }
  const L3 = new Float32Array(lamps);
  let night = 0;
  const setNight = (n: number) => {
    night = n;
    headMat.emissiveIntensity = n * 6.5;
    for (const L2 of lights) L2.intensity = n > 0.05 ? 120 * n : 0;
  };
  const used: number[] = [];
  const updateLights = (px: number, pz: number) => {
    if (night < 0.05 || !lights.length) return;
    used.length = 0;
    for (const L2 of lights) {
      let best = -1,
        bd = 1e12;
      for (let i = 0; i < L3.length; i += 3) {
        if (used.indexOf(i) >= 0) continue;
        const dx = L3[i] - px,
          dz = L3[i + 2] - pz,
          d2 = dx * dx + dz * dz;
        if (d2 < bd) {
          bd = d2;
          best = i;
        }
      }
      if (best < 0) {
        L2.visible = false;
        continue;
      }
      used.push(best);
      L2.visible = true;
      L2.position.set(L3[best], L3[best + 1] - 0.3, L3[best + 2]);
    }
  };
  return { group, lamps: L3, tower, counts, setNight, updateLights };
}
