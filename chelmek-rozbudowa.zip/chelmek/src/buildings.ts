import {
  BufferGeometry,
  CanvasTexture,
  Color,
  Float32BufferAttribute,
  Mesh,
  MeshStandardMaterial,
  ShapeUtils,
  SRGBColorSpace,
  Vector2,
} from "three";
import { hash01, obb, OBB, offsetPoly, pointInPoly, polyArea, polyCentroid, segDist, SegGrid, segT } from "./geo";
import { Chunks, MB } from "./mb";
import { SF, Terrain } from "./terrain";
import { L } from "./tex";

const lin = (h: string) => {
  const c = new Color(h);
  return [c.r, c.g, c.b];
};

const PAL: Record<string, number[][]> = {
  house: [
    "#f2e9d6",
    "#e7d8b7",
    "#d8c8a2",
    "#ced7c1",
    "#efe1cb",
    "#f5f0e6",
    "#e8c8a5",
    "#dde1e4",
    "#f0d78b",
    "#e1b598",
  ].map(lin),
  block: ["#c8c3b7", "#b7b1a3", "#d5cfc0", "#e5dbc0", "#ced5c3", "#e0c5a2", "#c6d1da"].map(lin),
  ind: ["#989ea4", "#b7bec4", "#7b8288", "#c6cacf", "#8d98a1"].map(lin),
  shop: ["#f2e9d6", "#e8e3d7", "#dbd5c7", "#e5d1b3"].map(lin),
  civic: ["#f4f0e5", "#ebe3cf", "#e5dbca"].map(lin),
  church: ["#f6f2e7"].map(lin),
  shed: ["#cec8bc", "#b8b2a5", "#a19a8c", "#d6d0c2", "#8d8982"].map(lin),
};

const ROOFS = ["#8e3f2b", "#7e3625", "#643e2d", "#36393f", "#43464b", "#703326", "#52575e", "#7a4232"].map(lin);
const WHITE2 = [1, 1, 1];
const GREY = [0.78, 0.78, 0.78];
const SOFFIT = [0.55, 0.52, 0.48];
const COPPER = lin("#42725e");
const BRICK_POST = lin("#8a3e2b");
const SHOPLIKE: Record<string, number> = {
  restaurant: 1,
  cafe: 1,
  fast_food: 1,
  pub: 1,
  bank: 1,
  pharmacy: 1,
  post_office: 1,
  fuel: 1,
  biergarten: 1,
  cinema: 1,
  kiosk: 1,
};

const isShop = (q: any) => !!q.v && (q.v.indexOf("shop:") === 0 || !!SHOPLIKE[q.v]);

function ringV2(q: number[]) {
  const a: Vector2[] = [];
  for (let i = 0; i < q.length; i += 2) a.push(new Vector2(q[i], q[i + 1]));
  return a;
}

function cap(mb: MB, p: number[], holes: number[][] | undefined, y: number, layer: number, tint: number[], sc: number) {
  const contour = ringV2(p),
    hs = (holes || []).map(ringV2);
  let faces: number[][] = [];
  try {
    faces = ShapeUtils.triangulateShape(contour, hs);
  } catch {
    return;
  }
  let all = contour;
  for (const h of hs) all = all.concat(h);
  for (const f of faces) {
    const A = all[f[0]],
      B = all[f[1]],
      C2 = all[f[2]];
    if (!A || !B || !C2) continue;
    mb.tri(
      A.x,
      y,
      A.y,
      B.x,
      y,
      B.y,
      C2.x,
      y,
      C2.y,
      0,
      1,
      0,
      A.x * sc,
      A.y * sc,
      B.x * sc,
      B.y * sc,
      C2.x * sc,
      C2.y * sc,
      layer,
      tint
    );
  }
}

function roofFlat(mb: MB, p: number[], holes: number[][] | undefined, top: number, tint: number[]) {
  const o = offsetPoly(p, -0.14),
    n = o.length,
    y0 = top - 0.05,
    y1 = top + 0.34;
  for (let i = 0; i < n; i += 2) {
    const j = (i + 2) % n,
      dx = o[j] - o[i],
      dz = o[j + 1] - o[i + 1],
      l = Math.hypot(dx, dz) || 1;
    mb.quad(
      o[i],
      y0,
      o[i + 1],
      o[j],
      y0,
      o[j + 1],
      o[j],
      y1,
      o[j + 1],
      o[i],
      y1,
      o[i + 1],
      dz / l,
      0,
      -dx / l,
      0,
      0,
      l / 3,
      0.12,
      L.CONCRETE,
      GREY
    );
  }
  cap(mb, o, holes, y1, L.ROOF_FLAT, tint, 1 / 3);
}

function roofGable(
  mb: MB,
  o: OBB,
  top: number,
  rh: number,
  layer: number,
  tint: number[],
  wl: number,
  wt: number[]
) {
  const e = 0.42,
    cx = o.cx,
    cz = o.cz,
    ux = o.ux,
    uz = o.uz,
    a = o.a,
    b = o.b,
    vx = -uz,
    vz = ux,
    A = a + e,
    B = b + e,
    ye = top - (e * rh) / b,
    yr = top + rh;
  const x1 = cx - ux * A + vx * B,
    z1 = cz - uz * A + vz * B,
    x2 = cx + ux * A + vx * B,
    z2 = cz + uz * A + vz * B;
  const x3 = cx + ux * A - vx * B,
    z3 = cz + uz * A - vz * B,
    x4 = cx - ux * A - vx * B,
    z4 = cz - uz * A - vz * B;
  const r1x = cx - ux * A,
    r1z = cz - uz * A,
    r2x = cx + ux * A,
    r2z = cz + uz * A;
  const rise = yr - ye,
    k = 1 / Math.hypot(rise, B),
    sl = Math.hypot(rise, B) / 2;
  mb.quad(x1, ye, z1, x2, ye, z2, r2x, yr, r2z, r1x, yr, r1z, vx * rise * k, B * k, vz * rise * k, 0, 0, A, sl, layer, tint);
  mb.quad(x3, ye, z3, x4, ye, z4, r1x, yr, r1z, r2x, yr, r2z, -vx * rise * k, B * k, -vz * rise * k, 0, 0, A, sl, layer, tint);
  // Roof soffit / eave underside
  mb.quad(x2, ye, z2, x1, ye, z1, r1x, yr - 0.08, r1z, r2x, yr - 0.08, r2z, 0, -1, 0, 0, 0, 1, 1, L.WOOD, SOFFIT);
  mb.quad(x4, ye, z4, x3, ye, z3, r2x, yr - 0.08, r2z, r1x, yr - 0.08, r1z, 0, -1, 0, 0, 0, 1, 1, L.WOOD, SOFFIT);
  for (const s of [1, -1]) {
    const px = cx + ux * a * s,
      pz = cz + uz * a * s;
    mb.tri(
      px + vx * b,
      top,
      pz + vz * b,
      px - vx * b,
      top,
      pz - vz * b,
      px,
      yr,
      pz,
      ux * s,
      0,
      uz * s,
      0,
      0,
      (2 * b) / 3,
      0,
      b / 3,
      rh / 3,
      wl,
      wt
    );
  }
}

function roofHip(mb: MB, o: OBB, top: number, rh: number, layer: number, tint: number[]) {
  const e = 0.42,
    cx = o.cx,
    cz = o.cz,
    ux = o.ux,
    uz = o.uz,
    a = o.a,
    b = o.b,
    vx = -uz,
    vz = ux,
    A = a + e,
    B = b + e,
    ye = top - (e * rh) / b,
    yr = top + rh,
    r = Math.max(0, a - b);
  const x1 = cx - ux * A + vx * B,
    z1 = cz - uz * A + vz * B,
    x2 = cx + ux * A + vx * B,
    z2 = cz + uz * A + vz * B;
  const x3 = cx + ux * A - vx * B,
    z3 = cz + uz * A - vz * B,
    x4 = cx - ux * A - vx * B,
    z4 = cz - uz * A - vz * B;
  const r1x = cx - ux * r,
    r1z = cz - uz * r,
    r2x = cx + ux * r,
    r2z = cz + uz * r;
  const rise = yr - ye,
    k = 1 / Math.hypot(rise, B),
    sl = Math.hypot(rise, B) / 2;
  mb.quad4(
    x1,
    ye,
    z1,
    x2,
    ye,
    z2,
    r2x,
    yr,
    r2z,
    r1x,
    yr,
    r1z,
    vx * rise * k,
    B * k,
    vz * rise * k,
    0,
    0,
    A,
    0,
    (A + r) / 2,
    sl,
    (A - r) / 2,
    sl,
    layer,
    tint
  );
  mb.quad4(
    x3,
    ye,
    z3,
    x4,
    ye,
    z4,
    r1x,
    yr,
    r1z,
    r2x,
    yr,
    r2z,
    -vx * rise * k,
    B * k,
    -vz * rise * k,
    0,
    0,
    A,
    0,
    (A + r) / 2,
    sl,
    (A - r) / 2,
    sl,
    layer,
    tint
  );
  mb.tri(x2, ye, z2, x3, ye, z3, r2x, yr, r2z, ux * rise * k, B * k, uz * rise * k, 0, 0, B, 0, B / 2, sl, layer, tint);
  mb.tri(x4, ye, z4, x1, ye, z1, r1x, yr, r1z, -ux * rise * k, B * k, -uz * rise * k, 0, 0, B, 0, B / 2, sl, layer, tint);
}

function roofInset(mb: MB, p: number[], top: number, layer: number, tint: number[]): number {
  const area2 = Math.abs(polyArea(p)),
    n = p.length;
  let per = 0;
  for (let i = 0; i < n; i += 2) {
    const j = (i + 2) % n;
    per += Math.hypot(p[j] - p[i], p[j + 1] - p[i + 1]);
  }
  const d = Math.min(3.2, (0.45 * 2 * area2) / per),
    sl = 0.75,
    out = offsetPoly(p, -0.35),
    inn = offsetPoly(p, d),
    ye = top - 0.35 * sl,
    yi = top + d * sl,
    k = 1 / Math.hypot(sl, 1);
  for (let i = 0; i < n; i += 2) {
    const j = (i + 2) % n,
      dx = p[j] - p[i],
      dz = p[j + 1] - p[i + 1],
      l = Math.hypot(dx, dz) || 1,
      nx = dz / l,
      nz = -dx / l;
    mb.quad(
      out[i],
      ye,
      out[i + 1],
      out[j],
      ye,
      out[j + 1],
      inn[j],
      yi,
      inn[j + 1],
      inn[i],
      yi,
      inn[i + 1],
      nx * sl * k,
      k,
      nz * sl * k,
      0,
      0,
      l / 2,
      (d + 0.35) * 0.625,
      layer,
      tint
    );
  }
  cap(mb, inn, undefined, yi, layer, tint, 0.5);
  return yi;
}

const CORN = [
  [-1, -1],
  [1, -1],
  [1, 1],
  [-1, 1],
];

function box(
  mb: MB,
  cx: number,
  cz: number,
  ux: number,
  uz: number,
  hu: number,
  hv: number,
  y0: number,
  y1: number,
  layer: number,
  tint: number[],
  bay: number
) {
  const vx = -uz,
    vz = ux;
  for (let i = 0; i < 4; i++) {
    const a = CORN[i],
      b = CORN[(i + 1) % 4];
    const ax = cx + ux * hu * a[0] + vx * hv * a[1],
      az = cz + uz * hu * a[0] + vz * hv * a[1],
      bx = cx + ux * hu * b[0] + vx * hv * b[1],
      bz = cz + uz * hu * b[0] + vz * hv * b[1];
    const dx = bx - ax,
      dz = bz - az,
      l = Math.hypot(dx, dz) || 1;
    let nx = dz / l,
      nz = -dx / l;
    if (((ax + bx) / 2 - cx) * nx + ((az + bz) / 2 - cz) * nz < 0) {
      nx = -nx;
      nz = -nz;
    }
    mb.quad(
      ax,
      y0,
      az,
      bx,
      y0,
      bz,
      bx,
      y1,
      bz,
      ax,
      y1,
      az,
      nx,
      0,
      nz,
      0,
      0,
      Math.max(1, Math.round(l / bay)),
      Math.max(1, Math.round((y1 - y0) / 3)),
      layer,
      tint
    );
  }
}

function pyramid(
  mb: MB,
  cx: number,
  cz: number,
  ux: number,
  uz: number,
  hu: number,
  hv: number,
  y0: number,
  y1: number,
  layer: number,
  tint: number[]
) {
  const vx = -uz,
    vz = ux,
    hgt = y1 - y0;
  for (let i = 0; i < 4; i++) {
    const a = CORN[i],
      b = CORN[(i + 1) % 4];
    const ax = cx + ux * hu * a[0] + vx * hv * a[1],
      az = cz + uz * hu * a[0] + vz * hv * a[1],
      bx = cx + ux * hu * b[0] + vx * hv * b[1],
      bz = cz + uz * hu * b[0] + vz * hv * b[1];
    const mx = (ax + bx) / 2 - cx,
      mz = (az + bz) / 2 - cz,
      ml = Math.hypot(mx, mz) || 1,
      k = 1 / Math.hypot(hgt, ml);
    mb.tri(
      ax,
      y0,
      az,
      bx,
      y0,
      bz,
      cx,
      y1,
      cz,
      (mx / ml) * hgt * k,
      ml * k,
      (mz / ml) * hgt * k,
      0,
      0,
      1,
      0,
      0.5,
      1,
      layer,
      tint
    );
  }
}

function addFenceSpan(
  mb: MB,
  ax: number,
  az: number,
  bx: number,
  bz: number,
  t: Terrain,
  h: number,
  layer: number,
  tint: number[]
) {
  const dx = bx - ax,
    dz = bz - az,
    len = Math.hypot(dx, dz);
  if (len < 0.4) return;
  const nx = dz / len,
    nz = -dx / len;
  const ya = t.h(ax, az) - 0.1,
    yb = t.h(bx, bz) - 0.1;
  const spans = Math.max(1, Math.round(len / 2.6));
  mb.quad(ax, ya, az, bx, yb, bz, bx, yb + h, bz, ax, ya + h, az, nx, 0, nz, 0, 0, spans, 1, layer, tint);
  mb.quad(bx, yb, bz, ax, ya, az, ax, ya + h, az, bx, yb + h, bz, -nx, 0, -nz, 0, 0, spans, 1, layer, tint);
}

export function buildBuildings(w: any, t: Terrain, drive: SegGrid, ch: Chunks) {
  const list: any[] = [],
    signs: any[] = [],
    counts: Record<string, number> = {};
  const GC = 40,
    key = (i: number, j: number) => (i + 512) * 1024 + j + 512;
  const grid = new Map<number, number[]>();
  const polys: number[][] = [];
  w.buildings.forEach((b: any, bi: number) => {
    let p = b.p;
    if (polyArea(p) < 0) {
      const q: number[] = [];
      for (let i = p.length - 2; i >= 0; i -= 2) q.push(p[i], p[i + 1]);
      p = q;
    }
    polys.push(p);
    const c = polyCentroid(p),
      k = key(Math.floor(c[0] / GC), Math.floor(c[1] / GC));
    let a = grid.get(k);
    if (!a) {
      a = [];
      grid.set(k, a);
    }
    a.push(bi);
  });

  const bp: any[][] = w.buildings.map(() => []);
  for (const q of w.points) {
    if (q.k !== "poi" || !q.n) continue;
    const ci = Math.floor(q.x / GC),
      cj = Math.floor(q.z / GC);
    let best = -1,
      bd = 9;
    for (let i = ci - 1; i <= ci + 1; i++)
      for (let j = cj - 1; j <= cj + 1; j++) {
        const a = grid.get(key(i, j));
        if (!a) continue;
        for (const bi of a) {
          const p = polys[bi];
          if (pointInPoly(q.x, q.z, p)) {
            best = bi;
            bd = -1;
            continue;
          }
          for (let e = 0; e < p.length; e += 2) {
            const f = (e + 2) % p.length,
              d = segDist(q.x, q.z, p[e], p[e + 1], p[f], p[f + 1]);
            if (d < bd) {
              bd = d;
              best = bi;
            }
          }
        }
      }
    if (best >= 0) bp[best].push(q);
  }

  // Helper to check if a point is inside any neighboring building
  const nearOtherBuilding = (x: number, z: number, selfIdx: number): boolean => {
    const ci = Math.floor(x / GC),
      cj = Math.floor(z / GC);
    for (let i = ci - 1; i <= ci + 1; i++)
      for (let j = cj - 1; j <= cj + 1; j++) {
        const a = grid.get(key(i, j));
        if (!a) continue;
        for (const bi of a) {
          if (bi === selfIdx) continue;
          const p = polys[bi];
          if (pointInPoly(x, z, p)) return true;
        }
      }
    return false;
  };

  w.buildings.forEach((b: any, bi: number) => one(b, polys[bi], bp[bi], bi));

  // Build all real OSM barriers (w.barriers — fences, walls, hedges)
  for (let bi = 0; bi < (w.barriers || []).length; bi++) {
    const bar = w.barriers[bi];
    const p = bar.p;
    if (!p || p.length < 4) continue;
    const lay = bar.k === "wall" ? L.CONCRETE : bi % 2 === 0 ? L.FENCE_METAL : L.FENCE_WOOD;
    const h = bar.k === "wall" ? 1.85 : 1.55;
    for (let i = 0; i + 3 < p.length; i += 2) {
      const ax = p[i],
        az = p[i + 1],
        bx = p[i + 2],
        bz = p[i + 3];
      if (t.surf(ax, az) === SF.ROAD || t.surf(bx, bz) === SF.ROAD) continue;
      addFenceSpan(ch.at((ax + bx) / 2, (az + bz) / 2), ax, az, bx, bz, t, h, lay, WHITE2);
    }
  }

  return { list, signs, counts };

  function one(b: any, p: number[], ps: any[], selfIdx: number) {
    const area2 = Math.abs(polyArea(p));
    if (area2 < 5) return;
    const c = polyCentroid(p),
      o = obb(p),
      id = b.id | 0,
      n = p.length;
    const r = hash01(id, 11),
      r2 = hash01(id, 23),
      r3 = hash01(id, 37);
    let surf: number = SF.FIELD;
    for (const dd of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ]) {
      const s = t.surf(
        o.cx + o.ux * (o.a + 5) * dd[0] - o.uz * (o.b + 5) * dd[1],
        o.cz + o.uz * (o.a + 5) * dd[0] + o.ux * (o.b + 5) * dd[1]
      );
      if (s !== SF.BUILDING && s !== SF.ROAD && s !== SF.WALK) {
        surf = s;
        if (s === SF.YARD || s === SF.PAVED || s === SF.ALLOT) break;
      }
    }
    const tt = b.t;
    let kind = "house";
    if (tt === "church" || b.am === "place_of_worship") kind = area2 > 150 ? "church" : "chapel";
    else if (tt === "chapel") kind = "chapel";
    else if (tt === "roof" || tt === "carport") kind = "roof";
    else if (tt === "allotment_house" || tt === "hut" || tt === "cabin") kind = "allot";
    else if (
      tt === "outbuilding" ||
      tt === "garage" ||
      tt === "garages" ||
      tt === "shed" ||
      tt === "barn" ||
      tt === "farm_auxiliary" ||
      tt === "service" ||
      tt === "greenhouse"
    )
      kind = "shed";
    else if (tt === "industrial" || tt === "warehouse" || tt === "manufacture" || tt === "hangar") kind = "ind";
    else if (tt === "retail" || tt === "supermarket" || tt === "commercial" || tt === "shop" || tt === "kiosk")
      kind = "shop";
    else if (tt === "apartments" || tt === "dormitory") kind = "block";
    else if (
      tt === "school" ||
      tt === "kindergarten" ||
      tt === "office" ||
      tt === "public" ||
      tt === "government" ||
      tt === "fire_station" ||
      tt === "train_station" ||
      tt === "civic" ||
      tt === "hospital"
    )
      kind = "civic";
    else if (
      tt === "house" ||
      tt === "detached" ||
      tt === "bungalow" ||
      tt === "semidetached_house" ||
      tt === "terrace" ||
      tt === "farm"
    )
      kind = "house";
    else if (area2 < 38) kind = "shed";
    else if (surf === SF.ALLOT) kind = "allot";
    else if (area2 > 260 && surf === SF.PAVED) kind = "ind";
    else if (area2 > 300) kind = surf === SF.YARD ? "block" : surf === SF.FIELD || surf === SF.FARM || surf === SF.MEADOW ? "ind" : "civic";
    else if (area2 < 62 && !b.ad) kind = "shed";
    if (
      b.am === "school" ||
      b.am === "kindergarten" ||
      b.am === "townhall" ||
      b.am === "police" ||
      b.am === "community_centre" ||
      b.am === "library" ||
      b.am === "fire_station"
    )
      kind = "civic";

    // Historic Kolonia Bata zone in Chełmek (czerwona cegła klinkierowa i płaskie dachy)
    const inBataColony = c[0] > -310 && c[0] < 30 && c[1] > -210 && c[1] < 110 && r < 0.45;
    const brick = (b.mat === "brick" || inBataColony) && kind !== "shed" && kind !== "allot" && kind !== "roof";
    const shops = ps.filter(isShop);
    if (shops.length && (kind === "shed" || kind === "allot")) kind = "shop";

    let levels = 1,
      fh = 2.95,
      roof = "flat",
      pitch = 0.78,
      up: number = L.H_WIN,
      gr: number = L.H_WIN,
      door = -1,
      plain: number = L.PLASTER,
      bay = 3.1,
      um = 1,
      tint = WHITE2,
      rl: number = L.ROOF_FLAT,
      rt = WHITE2;
    const pick = (name: string) => PAL[name][(r3 * PAL[name].length) | 0];

    if (kind === "house") {
      levels = b.lv ? b.lv : area2 > 75 && r < 0.62 ? 2 : 1;
      roof = area2 / o.area < 0.7 ? "inset" : r2 < 0.68 ? "gable" : "hip";
      door = L.H_DOOR;
      tint = pick("house");
      rl = L.ROOF_TILE;
      rt = ROOFS[(r * ROOFS.length) | 0];
    } else if (kind === "block") {
      levels = b.lv ? b.lv : 4 + (r < 0.45 ? 1 : 0);
      up = gr = L.B_WIN;
      um = 0.5;
      door = L.H_DOOR;
      tint = pick("block");
    } else if (kind === "shop") {
      levels = b.lv ? b.lv : 1;
      fh = levels === 1 ? 3.85 : 3.45;
      gr = levels === 1 && !shops.length ? L.CIVIC_WIN : L.PLASTER;
      bay = 3.2;
      tint = pick("shop");
    } else if (kind === "ind") {
      fh = 6.5 + r * 3;
      up = gr = L.IND;
      door = L.IND_GATE;
      bay = 6;
      tint = pick("ind");
      rl = L.ROOF_SHEET;
      rt = GREY;
      if (area2 < 600 && r2 < 0.4) {
        roof = "gable";
        pitch = 0.22;
      }
    } else if (kind === "shed") {
      fh = tt === "barn" ? 4.2 : 2.55;
      const g = r < 0.28 ? L.WOOD : r < 0.48 ? L.CONCRETE : L.PLASTER;
      up = gr = plain = g;
      tint = g === L.PLASTER ? pick("shed") : WHITE2;
      if (tt === "garage" || tt === "garages") door = L.GARAGE;
      if (area2 > 42 && r2 < 0.45) {
        roof = "gable";
        pitch = 0.46;
        rl = L.ROOF_SHEET;
        rt = GREY;
      }
    } else if (kind === "allot") {
      fh = 2.4;
      const g = r < 0.52 ? L.WOOD : L.PLASTER;
      up = gr = plain = g;
      tint = g === L.PLASTER ? pick("house") : WHITE2;
      roof = "gable";
      pitch = 0.62;
      rl = L.ROOF_SHEET;
      rt = ROOFS[(r2 * ROOFS.length) | 0];
    } else if (kind === "civic") {
      levels = b.lv ? b.lv : 2 + (r < 0.45 ? 1 : 0);
      fh = 3.35;
      up = gr = L.CIVIC_WIN;
      door = L.SHOP_DOOR;
      bay = 3.6;
      tint = pick("civic");
    } else if (kind === "church" || kind === "chapel") {
      fh = kind === "church" ? 9.2 : 4.6;
      up = gr = L.CHURCH_WIN;
      bay = 4.2;
      tint = pick("church");
      roof = "gable";
      pitch = 1.2;
      rl = L.ROOF_SHEET;
      rt = kind === "church" ? COPPER : ROOFS[1];
      door = L.H_DOOR;
    }

    if (brick) {
      up = gr = L.BRICK_WIN;
      plain = L.BRICK;
      tint = WHITE2;
      um = 1;
      bay = 3;
      if (kind === "house") roof = "flat";
    }
    if (b.roof === "flat") roof = "flat";
    else if ((b.roof === "gabled" || b.roof === "hipped") && roof === "flat") {
      roof = b.roof === "gabled" ? "gable" : "hip";
      rl = L.ROOF_TILE;
      rt = ROOFS[(r * ROOFS.length) | 0];
    }
    levels = Math.max(1, Math.min(12, Math.round(levels)));
    let wallH = levels * fh;
    if (b.ht && b.ht > 2) {
      wallH = roof === "flat" ? b.ht : Math.max(2.2, b.ht - 2);
      fh = wallH / levels;
    }
    let gmin = Infinity,
      gmax = -Infinity,
      x0 = Infinity,
      x1 = -Infinity,
      z0 = Infinity,
      z1 = -Infinity;
    for (let i = 0; i < n; i += 2) {
      const h = t.h(p[i], p[i + 1]);
      if (h < gmin) gmin = h;
      if (h > gmax) gmax = h;
      if (p[i] < x0) x0 = p[i];
      if (p[i] > x1) x1 = p[i];
      if (p[i + 1] < z0) z0 = p[i + 1];
      if (p[i + 1] > z1) z1 = p[i + 1];
    }
    const base = gmin + 0.75 * (gmax - gmin) + 0.12,
      bottom = gmin - 0.8,
      top = base + wallH;
    const mb = ch.at(c[0], c[1]);
    counts[kind] = (counts[kind] || 0) + 1;

    if (kind === "roof") {
      roofFlat(mb, p, undefined, base + 4.2, WHITE2);
      for (let i = 0; i < n; i += 2)
        box(
          mb,
          p[i] + (c[0] - p[i]) * 0.1,
          p[i + 1] + (c[1] - p[i + 1]) * 0.1,
          1,
          0,
          0.14,
          0.14,
          bottom,
          base + 4.2,
          L.CONCRETE,
          GREY,
          3
        );
      return;
    }

    let front = 0,
      fs = -1,
      dirx = 0,
      dirz = 0;
    const si = drive.nearest(c[0], c[1], 70);
    if (si >= 0) {
      const s = drive.s,
        q = si * 5;
      dirx = s[q] + (s[q + 2] - s[q]) * drive.nt - c[0];
      dirz = s[q + 1] + (s[q + 3] - s[q + 1]) * drive.nt - c[1];
      const dl = Math.hypot(dirx, dirz) || 1;
      dirx /= dl;
      dirz /= dl;
    }
    for (let i = 0; i < n; i += 2) {
      const j = (i + 2) % n,
        dx = p[j] - p[i],
        dz = p[j + 1] - p[i + 1],
        len = Math.hypot(dx, dz);
      if (len < 2) continue;
      const sc = (si >= 0 ? Math.max(0.05, (dz * dirx - dx * dirz) / len) : 1) * Math.sqrt(len);
      if (sc > fs) {
        fs = sc;
        front = i / 2;
      }
    }

    // Generate Homestead Property Fence (Ogrodzenia wokół domostw jednorodzinnych i działek)
    if ((kind === "house" || kind === "allot") && area2 < 240 && o.a < 15 && o.b < 13) {
      const padU = kind === "allot" ? 2.6 : 4.2 + (r * 1.8);
      const padV = kind === "allot" ? 2.4 : 3.6 + (r2 * 1.6);
      const vx = -o.uz,
        vz = o.ux;
      const fA = o.a + padU,
        fB = o.b + padV;
      const fc = [
        [o.cx - o.ux * fA - vx * fB, o.cz - o.uz * fA - vz * fB],
        [o.cx + o.ux * fA - vx * fB, o.cz + o.uz * fA - vz * fB],
        [o.cx + o.ux * fA + vx * fB, o.cz + o.uz * fA + vz * fB],
        [o.cx - o.ux * fA + vx * fB, o.cz - o.uz * fA + vz * fB],
      ];
      let validPlot = true;
      for (const pt of fc) {
        const sf = t.surf(pt[0], pt[1]);
        if (sf === SF.ROAD || sf === SF.WATER || sf === SF.RAIL || nearOtherBuilding(pt[0], pt[1], selfIdx)) {
          validPlot = false;
          break;
        }
      }
      if (validPlot) {
        const fLay = r3 < 0.55 ? L.FENCE_WOOD : L.FENCE_METAL;
        const fh2 = kind === "allot" ? 1.25 : 1.48;
        // Find which side of the 4-sided plot faces the street (dirx, dirz)
        let gateSide = 0,
          bestDot = -2;
        for (let s = 0; s < 4; s++) {
          const p0 = fc[s],
            p1 = fc[(s + 1) % 4];
          const mx = (p0[0] + p1[0]) / 2 - o.cx,
            mz = (p0[1] + p1[1]) / 2 - o.cz;
          const ml = Math.hypot(mx, mz) || 1;
          const dot = (mx / ml) * dirx + (mz / ml) * dirz;
          if (dot > bestDot) {
            bestDot = dot;
            gateSide = s;
          }
        }
        for (let s = 0; s < 4; s++) {
          const p0 = fc[s],
            p1 = fc[(s + 1) % 4];
          // Corner clinker/concrete pillar
          const py0 = t.h(p0[0], p0[1]) - 0.15;
          box(mb, p0[0], p0[1], o.ux, o.uz, 0.18, 0.18, py0, py0 + fh2 + 0.12, L.BRICK, BRICK_POST, 1);
          if (s === gateSide) {
            // Leave an open 3.2m driveway entrance gate in the middle of the front fence!
            const gx0 = p0[0] + (p1[0] - p0[0]) * 0.34,
              gz0 = p0[1] + (p1[1] - p0[1]) * 0.34;
            const gx1 = p0[0] + (p1[0] - p0[0]) * 0.66,
              gz1 = p0[1] + (p1[1] - p0[1]) * 0.66;
            addFenceSpan(mb, p0[0], p0[1], gx0, gz0, t, fh2, fLay, WHITE2);
            addFenceSpan(mb, gx1, gz1, p1[0], p1[1], t, fh2, fLay, WHITE2);
            // Gate posts
            const gy0 = t.h(gx0, gz0) - 0.15,
              gy1 = t.h(gx1, gz1) - 0.15;
            box(mb, gx0, gz0, o.ux, o.uz, 0.2, 0.2, gy0, gy0 + fh2 + 0.18, L.BRICK, BRICK_POST, 1);
            box(mb, gx1, gz1, o.ux, o.uz, 0.2, 0.2, gy1, gy1 + fh2 + 0.18, L.BRICK, BRICK_POST, 1);
            // Paved driveway / cobblestone path from the front gate into the homestead yard
            const dx0 = gx0 + (o.cx - gx0) * 0.55,
              dz0 = gz0 + (o.cz - gz0) * 0.55;
            const dx1 = gx1 + (o.cx - gx1) * 0.55,
              dz1 = gz1 + (o.cz - gz1) * 0.55;
            const pyA = t.h(gx0, gz0) + 0.05,
              pyB = t.h(gx1, gz1) + 0.05,
              pyC = t.h(dx1, dz1) + 0.05,
              pyD = t.h(dx0, dz0) + 0.05;
            mb.quad(gx0, pyA, gz0, gx1, pyB, gz1, dx1, pyC, dz1, dx0, pyD, dz0, 0, 1, 0, 0, 0, 1.5, 2.5, L.PAVING, WHITE2);
          } else {
            addFenceSpan(mb, p0[0], p0[1], p1[0], p1[1], t, fh2, fLay, WHITE2);
          }
        }
      }
    }

    const par = (q: any, e: number) => {
      const i = e * 2,
        j = (i + 2) % n;
      segDist(q.x, q.z, p[i], p[i + 1], p[j], p[j + 1]);
      return segT;
    };
    const edgeP = new Map<number, any[]>();
    const seen: Record<string, number> = {};
    for (const q of ps) {
      const nm = q.n;
      if (seen[nm]) continue;
      seen[nm] = 1;
      let be = front,
        bd = 2.5;
      for (let i = 0; i < n; i += 2) {
        const j = (i + 2) % n,
          d = segDist(q.x, q.z, p[i], p[i + 1], p[j], p[j + 1]);
        if (d < bd && Math.hypot(p[j] - p[i], p[j + 1] - p[i + 1]) > 2.2) {
          bd = d;
          be = i / 2;
        }
      }
      let a = edgeP.get(be);
      if (!a) {
        a = [];
        edgeP.set(be, a);
      }
      a.push(q);
    }
    const shopE = new Set<number>();
    edgeP.forEach((qs, e) => {
      if (qs.some(isShop)) shopE.add(e);
    });
    if (kind === "shop" && !shopE.size) shopE.add(front);

    const ring = (q: number[], flip: boolean, outer: boolean) => {
      const m = q.length;
      for (let i = 0; i < m; i += 2) {
        const j = (i + 2) % m,
          e = i / 2,
          ax = q[i],
          az = q[i + 1],
          dx = q[j] - ax,
          dz = q[j + 1] - az,
          len = Math.hypot(dx, dz);
        if (len < 0.08) continue;
        const sg = flip ? -1 : 1,
          nx = (dz / len) * sg,
          nz = (-dx / len) * sg;
        const seg = (t0: number, t1: number, y0: number, y1: number, layer: number, u1: number, v1: number) =>
          mb.quad(
            ax + dx * t0,
            y0,
            az + dz * t0,
            ax + dx * t1,
            y0,
            az + dz * t1,
            ax + dx * t1,
            y1,
            az + dz * t1,
            ax + dx * t0,
            y1,
            az + dz * t0,
            nx,
            0,
            nz,
            0,
            0,
            u1,
            v1,
            layer,
            tint
          );
        // Foundation plinth (cokół fundamentowy)
        mb.quad(
          ax,
          bottom,
          az,
          ax + dx,
          bottom,
          az + dz,
          ax + dx,
          base,
          az + dz,
          ax,
          base,
          az,
          nx,
          0,
          nz,
          0,
          0,
          len / 3,
          (base - bottom) / 3,
          L.CONCRETE,
          GREY
        );
        const small = len < 1.7,
          nb = Math.max(1, Math.round(len / bay)),
          yg = base + fh;
        if (small) seg(0, 1, base, yg, plain, len / 3, 1);
        else if (outer && shopE.has(e)) {
          const sb = Math.max(1, Math.round(len / 3.2));
          if (sb === 1) seg(0, 1, base, yg, L.SHOP_DOOR, 1, 1);
          else {
            const k = sb >> 1;
            seg(0, k / sb, base, yg, L.SHOP, k, 1);
            seg(k / sb, (k + 1) / sb, base, yg, L.SHOP_DOOR, 1, 1);
            if (k + 1 < sb) seg((k + 1) / sb, 1, base, yg, L.SHOP, sb - k - 1, 1);
          }
        } else if (outer && e === front && door >= 0 && len > 2.4) {
          if (door === L.GARAGE && len < 7) seg(0, 1, base, yg, L.GARAGE, Math.max(1, Math.round(len / 3)), 1);
          else {
            const k = nb >> 1;
            if (k > 0) seg(0, k / nb, base, yg, gr, k * um, 1);
            seg(k / sbOrNb(nb), (k + 1) / sbOrNb(nb), base, yg, door, 1, 1);
            if (k + 1 < nb) seg((k + 1) / nb, 1, base, yg, gr, (nb - k - 1) * um, 1);
          }
        } else seg(0, 1, base, yg, gr, nb * um, 1);
        if (levels > 1) seg(0, 1, yg, base + wallH, small ? plain : up, small ? len / 3 : nb * um, levels - 1);
      }
    };
    const sbOrNb = (v: number) => v;

    ring(p, false, true);
    if (b.holes) for (const h of b.holes) ring(h, polyArea(h) > 0, false);

    let rtop = top;
    if (roof === "flat") {
      roofFlat(mb, p, b.holes, top, WHITE2);
      rtop = top + 0.34;
    } else if (roof === "inset") rtop = roofInset(mb, p, top, rl, rt);
    else {
      const rh = Math.min(kind === "church" ? 9.2 : 4.8, Math.max(0.55, o.b * pitch));
      rtop = top + rh;
      if (roof === "hip") roofHip(mb, o, top, rh, rl, rt);
      else roofGable(mb, o, top, rh, rl, rt, plain, tint);
      // Brick chimneys on houses & blocks
      if ((kind === "house" || kind === "civic") && r3 < 0.85) {
        const chX = o.cx + o.ux * o.a * 0.38 - o.uz * o.b * 0.22;
        const chZ = o.cz + o.uz * o.a * 0.38 + o.ux * o.b * 0.22;
        box(mb, chX, chZ, o.ux, o.uz, 0.32, 0.32, top, top + rh + 0.65, L.BRICK, WHITE2, 3);
        box(mb, chX, chZ, o.ux, o.uz, 0.38, 0.38, top + rh + 0.65, top + rh + 0.74, L.CONCRETE, GREY, 1);
      }
      if (kind === "church") {
        const sg = o.ux * dirx + o.uz * dirz >= 0 ? 1 : -1,
          tx = o.cx + o.ux * (o.a - 2.2) * sg,
          tz = o.cz + o.uz * (o.a - 2.2) * sg,
          th = top + rh + 7.5;
        box(mb, tx, tz, o.ux, o.uz, 2.75, 2.75, base, th, L.PLASTER, tint, 3);
        pyramid(mb, tx, tz, o.ux, o.uz, 3.0, 3.0, th, th + 8.0, L.ROOF_SHEET, COPPER);
        rtop = th + 8.0;
      }
    }
    list.push({ p, x0, x1, z0, z1, top: rtop, kind });

    edgeP.forEach((qs, e) => {
      const i = e * 2,
        j = (i + 2) % n,
        dx = p[j] - p[i],
        dz = p[j + 1] - p[i + 1],
        len = Math.hypot(dx, dz);
      if (len < 1.8) return;
      const nx = dz / len,
        nz = -dx / len;
      qs.sort((a, b2) => par(a, e) - par(b2, e));
      qs.forEach((q, k) => {
        const nm = q.n,
          tp = (k + 0.5) / qs.length,
          wd = Math.min(len / qs.length - 0.3, Math.max(1.6, 0.34 * nm.length + 0.7), 7);
        if (wd < 1) return;
        const sy = levels === 1 ? base + Math.min(wallH - 0.45, 3.25) : base + Math.min(fh - 0.42, 3.05);
        signs.push({ text: nm, x: p[i] + dx * tp, y: sy, z: p[i + 1] + dz * tp, nx, nz, w: wd });
      });
    });
  }
}

export class BldIndex {
  cell = 32;
  map = new Map<number, number[]>();
  list: any[];
  constructor(list: any[]) {
    this.list = list;
    list.forEach((b, i) => {
      const c = this.cell;
      for (let x = Math.floor((b.x0 - 3) / c); x <= Math.floor((b.x1 + 3) / c); x++)
        for (let z = Math.floor((b.z0 - 3) / c); z <= Math.floor((b.z1 + 3) / c); z++) {
          const k = (x + 512) * 1024 + z + 512;
          let a = this.map.get(k);
          if (!a) {
            a = [];
            this.map.set(k, a);
          }
          a.push(i);
        }
    });
  }
  push(x: number, z: number, r: number, out: number[]): boolean {
    let hit = false;
    for (let pass = 0; pass < 2; pass++) {
      const a = this.map.get((Math.floor(x / this.cell) + 512) * 1024 + Math.floor(z / this.cell) + 512);
      if (!a) break;
      let moved = false;
      for (const bi of a) {
        const b = this.list[bi];
        if (x + r < b.x0 || x - r > b.x1 || z + r < b.z0 || z - r > b.z1) continue;
        const p = b.p,
          n = p.length;
        let bd = 1e9,
          qx = 0,
          qz = 0,
          onx = 0,
          onz = 0;
        for (let i = 0; i < n; i += 2) {
          const j = (i + 2) % n,
            d = segDist(x, z, p[i], p[i + 1], p[j], p[j + 1]);
          if (d < bd) {
            bd = d;
            const ex = p[j] - p[i],
              ez = p[j + 1] - p[i + 1],
              el = Math.hypot(ex, ez) || 1;
            qx = p[i] + ex * segT;
            qz = p[i + 1] + ez * segT;
            onx = ez / el;
            onz = -ex / el;
          }
        }
        if (pointInPoly(x, z, p)) {
          x = qx + onx * (r + 0.02);
          z = qz + onz * (r + 0.02);
          moved = hit = true;
        } else if (bd < r) {
          let vx = x - qx,
            vz = z - qz;
          const vl = Math.hypot(vx, vz);
          if (vl > 1e-4) {
            vx /= vl;
            vz /= vl;
          } else {
            vx = onx;
            vz = onz;
          }
          x = qx + vx * r;
          z = qz + vz * r;
          moved = hit = true;
        }
      }
      if (!moved) break;
    }
    out[0] = x;
    out[1] = z;
    return hit;
  }
}

const BRANDS = [
  ["żabka", "#1c8f3f", "#ffffff"],
  ["biedronka", "#f6c300", "#d21f1f"],
  ["lidl", "#0050aa", "#ffe500"],
  ["rossmann", "#ffffff", "#c8102e"],
  ["pko", "#0b2a5b", "#ffffff"],
  ["poczta", "#d81e05", "#ffd200"],
  ["avia", "#d2001a", "#ffffff"],
  ["delikatesy", "#c8102e", "#ffffff"],
  ["abc", "#e30613", "#ffed00"],
  ["ruch", "#00843d", "#ffffff"],
  ["apteka", "#0a8f4f", "#ffffff"],
  ["kino", "#1b1b1f", "#f2c14e"],
  ["ptyś", "#5a2d18", "#f7e3b5"],
  ["kafka", "#1e2e26", "#f4c868"],
];

const SIGNPAL = [
  ["#22303f", "#f3ead7"],
  ["#7a1f1f", "#ffffff"],
  ["#f3ead7", "#22262c"],
  ["#1f5f4a", "#ffffff"],
  ["#2d3e8f", "#ffffff"],
  ["#e2a04a", "#12151b"],
];

export function buildSigns(signs: any[], aniso: number): Mesh | null {
  if (!signs.length) return null;
  const CW = 512,
    CH = 64,
    COLS = 4,
    ROWS = 36,
    cv = document.createElement("canvas");
  cv.width = COLS * CW;
  cv.height = ROWS * CH;
  const c = cv.getContext("2d")!;
  c.fillStyle = "#333";
  c.fillRect(0, 0, cv.width, cv.height);
  const pos: number[] = [],
    uv: number[] = [],
    nor: number[] = [],
    idx: number[] = [];
  signs.slice(0, COLS * ROWS).forEach((s, k) => {
    const x0 = (k % COLS) * CW,
      y0 = ((k / COLS) | 0) * CH,
      low = s.text.toLowerCase();
    let cols = SIGNPAL[0];
    let h = 0;
    for (let i2 = 0; i2 < s.text.length; i2++) h = (h * 31 + s.text.charCodeAt(i2)) | 0;
    cols = SIGNPAL[Math.abs(h) % SIGNPAL.length];
    for (const b of BRANDS)
      if (low.indexOf(b[0]) >= 0) {
        cols = [b[1], b[2]];
        break;
      }
    c.fillStyle = cols[0];
    c.fillRect(x0, y0, CW, CH);
    c.strokeStyle = "rgba(0,0,0,0.35)";
    c.lineWidth = 3;
    c.strokeRect(x0 + 2, y0 + 2, CW - 4, CH - 4);
    c.fillStyle = cols[1];
    c.textAlign = "center";
    c.textBaseline = "middle";
    let fs = 42;
    c.font = "bold " + fs + "px system-ui, Arial, sans-serif";
    const tw = c.measureText(s.text).width;
    if (tw > CW - 28) {
      fs = Math.max(14, Math.floor((fs * (CW - 28)) / tw));
      c.font = "bold " + fs + "px system-ui, Arial, sans-serif";
    }
    c.fillText(s.text, x0 + CW / 2, y0 + CH / 2 + 2);
    const tx = -s.nz,
      tz = s.nx,
      hw = s.w / 2,
      hh = s.w / 16,
      ox = s.x + s.nx * 0.07,
      oz = s.z + s.nz * 0.07,
      i = pos.length / 3;
    pos.push(
      ox - tx * hw,
      s.y - hh,
      oz - tz * hw,
      ox + tx * hw,
      s.y - hh,
      oz + tz * hw,
      ox + tx * hw,
      s.y + hh,
      oz + tz * hw,
      ox - tx * hw,
      s.y + hh,
      oz - tz * hw
    );
    const u0 = x0 / cv.width,
      u1 = (x0 + CW) / cv.width,
      v1 = 1 - y0 / cv.height,
      v0 = 1 - (y0 + CH) / cv.height;
    uv.push(u1, v0, u0, v0, u0, v1, u1, v1);
    for (let q = 0; q < 4; q++) nor.push(s.nx, 0, s.nz);
    idx.push(i, i + 2, i + 1, i, i + 3, i + 2);
  });
  const tex = new CanvasTexture(cv);
  tex.colorSpace = SRGBColorSpace;
  tex.anisotropy = aniso;
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new Float32BufferAttribute(nor, 3));
  g.setAttribute("uv", new Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  return new Mesh(g, new MeshStandardMaterial({ map: tex, roughness: 0.5, metalness: 0.05 }));
}
