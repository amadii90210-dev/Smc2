import {
  ACESFilmicToneMapping,
  DirectionalLight,
  FogExp2,
  HalfFloatType,
  HemisphereLight,
  Mesh,
  PCFSoftShadowMap,
  PerspectiveCamera,
  PMREMGenerator,
  Scene,
  Vector2,
  Vector3,
  WebGLRenderer,
  WebGLRenderTarget,
} from "three";
import { Sky } from "three/examples/jsm/objects/Sky.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { SSAOPass } from "three/examples/jsm/postprocessing/SSAOPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { createCityAction } from "./cityAction";
import { BldIndex, buildBuildings, buildSigns } from "./buildings";
import { WORLD } from "./config";
import { U } from "./env";
import { buildFx } from "./fx";
import { hash01, pointInPoly, polyCentroid, segDist } from "./geo";
import { Chunks, worldMaterial } from "./mb";
import { buildBike, buildCar, buildPlayer } from "./models";
import { buildProps } from "./props";
import { buildRoads, deckAt, prepRoads, streamBuilder } from "./roads";
import { SF, Terrain, terrainMaterial, waterMaterial } from "./terrain";
import { detailTexture, makeArrayTexture } from "./tex";
import { makeUI } from "./ui";
import { buildVegetation } from "./veg";

const QUAL: Record<string, any> = {
  test: {
    tex: 128,
    shadow: 1024,
    px: 1,
    far: 2600,
    near: 110,
    tfar: 800,
    dens: 0.25,
    aniso: 2,
    grass: 5000,
    flowers: 800,
    parts: 200,
    gsize: 50,
    lights: 3,
    post: true,
  },
  low: {
    tex: 256,
    shadow: 1024,
    px: 1.25,
    far: 1800,
    near: 75,
    tfar: 600,
    dens: 0.5,
    aniso: 2,
    grass: 8000,
    flowers: 1200,
    parts: 250,
    gsize: 46,
    lights: 3,
    post: false,
  },
  mid: {
    tex: 256,
    shadow: 2048,
    px: 1.5,
    far: 3000,
    near: 130,
    tfar: 950,
    dens: 0.82,
    aniso: 4,
    grass: 22000,
    flowers: 3200,
    parts: 500,
    gsize: 62,
    lights: 5,
    post: true,
  },
  high: {
    tex: 512,
    shadow: 4096,
    px: 2,
    far: 4600,
    near: 190,
    tfar: 1400,
    dens: 1,
    aniso: 8,
    grass: 44000,
    flowers: 6400,
    parts: 900,
    gsize: 78,
    lights: 7,
    post: true,
  },
};

const TIMES = [
  {
    n: "Złota godzina (UE5 Lumen)",
    s: "Ciepłe światło popołudniowe i miękkie cienie",
    el: 17,
    az: 238,
    li: 3.15,
    lc: 0xffdfb0,
    he: 0.44,
    env: 0.58,
    ex: 0.68,
    fog: 0xd8c3ab,
    night: 0.16,
    lamp: 0.35,
    cl: [2.15, 1.68, 1.25],
  },
  {
    n: "Dzień",
    s: "Słoneczne południe nad Gminą Chełmek",
    el: 48,
    az: 150,
    li: 3.1,
    lc: 0xfff5dc,
    he: 0.42,
    env: 0.54,
    ex: 0.62,
    fog: 0xc2d6e6,
    night: 0,
    lamp: 0,
    cl: [2.1, 2.1, 2.15],
  },
  {
    n: "Zachód słońca",
    s: "Klimatyczny zmierzch i latarnie",
    el: 5,
    az: 262,
    li: 2.35,
    lc: 0xff9a5a,
    he: 0.32,
    env: 0.5,
    ex: 0.72,
    fog: 0xe0a67a,
    night: 0.45,
    lamp: 0.72,
    cl: [2.05, 1.18, 0.82],
  },
  {
    n: "Noc",
    s: "Świecą okna domostw i latarnie uliczne",
    el: -18,
    az: 300,
    li: 0.38,
    lc: 0x9db8ff,
    he: 0.22,
    env: 0.36,
    ex: 0.92,
    fog: 0x0b1220,
    night: 1,
    lamp: 1,
    cl: [0.07, 0.08, 0.12],
  },
];

export async function startGame(
  container: HTMLElement,
  uiRoot: HTMLElement,
  world: any,
  opts: { test: boolean; quality: string },
  progress: (f: number, msg: string) => void
) {
  const step = (f: number, m: string) => {
    progress(f, m);
    return new Promise((r) => setTimeout(r, 20));
  };
  const mobile = matchMedia("(pointer: coarse)").matches || Math.min(innerWidth, innerHeight) < 540;
  const qn = opts.test ? "test" : QUAL[opts.quality] ? opts.quality : mobile ? "low" : "high";
  const Q = QUAL[qn],
    diag: any = { q: qn, t: {} };
  let tm = performance.now();
  const lap = (k: string) => {
    const n = performance.now();
    diag.t[k] = Math.round(n - tm);
    tm = n;
  };
  const W = () => container.clientWidth || innerWidth,
    H = () => container.clientHeight || innerHeight;

  const renderer = new WebGLRenderer({
    antialias: true,
    powerPreference: "high-performance",
    preserveDrawingBuffer: opts.test,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, Q.px));
  renderer.setSize(W(), H());
  renderer.shadowMap.enabled = Q.shadow > 0;
  renderer.shadowMap.type = PCFSoftShadowMap;
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.68;
  container.appendChild(renderer.domElement);

  const scene = new Scene(),
    camera = new PerspectiveCamera(60, W() / H(), 0.3, Q.far + 600);
  const sunDir = new Vector3(0.335, 0.743, 0.579).normalize(),
    skyDir = sunDir.clone(),
    upV = new Vector3(0, 1, 0);
  const mkSky = (s: number) => {
    const k = new Sky();
    k.scale.setScalar(s);
    const u = k.material.uniforms;
    u.turbidity.value = 3.6;
    u.rayleigh.value = 1.45;
    u.mieCoefficient.value = 0.0045;
    u.mieDirectionalG.value = 0.84;
    u.sunPosition.value.copy(sunDir);
    return k;
  };
  const sky = mkSky(Q.far);
  scene.add(sky);
  const pm = new PMREMGenerator(renderer),
    envScene = new Scene(),
    envSky = mkSky(1000);
  envScene.add(envSky);
  let envRT: WebGLRenderTarget | null = null;
  scene.fog = new FogExp2(0xd8c3ab, 1.75 / Q.far);

  const sun = new DirectionalLight(0xffdfb0, 3.15);
  scene.add(sun, sun.target);
  const SR = 115;
  if (Q.shadow) {
    sun.castShadow = true;
    sun.shadow.mapSize.set(Q.shadow, Q.shadow);
    const c = sun.shadow.camera;
    c.left = -SR;
    c.right = SR;
    c.top = SR;
    c.bottom = -SR;
    c.near = 20;
    c.far = 800;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.045;
  }
  const hemi = new HemisphereLight(0xcfe4ff, 0x776858, 0.44);
  scene.add(hemi);
  lap("init");

  await step(0.12, "Generowanie tekstur PBR…");
  const aniso = Math.min(Q.aniso, renderer.capabilities.getMaxAnisotropy());
  const atex = makeArrayTexture(Q.tex, aniso);
  lap("tex");

  await step(0.22, "Rzeźba terenu, nasypy kolejowe i drogi Gminy Chełmek…");
  const terrain = new Terrain(world),
    net = prepRoads(world);
  terrain.buildMask(world, net.strokes);
  terrain.carve(world, net.strokes);
  lap("terrain");

  const chRoad = new Chunks(256),
    chBld = new Chunks(192);
  buildRoads(net, world, terrain, chRoad);
  lap("roads");

  await step(0.4, "Budynki, ogrodzenia domostw i mosty (Chełmek, Gorzów, Bobrek)…");
  const bl = buildBuildings(world, terrain, net.drive, chBld),
    bidx = new BldIndex(bl.list);
  lap("buildings");

  const groundTex = terrain.groundTexture(),
    heightTex = terrain.heightTexture();
  scene.add(terrain.meshes(terrainMaterial(terrain, groundTex, detailTexture())));
  scene.add(chRoad.meshes(worldMaterial(atex, 2), false, true), chBld.meshes(worldMaterial(atex, 0), true, true));
  const sg = buildSigns(bl.signs, aniso);
  if (sg) scene.add(sg);
  scene.add(new Mesh(terrain.waterGeometry(), waterMaterial(false)));
  const sbg = streamBuilder(world, terrain).geometry();
  if (sbg) scene.add(new Mesh(sbg, waterMaterial(true)));
  lap("meshes");

  await step(0.58, "Roślinność 3D i skały wapienne…");
  const veg = buildVegetation(world, terrain, { near: Q.near, far: Q.tfar, density: Q.dens });
  scene.add(veg.group);
  lap("veg");

  await step(0.72, "Place zabaw, kawiarnie, ogródki, latarnie i wieża widokowa…");
  const props = buildProps(world, terrain, net, Q.lights);
  scene.add(props.group);
  const fx = buildFx(terrain, groundTex, heightTex, Q);
  scene.add(fx.group);
  lap("props");

  await step(0.84, "Pojazdy i system nawigacji GPS…");
  const ground = (x: number, z: number, y: number) => {
    let g = terrain.h(x, z);
    const s = terrain.surf(x, z);
    if (s === SF.ROAD) g += 0.1;
    else if (s === SF.WALK || s === SF.DIRT) g += 0.07;
    if (net.decks.length) {
      const d = deckAt(net, x, z, y);
      if (d > g) g = d;
    }
    return g;
  };
  const out = [0, 0];
  const resolve = (x: number, z: number, r: number) => {
    let hit = bidx.push(x, z, r, out);
    if (veg.push(out[0], out[1], r, out)) hit = true;
    out[0] = Math.max(WORLD.x0 + 12, Math.min(WORLD.x1 - 12, out[0]));
    out[1] = Math.max(WORLD.z0 + 12, Math.min(WORLD.z1 - 12, out[1]));
    return hit;
  };
  const inBld = (x: number, z: number, y: number) => {
    const a = bidx.map.get((Math.floor(x / 32) + 512) * 1024 + Math.floor(z / 32) + 512);
    if (!a) return false;
    for (const bi of a) {
      const b = bidx.list[bi];
      if (x < b.x0 || x > b.x1 || z < b.z0 || z > b.z1 || y > b.top) continue;
      if (pointInPoly(x, z, b.p)) return true;
    }
    return false;
  };
  const camFrac = (tx: number, ty: number, tz: number, cx: number, cy: number, cz: number) => {
    const dx = cx - tx,
      dy = cy - ty,
      dz = cz - tz,
      n = Math.max(2, Math.ceil(Math.hypot(dx, dz) / 0.6));
    for (let i = 1; i <= n; i++) {
      const f = i / n,
        x = tx + dx * f,
        y = ty + dy * f,
        z = tz + dz * f;
      if (inBld(x, z, y) || y < terrain.h(x, z) + 0.4) return Math.max(0.12, (i - 1) / n);
    }
    return 1;
  };

  const places = world.points.filter((p: any) => p.k === "place" && p.n && p.v !== "town");
  const placeAt = (x: number, z: number) => {
    let best = "Chełmek",
      bd = 750;
    for (const p of places) {
      const d = Math.hypot(p.x - x, p.z - z);
      if (d < bd) {
        bd = d;
        best = p.n;
      }
    }
    return best;
  };
  const streetAt = (x: number, z: number) => {
    let name = "",
      bd = 48;
    const s = net.all.s;
    net.all.near(x, z, 48, (si: number) => {
      const o = si * 5,
        r = net.roads[Math.floor(s[o + 4] / 4096)];
      if (!r.name) return;
      const d = segDist(x, z, s[o], s[o + 1], s[o + 2], s[o + 3]);
      if (d < bd) {
        bd = d;
        name = r.name;
      }
    });
    return name;
  };

  let sx = 0,
    sz = 0,
    sh = 0,
    sbd = 1e9;
  for (const r of net.roads) {
    if (r.k !== "tertiary" && r.k !== "secondary" && r.k !== "residential") continue;
    for (let i = 0; i + 1 < r.p.length / 2; i++) {
      const d = Math.hypot(r.p[i * 2], r.p[i * 2 + 1]);
      if (d < sbd) {
        sbd = d;
        sx = r.p[i * 2];
        sz = r.p[i * 2 + 1];
        sh = Math.atan2(r.p[i * 2 + 2] - sx, r.p[i * 2 + 3] - sz);
      }
    }
  }
  const fwx = Math.sin(sh),
    fwz = Math.cos(sh),
    rgx = -fwz,
    rgz = fwx;
  const S: any = {
    px: sx - rgx * 2.2,
    pz: sz - rgz * 2.2,
    py: 0,
    vy: 0,
    yaw: sh,
    speed: 0,
    veh: null,
    cam: 0,
    camYaw: sh,
    camPitch: 0.28,
    dragT: 0,
    started: false,
    walk: 0,
    time: 0,
    post: !!Q.post,
    tower: false,
  };
  const input: any = {
    mx: 0,
    my: 0,
    gas: 0,
    brake: 0,
    sprint: false,
    jump: false,
    act: false,
    camNext: false,
    timeNext: false,
    lookX: 0,
    lookY: 0,
  };
  const keys: Record<string, boolean> = {};

  const player = buildPlayer();
  scene.add(player.g);
  const vehs: any[] = [];
  function placeVeh(v: any, dt: number) {
    const bike = v.kind === 1,
      L2 = bike ? 0.55 : 1.4,
      W2 = bike ? 0 : 0.85,
      fx2 = Math.sin(v.h),
      fz2 = Math.cos(v.h),
      lx = fz2,
      lz = -fx2;
    const y0 = ground(v.x, v.z, v.y + 1),
      hf = ground(v.x + fx2 * L2, v.z + fz2 * L2, v.y + 1),
      hb = ground(v.x - fx2 * L2, v.z - fz2 * L2, v.y + 1);
    const hl = W2 ? ground(v.x + lx * W2, v.z + lz * W2, v.y + 1) : y0,
      hr = W2 ? ground(v.x - lx * W2, v.z - lz * W2, v.y + 1) : y0;
    const ty = W2 ? (hf + hb + hl + hr) / 4 : (hf + hb) / 2,
      k = Math.min(1, dt * 12);
    v.y += (ty - v.y) * k;
    const pitch = Math.atan2(hf - hb, 2 * L2),
      roll = W2 ? Math.atan2(hl - hr, 2 * W2) : v.steer * Math.min(0.5, Math.abs(v.v) * 0.045);
    const m = v.mesh;
    m.position.set(v.x, v.y, v.z);
    m.rotation.order = "YXZ";
    m.rotation.y = v.h;
    m.rotation.x += (-pitch - m.rotation.x) * k;
    m.rotation.z += (roll - m.rotation.z) * k;
    for (let i = 0; i < v.wheels.length; i++) {
      const w = v.wheels[i];
      w.rotation.x += (v.v * dt) / v.wr;
      if (i < 2) w.rotation.y = -v.steer * 0.42;
    }
  }
  const addVeh = (mesh: any, kind: number, x: number, z: number, h: number, max: number, acc: number, name: string) => {
    const v = {
      mesh,
      kind,
      x,
      z,
      y: ground(x, z, 1e9),
      h,
      v: 0,
      max,
      acc,
      name,
      wheels: mesh.userData.wheels || [],
      steer: 0,
      wr: mesh.userData.wr || 0.36,
    };
    scene.add(mesh);
    vehs.push(v);
    placeVeh(v, 1);
    return v;
  };

  addVeh(buildCar("#c4452d", "#0e1116", "sport"), 0, sx + rgx * 1.4, sz + rgz * 1.4, sh, 34, 9, "Mirage S");
  addVeh(buildBike("#1f6f4a"), 1, sx + rgx * 3.8 + fwx * 3, sz + rgz * 3.8 + fwz * 3, sh, 8.5, 5, "Rower");
  const others: [string, string, string, string, number, number][] = [
    ["#e8ddc2", "#1f6f4a", "van", "Bata Van", 26, 6],
    ["#e2a04a", "#12151b", "hatch", "Orlik GT", 32, 8.5],
    ["#3d5a45", "#0e1116", "suv", "Puszcza 4x4", 28, 7],
    ["#f3ead7", "#c4452d", "suv", "Radiowóz OSP", 31, 8],
  ];
  others.forEach((o, i) =>
    addVeh(
      buildCar(o[0], o[1], o[2], i === 3),
      0,
      sx + rgx * 1.4 - fwx * (9 + i * 7),
      sz + rgz * 1.4 - fwz * (9 + i * 7),
      sh,
      o[4],
      o[5],
      o[3]
    )
  );
  const PC = ["#7d9bb5", "#22262c", "#b9bec4", "#8a1f1f", "#2f4f7a", "#d9d4c6"],
    PT2 = ["hatch", "suv", "hatch", "sport", "van"];
  world.areas
    .filter((a: any) => a.k === "parking")
    .map((a: any) => ({ c: polyCentroid(a.p) }))
    .sort((a: any, b: any) => Math.hypot(a.c[0], a.c[1]) - Math.hypot(b.c[0], b.c[1]))
    .slice(0, 12)
    .forEach((a: any, i: number) => {
      if (Math.hypot(a.c[0] - sx, a.c[1] - sz) < 12) return;
      addVeh(
        buildCar(PC[i % PC.length], "#0e1116", PT2[i % PT2.length]),
        0,
        a.c[0],
        a.c[1],
        hash01(i, 5) * 6.28,
        30,
        7.5,
        "Auto z parkingu"
      );
    });

  // Extra vehicles stationed in Gorzów, Bobrek, Stawy & Wzgórze Skała
  addVeh(buildCar("#2563eb", "#0f172a", "suv"), 0, -1472, 2255, 0.2, 31, 8, "Gorzów SUV");
  addVeh(buildBike("#eab308"), 1, -1478, 2262, 0.5, 9, 5.5, "Rower Gorzów");
  addVeh(buildCar("#991b1b", "#0f172a", "sport"), 0, -285, 3775, 1.1, 34, 9, "Bobrek GT");
  addVeh(buildCar("#15803d", "#0f172a", "van"), 0, 245, 3415, -0.5, 27, 6.5, "Bus Park Bobrek");
  addVeh(buildBike("#dc2626"), 1, -1038, 52, -0.8, 9, 5.5, "Rower Górski Skała");

  S.py = ground(S.px, S.pz, 1e9);
  const tw = props.tower;

  function teleportTo(tx: number, tz: number, yaw?: number, label?: string) {
    S.tower = false;
    // Snap near a road if within 22m so vehicle/player lands cleanly on pavement
    const si = net.drive.nearest(tx, tz, 22);
    if (si >= 0) {
      const s = net.drive.s,
        o = si * 5;
      tx = s[o] + (s[o + 2] - s[o]) * net.drive.nt;
      tz = s[o + 1] + (s[o + 3] - s[o + 1]) * net.drive.nt;
      if (yaw === undefined) yaw = Math.atan2(s[o + 2] - s[o], s[o + 3] - s[o + 1]);
    }
    resolve(tx, tz, S.veh ? 1.2 : 0.4);
    const fx = out[0],
      fz = out[1],
      fy = ground(fx, fz, 1e9);
    S.px = fx;
    S.pz = fz;
    S.py = fy;
    S.vy = 0;
    S.speed = 0;
    if (yaw !== undefined) {
      S.yaw = yaw;
      S.camYaw = yaw;
    }
    if (S.veh) {
      S.veh.x = fx;
      S.veh.z = fz;
      S.veh.y = fy;
      S.veh.v = 0;
      if (yaw !== undefined) S.veh.h = yaw;
      placeVeh(S.veh, 1);
    } else {
      player.g.position.set(fx, fy, fz);
      player.g.rotation.y = S.yaw;
    }
    updateCamera(0.016, true);
    ui.toast("Teleportacja GPS", label || `${placeAt(fx, fz)} ${streetAt(fx, fz)}`);
  }

  const ui = makeUI(uiRoot, input, mobile, world, teleportTo);
  const cityAction = createCityAction(scene, camera, renderer.domElement, uiRoot, mobile, net, ground, inBld, S, player);

  function toggleVehicle() {
    if (S.tower && tw) {
      S.tower = false;
      S.px = tw.x + 4.5;
      S.pz = tw.z + 4.5;
      S.py = ground(S.px, S.pz, 1e9);
      ui.toast("Na dole", "Wzgórze Skała");
      return;
    }
    if (S.veh) {
      const v = S.veh,
        lx = Math.cos(v.h),
        lz = -Math.sin(v.h);
      resolve(v.x + lx * 1.9, v.z + lz * 1.9, 0.35);
      S.px = out[0];
      S.pz = out[1];
      S.py = ground(S.px, S.pz, v.y + 1);
      v.v = 0;
      S.veh = null;
      S.speed = 0;
      S.yaw = v.h;
      ui.toast("Pieszo", "E — wsiądź do pojazdu");
      return;
    }
    let best: any = null,
      bd = 4.2;
    for (const v of vehs) {
      const d = Math.hypot(v.x - S.px, v.z - S.pz);
      if (d < bd) {
        bd = d;
        best = v;
      }
    }
    if (best) {
      S.veh = best;
      ui.toast(
        best.name,
        best.kind === 1
          ? "Rower: góra — pedałuj, lewo / prawo — skręt"
          : "Góra — gaz, dół — hamulec, lewo / prawo — skręt"
      );
      return;
    }
    if (tw && Math.hypot(tw.x - S.px, tw.z - S.pz) < 7) {
      S.tower = true;
      S.px = tw.x;
      S.pz = tw.z;
      S.py = tw.deck;
      S.vy = 0;
      ui.toast("Wieża widokowa im. rtm. Pileckiego", "32 m nad wzgórzem Skała. E — zejdź");
    }
  }

  const sRight = new Vector3(),
    sUp = new Vector3();
  function applyTime(i: number, quiet: boolean) {
    S.time = i;
    const T = TIMES[i % TIMES.length];
    const dir = (el: number, az: number, v: Vector3) => {
      const e = (el * Math.PI) / 180,
        a = (az * Math.PI) / 180;
      return v.set(Math.cos(e) * Math.sin(a), Math.sin(e), -Math.cos(e) * Math.cos(a));
    };
    dir(T.el, T.az, skyDir);
    if (T.night === 1) dir(38, 200, sunDir);
    else sunDir.copy(skyDir);
    U.sunDir.value.copy(sunDir);
    sky.material.uniforms.sunPosition.value.copy(skyDir);
    envSky.material.uniforms.sunPosition.value.copy(skyDir);
    const old = envRT;
    envRT = pm.fromScene(envScene, 0, 0.1, 2000);
    scene.environment = envRT.texture;
    scene.environmentIntensity = T.env;
    if (old) old.dispose();
    sun.color.set(T.lc);
    sun.intensity = T.li;
    hemi.intensity = T.he;
    renderer.toneMappingExposure = T.ex;
    (scene.fog as FogExp2).color.set(T.fog);
    U.night.value = T.night;
    props.setNight(T.lamp);
    fx.setLight(T.cl);
    sRight.crossVectors(upV, sunDir).normalize();
    sUp.crossVectors(sunDir, sRight).normalize();
    if (!quiet) ui.toast(T.n, T.s);
  }
  applyTime(0, true);

  let composer: EffectComposer | null = null,
    ssao: SSAOPass | null = null;
  const bufSize = new Vector2();
  if (Q.post) {
    renderer.getDrawingBufferSize(bufSize);
    composer = new EffectComposer(
      renderer,
      new WebGLRenderTarget(bufSize.x, bufSize.y, { type: HalfFloatType, samples: 4 })
    );
    composer.addPass(new RenderPass(scene, camera));
    ssao = new SSAOPass(scene, camera, bufSize.x, bufSize.y);
    ssao.kernelRadius = 0.9;
    ssao.minDistance = 0.00002;
    ssao.maxDistance = 0.0004;
    ssao.enabled = false;
    composer.addPass(ssao);
    composer.addPass(new UnrealBloomPass(new Vector2(bufSize.x, bufSize.y), 0.28, 0.52, 2.2));
    composer.addPass(new OutputPass());
  }
  const draw2 = () => {
    if (composer && S.post) composer.render();
    else renderer.render(scene, camera);
  };

  function update(dt: number) {
    let mx = input.mx,
      my = input.my;
    if (keys.KeyW || keys.ArrowUp) my += 1;
    if (keys.KeyS || keys.ArrowDown) my -= 1;
    if (keys.KeyD || keys.ArrowRight) mx += 1;
    if (keys.KeyA || keys.ArrowLeft) mx -= 1;
    mx = Math.max(-1, Math.min(1, mx));
    my = Math.max(-1, Math.min(1, my));
    const sprint = input.sprint || keys.ShiftLeft || keys.ShiftRight || (!S.veh && input.gas > 0);
    S.camYaw -= input.lookX * 0.005;
    S.camPitch = Math.max(0.05, Math.min(1.2, S.camPitch + input.lookY * 0.004));
    if (input.lookX || input.lookY) S.dragT = 2.5;
    input.lookX = 0;
    input.lookY = 0;
    S.dragT -= dt;
    if (input.act) {
      input.act = false;
      toggleVehicle();
    }
    if (input.camNext) {
      input.camNext = false;
      S.cam = (S.cam + 1) % 3;
    }
    if (input.timeNext) {
      input.timeNext = false;
      applyTime((S.time + 1) % TIMES.length, false);
    }
    const v = S.veh;
    if (v) {
      const bike = v.kind === 1;
      const gas = Math.max(input.gas, my > 0 ? my : 0),
        brake = Math.max(input.brake, my < 0 ? -my : 0, keys.Space ? 1 : 0);
      const sf = terrain.surf(v.x, v.z),
        off =
          sf === SF.ROAD ||
          sf === SF.WALK ||
          sf === SF.PARKING ||
          sf === SF.PAVED ||
          sf === SF.DIRT ||
          sf === SF.RAIL
            ? 1
            : sf === SF.WATER
            ? 0.25
            : 0.62;
      const max = v.max * off * (bike && sprint ? 1.25 : 1);
      if (gas > 0) v.v += v.acc * gas * dt * (v.v < 0 ? 2 : 1);
      if (brake > 0) {
        if (v.v > 0.5) v.v -= 26 * brake * dt;
        else v.v -= (bike ? 3 : 9) * brake * dt;
      }
      if (gas === 0 && brake === 0) v.v -= Math.sign(v.v) * Math.min(Math.abs(v.v), (bike ? 2.2 : 3.5) * dt);
      v.v -= v.v * 0.25 * dt;
      if (v.v > max) v.v = Math.max(max, v.v - 30 * dt);
      if (v.v < -6) v.v = -6;
      const sp = Math.abs(v.v);
      v.steer += (mx - v.steer) * Math.min(1, dt * 6);
      const rate = Math.min(bike ? 2.4 : 1.9, sp / (bike ? 1.4 : 3.2)) / (1 + sp * 0.035);
      v.h -= v.steer * rate * dt * (v.v >= 0 ? 1 : -1);
      let nx = v.x + Math.sin(v.h) * v.v * dt,
        nz = v.z + Math.cos(v.h) * v.v * dt,
        hit = false;
      if (bike) {
        hit = resolve(nx, nz, 0.5);
        nx = out[0];
        nz = out[1];
      } else {
        const ax = Math.sin(v.h) * 1.25,
          az = Math.cos(v.h) * 1.25;
        if (resolve(nx + ax, nz + az, 1.15)) hit = true;
        nx = out[0] - ax;
        nz = out[1] - az;
        if (resolve(nx - ax, nz - az, 1.15)) hit = true;
        nx = out[0] + ax;
        nz = out[1] + az;
      }
      if (hit) {
        if (sp > 9) ui.toast("Kraksa!", "Uważaj na budynki i drzewa.");
        v.v *= 0.4;
      }
      v.x = nx;
      v.z = nz;
      placeVeh(v, dt);
      S.px = v.x;
      S.pz = v.z;
      S.py = v.y;
      S.yaw = v.h;
      S.speed = v.v;
      if (bike) {
        player.g.visible = true;
        player.g.position.set(v.x, v.y + 0.12, v.z);
        player.g.rotation.y = v.h;
        S.walk += dt * (2 + sp * 1.2);
        player.ride(S.walk);
      } else player.g.visible = false;
    } else {
      const cfx = Math.sin(S.camYaw),
        cfz = Math.cos(S.camYaw),
        crx = -cfz,
        crz = cfx;
      let wx = cfx * my + crx * mx,
        wz = cfz * my + crz * mx;
      const mag = Math.hypot(wx, wz);
      const target = mag > 0.1 ? (sprint ? 7.5 : 3.6) * Math.min(1, mag) : 0;
      S.speed += (target - S.speed) * Math.min(1, dt * 9);
      if (mag > 0.1) {
        wx /= mag;
        wz /= mag;
        let d = Math.atan2(wx, wz) - S.yaw;
        while (d > Math.PI) d -= 2 * Math.PI;
        while (d < -Math.PI) d += 2 * Math.PI;
        S.yaw += d * Math.min(1, dt * 12);
        if (S.tower && tw) {
          S.px = Math.max(tw.x - tw.half, Math.min(tw.x + tw.half, S.px + wx * S.speed * dt));
          S.pz = Math.max(tw.z - tw.half, Math.min(tw.z + tw.half, S.pz + wz * S.speed * dt));
        } else {
          resolve(S.px + wx * S.speed * dt, S.pz + wz * S.speed * dt, 0.35);
          S.px = out[0];
          S.pz = out[1];
        }
        S.walk += dt * S.speed * 2.4;
      }
      const g = S.tower && tw ? tw.deck : ground(S.px, S.pz, S.py + 0.6);
      if ((keys.Space || input.jump) && S.py <= g + 0.02) S.vy = 4.6;
      input.jump = false;
      S.vy -= 13 * dt;
      S.py += S.vy * dt;
      if (S.py < g || (S.vy <= 0 && S.py - g < 0.3)) {
        S.py = g;
        S.vy = 0;
      }
      player.g.visible = true;
      player.g.position.set(S.px, S.py, S.pz);
      player.g.rotation.y = S.yaw;
      player.pose(
        S.walk,
        Math.min(1, Math.abs(S.speed) / 3.2),
        Math.max(0, Math.min(1, (Math.abs(S.speed) - 3.6) / 3.5)),
        U.time.value
      );
    }
  }

  const camPos = new Vector3(),
    camLook = new Vector3(),
    tmpV = new Vector3();
  function updateCamera(dt: number, snap: boolean) {
    const v = S.veh,
      sp = Math.abs(S.speed);
    if (v && S.dragT <= 0) {
      let d = v.h - S.camYaw;
      while (d > Math.PI) d -= 2 * Math.PI;
      while (d < -Math.PI) d += 2 * Math.PI;
      S.camYaw += d * Math.min(1, dt * (2 + sp * 0.15));
    }
    const dist =
      S.cam === 0 ? (v ? (v.kind === 1 ? 5.2 : 8.2) + sp * 0.1 : 5.2) : S.cam === 1 ? 17 + sp * 0.15 : 60;
    const pitch = S.cam === 2 ? 1.15 : S.cam === 1 ? Math.max(S.camPitch, 0.45) : S.camPitch;
    const cx2 = Math.sin(S.camYaw),
      cz2 = Math.cos(S.camYaw),
      cp = Math.cos(pitch),
      sn = Math.sin(pitch),
      ty = S.py + (v ? 1.3 : 1.55);
    tmpV.set(S.px - cx2 * cp * dist, ty + sn * dist, S.pz - cz2 * cp * dist);
    if (S.cam !== 2 && !S.tower) {
      const f = camFrac(S.px, ty, S.pz, tmpV.x, tmpV.y, tmpV.z);
      if (f < 1) tmpV.set(S.px + (tmpV.x - S.px) * f, ty + (tmpV.y - ty) * f, S.pz + (tmpV.z - S.pz) * f);
    }
    const gm = terrain.h(tmpV.x, tmpV.z) + 0.7;
    if (!S.tower && tmpV.y < gm) tmpV.y = gm;
    if (snap) camPos.copy(tmpV);
    else camPos.lerp(tmpV, 1 - Math.exp(-9 * dt));
    if (S.cam !== 2 && !S.tower && inBld(camPos.x, camPos.z, camPos.y)) camPos.copy(tmpV);
    tmpV.set(S.px + cx2 * 2.5, ty, S.pz + cz2 * 2.5);
    if (snap) camLook.copy(tmpV);
    else camLook.lerp(tmpV, 1 - Math.exp(-12 * dt));
    camera.position.copy(camPos);
    camera.lookAt(camLook);
  }

  function updateSun(cx: number, cy: number, cz: number) {
    if (Q.shadow) {
      const texel = (2 * SR) / Q.shadow;
      tmpV.set(cx, cy, cz);
      const r = tmpV.dot(sRight),
        u = tmpV.dot(sUp),
        dr = Math.round(r / texel) * texel - r,
        du = Math.round(u / texel) * texel - u;
      cx += sRight.x * dr + sUp.x * du;
      cy += sRight.y * dr + sUp.y * du;
      cz += sRight.z * dr + sUp.z * du;
    }
    sun.target.position.set(cx, cy, cz);
    sun.position.set(cx + sunDir.x * 400, cy + sunDir.y * 400, cz + sunDir.z * 400);
    sun.target.updateMatrixWorld();
  }

  window.addEventListener("keydown", (e) => {
    keys[e.code] = true;
    if (e.code === "KeyE" || e.code === "KeyF") input.act = true;
    if (e.code === "KeyC") input.camNext = true;
    if (e.code === "KeyT") input.timeNext = true;
    if (e.code === "KeyP" && composer) {
      S.post = !S.post;
      ui.toast("Efekty", S.post ? "Poświata UE5 włączona" : "Wyłączone");
    }
    if (e.code === "KeyO" && ssao) {
      ssao.enabled = !ssao.enabled;
      S.post = true;
      ui.toast("SSAO", ssao.enabled ? "Włączone" : "Wyłączone");
    }
    if (e.code === "Space" || e.code.indexOf("Arrow") === 0) e.preventDefault();
  });
  window.addEventListener("keyup", (e) => {
    keys[e.code] = false;
  });
  window.addEventListener("blur", () => {
    for (const k in keys) keys[k] = false;
  });
  {
    const el = renderer.domElement;
    let pid = -1,
      lx = 0,
      ly = 0;
    el.addEventListener("pointerdown", (e) => {
      pid = e.pointerId;
      lx = e.clientX;
      ly = e.clientY;
      try {
        el.setPointerCapture(pid);
      } catch {}
    });
    el.addEventListener("pointermove", (e) => {
      if (e.pointerId !== pid) return;
      input.lookX += e.clientX - lx;
      input.lookY += e.clientY - ly;
      lx = e.clientX;
      ly = e.clientY;
    });
    const end = (e: PointerEvent) => {
      if (e.pointerId === pid) pid = -1;
    };
    el.addEventListener("pointerup", end);
    el.addEventListener("pointercancel", end);
    el.addEventListener("contextmenu", (e) => e.preventDefault());
  }
  window.addEventListener("resize", () => {
    renderer.setSize(W(), H());
    camera.aspect = W() / H();
    camera.updateProjectionMatrix();
    if (composer) {
      renderer.getDrawingBufferSize(bufSize);
      composer.setSize(bufSize.x, bufSize.y);
    }
  });

  const g0 = terrain.h(0, 0),
    gs = ground(sx, sz, 1e9);
  let mx0 = 0,
    mz0 = 0;
  for (let r = 40; r < 1500 && !mx0; r += 40)
    for (let a = 0; a < 16; a++) {
      const x = Math.cos(a * 0.3927) * r,
        z = Math.sin(a * 0.3927) * r,
        s = terrain.surf(x, z);
      if (s === SF.MEADOW || s === SF.FIELD) {
        mx0 = x;
        mz0 = z;
        break;
      }
    }
  const views = [
    [140, g0 + 170, 240, 0, g0, 0],
    [sx - fwx * 9 + rgx * 2.5, gs + 3.2, sz - fwz * 9 + rgz * 2.5, sx + fwx * 20, gs + 1.5, sz + fwz * 20],
    [mx0, terrain.h(mx0, mz0) + 1.3, mz0, mx0 + 12, terrain.h(mx0 + 12, mz0 + 6) + 0.3, mz0 + 6],
    tw ? [tw.x + 34, tw.deck - 14, tw.z + 26, tw.x, tw.deck - 12, tw.z] : [0, g0 + 30, 60, 0, g0, 0],
  ];
  const mixAt = (x: number, z: number) => {
    const s = terrain.surf(x, z);
    return s === SF.FOREST || s === SF.SCRUB
      ? [1, 0.2, 0]
      : s === SF.MEADOW || s === SF.FIELD || s === SF.GRASS || s === SF.PARK || s === SF.WETLAND || s === SF.FARM
      ? [0.15, 1, 0.1]
      : [0.1, 0.15, 1];
  };

  let testCam: number[] | null = null,
    last = performance.now(),
    hudT = 0,
    lightT = 0,
    frames = 0;
  function frame() {
    requestAnimationFrame(frame);
    const now2 = performance.now(),
      dt = Math.min(0.05, (now2 - last) / 1000);
    last = now2;
    frames++;
    U.time.value += dt;
    if (testCam) {
      camera.position.set(testCam[0], testCam[1], testCam[2]);
      camera.lookAt(testCam[3], testCam[4], testCam[5]);
      updateSun(testCam[3], testCam[4], testCam[5]);
    } else if (S.started) {
      update(dt);
      updateCamera(dt, false);
      if (!S.veh) player.aim();
      cityAction.update(dt);
      updateSun(S.px, S.py, S.pz);
    } else {
      const a = now2 * 0.00006;
      camera.position.set(Math.sin(a) * 320, g0 + 150, Math.cos(a) * 320);
      camera.lookAt(0, g0 + 5, 0);
      updateSun(0, g0, 0);
    }
    sky.position.copy(camera.position);
    veg.update(camera.position.x, camera.position.z);
    fx.update(camera.position, mixAt(camera.position.x, camera.position.z), renderer.domElement.height);
    lightT -= dt;
    if (lightT <= 0) {
      lightT = 0.25;
      props.updateLights(testCam ? testCam[3] : S.px, testCam ? testCam[5] : S.pz);
    }
    draw2();
    hudT -= dt;
    if (hudT <= 0 && S.started) {
      hudT = 0.2;
      let hint = "";
      if (S.tower) hint = "E — zejdź z wieży";
      else if (!S.veh) {
        for (const v of vehs)
          if (Math.hypot(v.x - S.px, v.z - S.pz) < 4.2) {
            hint = "E — wsiądź: " + v.name;
            break;
          }
        if (!hint && tw && Math.hypot(tw.x - S.px, tw.z - S.pz) < 7) hint = "E — wejdź na wieżę widokową";
      }
      ui.set(
        placeAt(S.px, S.pz),
        streetAt(S.px, S.pz),
        Math.round(Math.abs(S.speed) * 3.6),
        S.veh ? S.veh.name : "pieszo",
        hint,
        S.px,
        S.py,
        S.pz,
        S.yaw,
        vehs
      );
    }
  }

  diag.counts = {
    buildings: bl.list.length,
    signs: bl.signs.length,
    trees: veg.count,
    roads: net.roads.length,
    props: props.counts,
    lamps: props.lamps.length / 3,
    tower: !!tw,
    vehs: vehs.length,
  };
  lap("game");
  await step(0.95, "Kompilacja shaderów UE5 Lumen…");
  camera.position.set(140, g0 + 170, 240);
  camera.lookAt(0, g0, 0);
  updateSun(0, g0, 0);
  sky.position.copy(camera.position);
  veg.update(camera.position.x, camera.position.z);
  fx.update(camera.position, [0, 1, 0], renderer.domElement.height);
  draw2();
  lap("firstFrame");
  diag.info = {
    calls: renderer.info.render.calls,
    tris: renderer.info.render.triangles,
    geos: renderer.info.memory.geometries,
    tex: renderer.info.memory.textures,
    progs: renderer.info.programs ? renderer.info.programs.length : 0,
  };
  requestAnimationFrame(frame);

  const wait = <T>(fn: () => T): Promise<T> =>
    new Promise((res) => requestAnimationFrame(() => requestAnimationFrame(() => res(fn()))));
  return {
    diag,
    views,
    teleportTo,
    start() {
      S.started = true;
      updateCamera(0.016, true);
    },
    testView(k: number) {
      testCam = k >= 0 ? views[k] : null;
      return wait(() => renderer.info.render.calls + "c/" + renderer.info.render.triangles + "t f" + frames);
    },
    testTime(i: number) {
      applyTime(i, true);
      return wait(() => TIMES[i % TIMES.length].n);
    },
    testPost(on: boolean) {
      S.post = on && !!composer;
      return wait(() => S.post);
    },
    testSim() {
      const res: any = {},
        dt = 1 / 30;
      testCam = null;
      S.started = true;
      S.veh = null;
      S.tower = false;
      S.camYaw = 0.7;
      S.dragT = 99;
      S.px = sx - rgx * 3;
      S.pz = sz - rgz * 3;
      S.py = ground(S.px, S.pz, 1e9);
      S.speed = 0;
      const run = (k: string[], n: number) => {
        for (const c of k) keys[c] = true;
        for (let i = 0; i < n; i++) update(dt);
        for (const c of k) keys[c] = false;
      };
      const cf = [Math.sin(0.7), Math.cos(0.7)],
        cr = [-cf[1], cf[0]];
      let x0 = S.px,
        z0 = S.pz;
      run(["KeyW"], 45);
      res.footFwd = +((S.px - x0) * cf[0] + (S.pz - z0) * cf[1]).toFixed(2);
      x0 = S.px;
      z0 = S.pz;
      run(["KeyD"], 45);
      res.footRight = +((S.px - x0) * cr[0] + (S.pz - z0) * cr[1]).toFixed(2);
      const v = vehs[0];
      S.veh = v;
      v.v = 0;
      const h0 = v.h;
      x0 = v.x;
      z0 = v.z;
      run(["KeyW"], 60);
      res.carFwd = +((v.x - x0) * Math.sin(h0) + (v.z - z0) * Math.cos(h0)).toFixed(2);
      res.carV = +v.v.toFixed(2);
      const h1 = v.h;
      run(["KeyW", "KeyD"], 30);
      res.carTurnRight = +(h1 - v.h).toFixed(3);
      S.veh = null;
      v.v = 0;
      if (tw) {
        S.px = tw.x + 3;
        S.pz = tw.z + 3;
        S.py = ground(S.px, S.pz, 1e9);
        toggleVehicle();
        res.towerUp = +(S.py - terrain.h(tw.x, tw.z)).toFixed(1);
        run(["KeyW"], 90);
        res.towerClamp = Math.abs(S.px - tw.x) <= tw.half + 0.01 && Math.abs(S.pz - tw.z) <= tw.half + 0.01;
        toggleVehicle();
        res.towerDown = +(S.py - terrain.h(S.px, S.pz)).toFixed(2);
      }
      res.camClip = +camFrac(sx, gs + 1.5, sz, sx + 400, gs + 1.5, sz).toFixed(2);
      res.finite = isFinite(v.x + v.y + v.z + v.h + v.v + S.px + S.py + S.pz);
      S.px = sx - rgx * 2.2;
      S.pz = sz - rgz * 2.2;
      S.py = ground(S.px, S.pz, 1e9);
      S.dragT = 0;
      return res;
    },
  };
}
