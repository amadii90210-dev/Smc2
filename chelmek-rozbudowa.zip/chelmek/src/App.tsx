import { useEffect, useRef, useState } from "react";
import { startGame } from "./engine";
import { loadWorldData } from "./worldInline";

declare global {
  interface Window {
    __game?: any;
    __INITIAL_HTML__?: string;
  }
}

export function App() {
  const bootedRef = useRef(false);
  const [showDeploy, setShowDeploy] = useState(false);
  const [token, setToken] = useState("");
  const [projName, setProjName] = useState("chelmek-explore-3d");
  const [deployStatus, setDeployStatus] = useState<string>("");
  const [deployedUrl, setDeployedUrl] = useState<string>("");
  const [deploying, setDeploying] = useState(false);

  useEffect(() => {
    if (bootedRef.current) return;
    bootedRef.current = true;

    const $ = (id: string) => document.getElementById(id)!;
    const G: any = (window.__game = { ready: false, error: null, diag: {} });

    async function boot() {
      const q = new URLSearchParams(location.search),
        test = q.has("test");
      const progress = (f: number, msg: string) => {
        const prog = document.getElementById("prog");
        const m = document.getElementById("msg");
        if (prog) prog.style.width = Math.round(f * 100) + "%";
        if (m) m.textContent = msg;
      };
      try {
        progress(0.05, "Wczytywanie mapy całej Gminy Chełmek (32-660)…");
        const world = await loadWorldData();
        const api = await startGame($("game"), $("ui"), world, { test, quality: q.get("q") || "" }, progress);
        Object.assign(G, api);
        G.ready = true;
        progress(1, "Gotowe — Cała Gmina Chełmek 3D (Chełmek · Gorzów · Bobrek)");
        const begin = () => {
          $("loading").style.display = "none";
          api.start();
        };
        if (test) begin();
        else {
          const b = $("start");
          b.style.display = "inline-block";
          b.onclick = begin;
          const actions = document.getElementById("start-actions");
          if (actions) actions.style.display = "flex";
        }
      } catch (e: any) {
        G.error = String((e && e.stack) || e);
        const m = document.getElementById("msg");
        if (m) m.textContent = "Błąd: " + String((e && e.message) || e);
        console.error(e);
      }
    }
    boot();
  }, []);

  const handleDownloadHtml = () => {
    const html = window.__INITIAL_HTML__ || "<!doctype html>\n" + document.documentElement.outerHTML;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "index.html";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  const handleVercelDeploy = async () => {
    const cleanToken = token.trim();
    if (!cleanToken) {
      setDeployStatus("Wklej Personal Access Token z https://vercel.com/account/tokens");
      return;
    }
    if (cleanToken.startsWith("vck_")) {
      setDeployStatus(
        "Uwaga: Klucz zaczynający się od 'vck_' to klucz AI Gateway (limited: true), który nie ma uprawnień do tworzenia wdrożeń. Wygeneruj pełny Personal Access Token w https://vercel.com/account/tokens i wklej go powyżej."
      );
      return;
    }
    setDeploying(true);
    setDeployStatus("Wysyłanie zbudowanej gry 3D do Vercel API (/v13/deployments)…");
    setDeployedUrl("");
    try {
      const html = window.__INITIAL_HTML__ || "<!doctype html>\n" + document.documentElement.outerHTML;
      const bytes = new TextEncoder().encode(html);
      let bin = "";
      const chunk = 0x8000;
      for (let i = 0; i < bytes.length; i += chunk) {
        bin += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)));
      }
      const b64 = btoa(bin);

      const res = await fetch("https://api.vercel.com/v13/deployments?skipAutoDetectionConfirmation=1", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${cleanToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: projName.trim() || "chelmek-explore-3d",
          target: "production",
          projectSettings: {
            framework: null,
            buildCommand: null,
            outputDirectory: null,
            installCommand: null,
          },
          files: [{ file: "index.html", data: b64, encoding: "base64" }],
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error?.message || JSON.stringify(data));
      }
      const liveUrl =
        data.alias && data.alias.length > 0 ? `https://${data.alias[0]}` : `https://${data.url}`;
      setDeployedUrl(liveUrl);
      setDeployStatus("Wdrożono pomyślnie na Vercel!");
    } catch (err: any) {
      setDeployStatus("Błąd Vercel API: " + (err?.message || String(err)));
    } finally {
      setDeploying(false);
    }
  };

  return (
    <>
      <style>{`
        html,body{margin:0;height:100%;background:#0e1116;color:#f3ead7;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:hidden;overscroll-behavior:none;touch-action:none;user-select:none;-webkit-user-select:none}
        #game{position:fixed;inset:0}
        #game canvas{display:block;width:100%;height:100%}
        #loading{position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;background:radial-gradient(circle at 50% 35%,rgba(226,160,74,.16),transparent 60%),linear-gradient(160deg,#141d28,#0b0e13);z-index:50;text-align:center;padding:24px}
        #loading h1{margin:0;font-size:clamp(28px,6vw,54px);letter-spacing:.05em;color:#f7efe0;text-shadow:0 4px 24px rgba(226,160,74,.35)}
        #loading .sub-badge{font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#e2a04a;background:rgba(226,160,74,.14);border:1px solid rgba(226,160,74,.38);padding:5px 14px;border-radius:999px}
        #loading p{margin:0;opacity:.85;max-width:580px;line-height:1.45}
        #bar{width:min(440px,82vw);height:9px;border-radius:8px;background:#232a34;overflow:hidden;border:1px solid rgba(255,255,255,.1)}
        #bar i{display:block;height:100%;width:4%;background:linear-gradient(90deg,#d97706,#f59e0b);transition:width .25s}
        #start{display:none;padding:14px 42px;border-radius:12px;border:0;background:linear-gradient(135deg,#e2a04a,#d97706);color:#12151b;font-weight:800;font-size:18px;cursor:pointer;box-shadow:0 10px 28px rgba(226,160,74,.4)}
        #start:hover{transform:translateY(-1px);filter:brightness(1.06)}
        #start-actions{display:none;gap:10px;flex-wrap:wrap;justify-content:center;margin-top:4px}
        .sec-btn{padding:9px 16px;border-radius:10px;border:1px solid rgba(226,160,74,.45);background:rgba(226,160,74,.14);color:#f7efe0;font-weight:700;font-size:13px;cursor:pointer}
        .sec-btn:hover{background:rgba(226,160,74,.28)}
        #deploy-modal{position:fixed;inset:0;background:rgba(8,11,16,.86);backdrop-filter:blur(10px);z-index:80;display:flex;align-items:center;justify-content:center;padding:16px;user-select:text;-webkit-user-select:text}
        #deploy-card{width:min(540px,94vw);background:#151d28;border:1px solid rgba(226,160,74,.45);border-radius:16px;padding:20px;text-align:left;box-shadow:0 20px 60px rgba(0,0,0,.65)}
        #deploy-card h3{margin:0 0 8px;color:#e2a04a;font-size:18px}
        #deploy-card p{font-size:13px;color:#cbd5e1;line-height:1.45;margin:6px 0}
        #deploy-card input{width:100%;box-sizing:border-box;padding:10px 12px;border-radius:8px;border:1px solid rgba(255,255,255,.18);background:#0d1219;color:#f7efe0;font-size:13px;margin-top:6px}
      `}</style>
      <div id="game"></div>
      <div id="ui"></div>
      <div id="loading">
        <span className="sub-badge">GMINA CHEŁMEK 32-660 · EDYCJA PBR 3D (UE5 LUMEN)</span>
        <h1>CHEŁMEK EXPLORE</h1>
        <p id="msg">Wczytywanie miasta…</p>
        <div id="bar">
          <i id="prog"></i>
        </div>
        <button id="start">GRAJ</button>
        <div id="start-actions">
          <button className="sec-btn" onClick={() => setShowDeploy(true)}>
            Wdróż na własny Vercel / Pobierz HTML
          </button>
          <button className="sec-btn" onClick={handleDownloadHtml}>
            Pobierz samodzielny plik gry (index.html)
          </button>
        </div>
        <p style={{ fontSize: 12, opacity: 0.6 }}>
          Pełna mapa Gminy Chełmek (Chełmek · Kolonia Bata · Wzgórze Skała · Gorzów · Bobrek). Dane © OpenStreetMap
          (ODbL) · DEM: Mapzen Terrain Tiles.
        </p>
      </div>

      {showDeploy && (
        <div id="deploy-modal">
          <div id="deploy-card">
            <h3>Wdróż grę na Vercel lub pobierz plik produkcyjny</h3>
            <p>
              Gra została skompilowana do pojedynczego, samodzielnego pliku <b>index.html</b> zawierającego pełny silnik
              3D PBR oraz mapę całej Gminy Chełmek (Chełmek, Gorzów, Bobrek).
            </p>
            <p style={{ background: "rgba(226,160,74,0.12)", padding: "8px 10px", borderRadius: 8, fontSize: 12 }}>
              <b>Informacja o kluczu API Vercel:</b> Podany klucz <code>vck_...</code> to klucz <i>Vercel AI Gateway</i>{" "}
              (posiada flagę <code>limited: true</code> i zwraca błąd 403 przy próbie utworzenia deploymentu). Aby
              wdrożyć grę bezpośrednio na swoje konto Vercel (<code>aitryb981-1019</code>), utwórz{" "}
              <b>Personal Access Token</b> w zakładce <b>vercel.com/account/tokens</b> i wklej go poniżej:
            </p>
            <label style={{ display: "block", fontSize: 12, fontWeight: 700, marginTop: 10 }}>
              Nazwa projektu na Vercel:
            </label>
            <input value={projName} onChange={(e) => setProjName(e.target.value)} placeholder="chelmek-explore-3d" />
            <label style={{ display: "block", fontSize: 12, fontWeight: 700, marginTop: 10 }}>
              Vercel Personal Access Token (z vercel.com/account/tokens):
            </label>
            <input
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="Wklej token z vercel.com/account/tokens…"
            />
            {deployStatus && (
              <p style={{ color: deployedUrl ? "#4ade80" : "#fbbf24", fontWeight: 600, marginTop: 10 }}>
                {deployStatus}
              </p>
            )}
            {deployedUrl && (
              <p style={{ marginTop: 6 }}>
                Link do gry:{" "}
                <a
                  href={deployedUrl}
                  target="_blank"
                  rel="noreferrer"
                  style={{ color: "#38bdf8", fontWeight: 800, textDecoration: "underline" }}
                >
                  {deployedUrl}
                </a>
              </p>
            )}
            <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap", justifyContent: "flex-end" }}>
              <button className="sec-btn" onClick={handleDownloadHtml}>
                Pobierz index.html (1.5 MB)
              </button>
              <button
                className="sec-btn"
                style={{ background: "#e2a04a", color: "#12151b" }}
                onClick={handleVercelDeploy}
                disabled={deploying}
              >
                {deploying ? "Wdrażanie…" : "Wdróż na Vercel teraz"}
              </button>
              <button className="sec-btn" onClick={() => setShowDeploy(false)}>
                Zamknij
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
export default App;
