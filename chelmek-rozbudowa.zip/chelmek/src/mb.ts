import {
  BufferGeometry,
   DataArrayTexture,
  Float32BufferAttribute,
  Group,
  Mesh,
  MeshStandardMaterial,
} from "three";
import { U } from "./env";

export class MB {
  pos: number[] = [];
  nor: number[] = [];
  uv: number[] = [];
  lay: number[] = [];
  tint: number[] = [];
  idx: number[] = [];

  v(
    x: number,
    y: number,
    z: number,
    nx: number,
    ny: number,
    nz: number,
    u: number,
    vv: number,
    layer: number,
    c: number[]
  ) {
    this.pos.push(x, y, z);
    this.nor.push(nx, ny, nz);
    this.uv.push(u, vv);
    this.lay.push(layer);
    this.tint.push(c[0], c[1], c[2]);
  }

  quad4(
    ax: number,
    ay: number,
    az: number,
    bx: number,
    by: number,
    bz: number,
    cx: number,
    cy: number,
    cz: number,
    dx: number,
    dy: number,
    dz: number,
    nx: number,
    ny: number,
    nz: number,
    ua: number,
    va: number,
    ub: number,
    vb: number,
    uc: number,
    vc: number,
    ud: number,
    vd: number,
    layer: number,
    col2: number[]
  ) {
    const i = this.pos.length / 3;
    this.v(ax, ay, az, nx, ny, nz, ua, va, layer, col2);
    this.v(bx, by, bz, nx, ny, nz, ub, vb, layer, col2);
    this.v(cx, cy, cz, nx, ny, nz, uc, vc, layer, col2);
    this.v(dx, dy, dz, nx, ny, nz, ud, vd, layer, col2);
    const e1x = bx - ax,
      e1y = by - ay,
      e1z = bz - az,
      e2x = cx - ax,
      e2y = cy - ay,
      e2z = cz - az;
    const d = (e1y * e2z - e1z * e2y) * nx + (e1z * e2x - e1x * e2z) * ny + (e1x * e2y - e1y * e2x) * nz;
    if (d >= 0) this.idx.push(i, i + 1, i + 2, i, i + 2, i + 3);
    else this.idx.push(i, i + 2, i + 1, i, i + 3, i + 2);
  }

  quad(
    ax: number,
    ay: number,
    az: number,
    bx: number,
    by: number,
    bz: number,
    cx: number,
    cy: number,
    cz: number,
    dx: number,
    dy: number,
    dz: number,
    nx: number,
    ny: number,
    nz: number,
    u0: number,
    v0: number,
    u1: number,
    v1: number,
    layer: number,
    col2: number[]
  ) {
    this.quad4(ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, nx, ny, nz, u0, v0, u1, v0, u1, v1, u0, v1, layer, col2);
  }

  tri(
    ax: number,
    ay: number,
    az: number,
    bx: number,
    by: number,
    bz: number,
    cx: number,
    cy: number,
    cz: number,
    nx: number,
    ny: number,
    nz: number,
    ua: number,
    va: number,
    ub: number,
    vb: number,
    uc: number,
    vc: number,
    layer: number,
    col2: number[]
  ) {
    const i = this.pos.length / 3;
    this.v(ax, ay, az, nx, ny, nz, ua, va, layer, col2);
    this.v(bx, by, bz, nx, ny, nz, ub, vb, layer, col2);
    this.v(cx, cy, cz, nx, ny, nz, uc, vc, layer, col2);
    const e1x = bx - ax,
      e1y = by - ay,
      e1z = bz - az,
      e2x = cx - ax,
      e2y = cy - ay,
      e2z = cz - az;
    const d = (e1y * e2z - e1z * e2y) * nx + (e1z * e2x - e1x * e2z) * ny + (e1x * e2y - e1y * e2x) * nz;
    if (d >= 0) this.idx.push(i, i + 1, i + 2);
    else this.idx.push(i, i + 2, i + 1);
  }

  geometry(): BufferGeometry | null {
    if (!this.idx.length) return null;
    const g = new BufferGeometry();
    g.setAttribute("position", new Float32BufferAttribute(this.pos, 3));
    g.setAttribute("normal", new Float32BufferAttribute(this.nor, 3));
    g.setAttribute("fUv", new Float32BufferAttribute(this.uv, 2));
    g.setAttribute("fLayer", new Float32BufferAttribute(this.lay, 1));
    g.setAttribute("fTint", new Float32BufferAttribute(this.tint, 3));
    g.setIndex(this.idx);
    g.computeBoundingSphere();
    g.computeBoundingBox();
    return g;
  }
}

export class Chunks {
  size: number;
  map = new Map<number, MB>();
  constructor(size: number) {
    this.size = size;
  }
  at(x: number, z: number): MB {
    const k = (Math.floor(x / this.size) + 512) * 1024 + Math.floor(z / this.size) + 512;
    let m = this.map.get(k);
    if (!m) {
      m = new MB();
      this.map.set(k, m);
    }
    return m;
  }
  meshes(mat: MeshStandardMaterial, cast: boolean, receive: boolean): Group {
    const g = new Group();
    for (const m of this.map.values()) {
      const geo = m.geometry();
      if (!geo) continue;
      const mesh = new Mesh(geo, mat);
      mesh.castShadow = cast;
      mesh.receiveShadow = receive;
      g.add(mesh);
    }
    return g;
  }
}

export function worldMaterial(tex: DataArrayTexture, offset: number): MeshStandardMaterial {
  const m = new MeshStandardMaterial({ color: 0xffffff, roughness: 0.85, metalness: 0.04 });
  if (offset) {
    m.polygonOffset = true;
    m.polygonOffsetFactor = -offset;
    m.polygonOffsetUnits = -4 * offset;
  }
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uFacade = { value: tex };
    sh.uniforms.uNight = U.night;
    sh.vertexShader = sh.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
attribute vec2 fUv;
attribute float fLayer;
attribute vec3 fTint;
varying vec2 vFUv;
varying float vFLayer;
varying vec3 vFTint;`
      )
      .replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
vFUv = fUv; vFLayer = fLayer; vFTint = fTint;`
      );
    sh.fragmentShader = sh.fragmentShader
      .replace(
        "#include <common>",
        `#include <common>
uniform highp sampler2DArray uFacade;
uniform float uNight;
varying vec2 vFUv;
varying float vFLayer;
varying vec3 vFTint;`
      )
      .replace(
        "#include <map_fragment>",
        `vec4 fTex = texture( uFacade, vec3( vFUv, floor( vFLayer + 0.5 ) ) );
float fTintW = clamp( fTex.a * 2.0 - 1.0, 0.0, 1.0 );
float fGlassW = clamp( 1.0 - fTex.a * 2.0, 0.0, 1.0 );
float fLit = step( 0.42, fract( sin( dot( floor( vFUv ) + vFTint.xy * 57.0, vec2( 12.9898, 78.233 ) ) ) * 43758.5453 ) );
diffuseColor.rgb *= fTex.rgb * mix( vec3( 1.0 ), vFTint, fTintW );`
      )
      .replace(
        "#include <normal_fragment_maps>",
        `#include <normal_fragment_maps>
float fLum = dot( fTex.rgb, vec3( 0.3, 0.59, 0.11 ) );
vec2 dL = vec2( dFdx( fLum ), dFdy( fLum ) ) * ( 1.0 - fGlassW );
normal = normalize( normal + vec3( -dL.x * 2.8, -dL.y * 1.4, -dL.y * 2.8 ) );`
      )
      .replace(
        "#include <metalnessmap_fragment>",
        `#include <metalnessmap_fragment>
roughnessFactor = mix( roughnessFactor - 0.12 * (1.0 - fLum), 0.05, fGlassW );
metalnessFactor = mix( metalnessFactor, 0.92, fGlassW );`
      )
      .replace(
        "#include <emissivemap_fragment>",
        `#include <emissivemap_fragment>
totalEmissiveRadiance += vec3( 1.0, 0.72, 0.36 ) * ( fGlassW * fLit * uNight * 3.4 );`
      );
  };
  m.customProgramCacheKey = () => "world_ue5_" + offset;
  return m;
}
