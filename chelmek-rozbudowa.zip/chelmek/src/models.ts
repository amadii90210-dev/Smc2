import {
  BoxGeometry,
  BufferGeometry,
  CapsuleGeometry,
  CircleGeometry,
  CylinderGeometry,
  ExtrudeGeometry,
  Group,
  Mesh,
  MeshPhysicalMaterial,
  MeshStandardMaterial,
  Shape,
  SphereGeometry,
  TorusGeometry,
  Vector3,
} from "three";

export function buildPlayer() {
  const g = new Group(),
    body = new Group();
  g.add(body);
  const M = (c: string, r: number, m = 0) => new MeshStandardMaterial({ color: c, roughness: r, metalness: m });
  const jacket = M("#b83d27", 0.55),
    jacketTrim = M("#1e232a", 0.65),
    jeans = M("#23324a", 0.82),
    skin = M("#dfa888", 0.58),
    shoe = M("#1d2025", 0.55),
    sole = M("#eceae4", 0.7),
    hair = M("#2c1f16", 0.85),
    packM = M("#2d3748", 0.72);

  const cap2 = (r: number, len: number, m: MeshStandardMaterial) => {
    const o = new Mesh(new CapsuleGeometry(r, len, 6, 14), m);
    o.castShadow = true;
    return o;
  };
  const hips = new Group();
  hips.position.y = 0.9;
  body.add(hips);
  const pelvis = cap2(0.14, 0.1, jeans);
  pelvis.rotation.z = Math.PI / 2;
  hips.add(pelvis);

  const torso = new Group();
  torso.position.y = 0.04;
  hips.add(torso);
  const chest = cap2(0.165, 0.31, jacket);
  chest.position.y = 0.3;
  chest.scale.set(1.18, 1, 0.82);
  torso.add(chest);

  // Jacket zipper & collar + explorer backpack
  const zip = new Mesh(new BoxGeometry(0.025, 0.42, 0.02), jacketTrim);
  zip.position.set(0, 0.31, 0.135);
  torso.add(zip);
  const collar = new Mesh(new TorusGeometry(0.088, 0.028, 8, 16), jacketTrim);
  collar.rotation.x = Math.PI / 2 + 0.15;
  collar.position.set(0, 0.55, -0.01);
  torso.add(collar);
  const backpack = new Mesh(new BoxGeometry(0.26, 0.34, 0.13), packM);
  backpack.position.set(0, 0.32, -0.16);
  backpack.castShadow = true;
  torso.add(backpack);

  const neck = cap2(0.05, 0.05, skin);
  neck.position.y = 0.6;
  torso.add(neck);
  const head = new Mesh(new SphereGeometry(0.116, 18, 16), skin);
  head.position.y = 0.745;
  head.scale.set(0.95, 1.1, 1);
  head.castShadow = true;
  torso.add(head);
  const hr = new Mesh(new SphereGeometry(0.125, 18, 14, 0, Math.PI * 2, 0, Math.PI * 0.58), hair);
  hr.position.y = 0.02;
  hr.rotation.x = -0.25;
  head.add(hr);

  const limb = (
    parent: Group,
    x: number,
    y: number,
    r1: number,
    l1: number,
    r2: number,
    l2: number,
    m: MeshStandardMaterial,
    end: Group | Mesh
  ) => {
    const up = new Group();
    up.position.set(x, y, 0);
    parent.add(up);
    const a = cap2(r1, l1, m);
    a.position.y = -(l1 / 2 + r1 * 0.5);
    up.add(a);
    const lo = new Group();
    lo.position.y = -(l1 + r1);
    up.add(lo);
    const b = cap2(r2, l2, m);
    b.position.y = -(l2 / 2 + r2 * 0.5);
    lo.add(b);
    end.position.y += -(l2 + r2);
    end.castShadow = true;
    lo.add(end);
    return { up, lo };
  };
  const hand = () => new Mesh(new SphereGeometry(0.05, 10, 10), skin);
  const foot = () => {
    const fg = new Group();
    const upper = new Mesh(new BoxGeometry(0.105, 0.06, 0.25), shoe);
    upper.position.set(0, -0.01, 0.06);
    upper.castShadow = true;
    const s = new Mesh(new BoxGeometry(0.11, 0.022, 0.26), sole);
    s.position.set(0, -0.045, 0.06);
    fg.add(upper, s);
    return fg;
  };
  const aL = limb(torso, 0.255, 0.5, 0.052, 0.22, 0.044, 0.2, jacket, hand()),
    aR = limb(torso, -0.255, 0.5, 0.052, 0.22, 0.044, 0.2, jacket, hand());
  const lL = limb(hips, 0.1, -0.02, 0.076, 0.33, 0.062, 0.33, jeans, foot()),
    lR = limb(hips, -0.1, -0.02, 0.076, 0.33, 0.062, 0.33, jeans, foot());
  aL.up.rotation.z = 0.07;
  aR.up.rotation.z = -0.07;

  const pose = (ph: number, amt: number, run: number, t: number) => {
    const s = Math.sin(ph),
      c = Math.cos(ph),
      A = (0.5 + 0.4 * run) * amt,
      K = (0.95 + 0.5 * run) * amt,
      idle = 1 - amt;
    lL.up.rotation.x = -s * A;
    lR.up.rotation.x = s * A;
    lL.lo.rotation.x = Math.max(0, c) * K + 0.04;
    lR.lo.rotation.x = Math.max(0, -c) * K + 0.04;
    aL.up.rotation.x = s * A * 0.85;
    aR.up.rotation.x = -s * A * 0.85;
    const el = -(0.18 + 0.75 * run * amt + 0.2 * amt);
    aL.lo.rotation.x = el;
    aR.lo.rotation.x = el;
    body.position.y = (Math.abs(s) - 0.6) * 0.035 * amt + Math.sin(t * 1.7) * 0.004 * idle;
    torso.rotation.x = (0.05 + 0.16 * run) * amt;
    torso.rotation.y = s * 0.13 * amt;
    hips.rotation.y = -s * 0.06 * amt;
    head.rotation.y = -s * 0.1 * amt + Math.sin(t * 0.45) * 0.22 * idle;
    chest.scale.z = 0.82 + Math.sin(t * 1.7) * 0.012;
  };
  const ride = (ph: number) => {
    const s = Math.sin(ph),
      c = Math.cos(ph);
    lL.up.rotation.x = -1.05 + s * 0.42;
    lR.up.rotation.x = -1.05 - s * 0.42;
    lL.lo.rotation.x = 1.25 + c * 0.4;
    lR.lo.rotation.x = 1.25 - c * 0.4;
    aL.up.rotation.x = -1;
    aR.up.rotation.x = -1;
    aL.lo.rotation.x = -0.35;
    aR.lo.rotation.x = -0.35;
    torso.rotation.x = 0.42;
    torso.rotation.y = 0;
    hips.rotation.y = 0;
    head.rotation.y = 0;
    body.position.y = 0;
  };
  return {
    g,
    pose,
    ride,
    weaponHand: aR.lo,
    aim() { aR.up.rotation.x = -1.35; aR.lo.rotation.x = -0.25; },
    setJacket(c2: string) {
      jacket.color.set(c2);
    },
  };
}

const PROF: Record<string, number[]> = {
  sport: [-2.12, 0.3, -2.18, 0.58, -2, 0.86, -1.55, 0.92, -0.95, 1.22, 0.25, 1.24, 1, 0.9, 1.95, 0.78, 2.18, 0.56, 2.12, 0.3],
  hatch: [-1.95, 0.32, -2, 0.62, -1.9, 1, -1.6, 1.42, 0.35, 1.44, 1, 0.98, 1.8, 0.84, 2, 0.6, 1.95, 0.32],
  suv: [-2.2, 0.42, -2.26, 0.8, -2.15, 1.2, -1.9, 1.72, 0.5, 1.74, 1.15, 1.22, 2.05, 1.08, 2.26, 0.78, 2.2, 0.42],
  van: [-2.3, 0.34, -2.36, 0.7, -2.3, 1.9, -2.1, 2, 1, 2, 1.6, 1.35, 2.25, 1.05, 2.4, 0.7, 2.34, 0.34],
};

const GLASS: Record<string, number[]> = {
  sport: [-1.511, 0.962, -1.019, 1.208, 0.333, 1.224, 0.948, 0.945],
  hatch: [-1.892, 1.046, -1.646, 1.39, 0.427, 1.41, 0.96, 1.033],
  suv: [-2.148, 1.251, -1.943, 1.677, 0.578, 1.704, 1.11, 1.277],
  van: [0.2, 1.416, 0.2, 1.949, 1.075, 1.949, 1.567, 1.416],
};

const DIM: Record<string, [number, number, number]> = {
  sport: [1.84, 0.33, 2.7],
  hatch: [1.78, 0.31, 2.5],
  suv: [1.92, 0.38, 2.75],
  van: [1.98, 0.36, 3.1],
};

function extrude(pts: number[], width: number, bev: number): BufferGeometry {
  const sh = new Shape();
  sh.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) sh.lineTo(pts[i], pts[i + 1]);
  sh.closePath();
  const depth = width - 2 * bev;
  const g = new ExtrudeGeometry(
    sh,
    bev > 0
      ? {
          depth,
          bevelEnabled: true,
          bevelThickness: bev,
          bevelSize: bev,
          bevelOffset: -bev,
          bevelSegments: 3,
          steps: 1,
        }
      : { depth, bevelEnabled: false, steps: 1 }
  );
  g.rotateY(-Math.PI / 2);
  g.translate(depth / 2, 0, 0);
  return g;
}

export function buildCar(color: string, accent: string, type: string, bar = false): Group {
  const ty = PROF[type] ? type : "hatch",
    dim = DIM[ty],
    W = dim[0],
    R = dim[1],
    wb = dim[2],
    P = PROF[ty],
    n = P.length,
    g = new Group();
  const paint = new MeshPhysicalMaterial({
    color,
    metalness: 0.62,
    roughness: 0.28,
    clearcoat: 1,
    clearcoatRoughness: 0.05,
  });
  const glass = new MeshPhysicalMaterial({
    color: "#0e151e",
    metalness: 0.9,
    roughness: 0.04,
    clearcoat: 1,
  });
  const dark = new MeshStandardMaterial({ color: "#0c0e12", roughness: 0.82 }),
    rimM = new MeshStandardMaterial({ color: "#cbd1d8", metalness: 0.88, roughness: 0.22 }),
    trim = new MeshStandardMaterial({ color: accent, roughness: 0.45, metalness: 0.35 }),
    plateM = new MeshStandardMaterial({ color: "#f4f4f0", roughness: 0.5 });

  const body = new Mesh(extrude(P, W, 0.1), paint);
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);
  g.add(new Mesh(extrude(GLASS[ty], W + 0.032, 0), glass));

  const skirt = new Mesh(new BoxGeometry(W - 0.08, 0.16, wb + 1.05), trim);
  skirt.position.set(0, P[1] + 0.02, 0);
  g.add(skirt);

  // Front radiator grille & bumpers + Polish KCH license plates
  const grille = new Mesh(new BoxGeometry(W * 0.52, 0.2, 0.06), dark);
  grille.position.set(0, P[n - 3] + 0.06, P[n - 4] - 0.01);
  g.add(grille);
  const fPlate = new Mesh(new BoxGeometry(0.46, 0.1, 0.04), plateM);
  fPlate.position.set(0, P[n - 3] - 0.08, P[n - 4] + 0.01);
  g.add(fPlate);
  const rPlate = new Mesh(new BoxGeometry(0.46, 0.1, 0.04), plateM);
  rPlate.position.set(0, P[3] + 0.02, P[2] - 0.02);
  g.add(rPlate);

  // Side mirrors
  for (const sx of [-1, 1]) {
    const mir = new Mesh(new BoxGeometry(0.16, 0.1, 0.12), paint);
    mir.position.set(sx * (W / 2 + 0.06), GLASS[ty][1] - 0.02, 0.62);
    g.add(mir);
  }

  const tire = new CylinderGeometry(R, R, 0.24, 24);
  tire.rotateZ(Math.PI / 2);
  const rim = new CylinderGeometry(R * 0.64, R * 0.64, 0.25, 16);
  rim.rotateZ(Math.PI / 2);
  const arch2 = new CircleGeometry(R + 0.075, 22),
    wheels: Group[] = [];
  for (const p of [
    [1, 1],
    [-1, 1],
    [1, -1],
    [-1, -1],
  ]) {
    const w = new Group();
    w.position.set(p[0] * (W / 2 - 0.07), R, (p[1] * wb) / 2);
    w.rotation.order = "YXZ";
    const t = new Mesh(tire, dark);
    t.castShadow = true;
    w.add(t);
    w.add(new Mesh(rim, rimM));
    g.add(w);
    wheels.push(w);
    const a = new Mesh(arch2, dark);
    a.position.set(p[0] * (W / 2 + 0.004), R + 0.02, (p[1] * wb) / 2);
    a.rotation.y = (p[0] * Math.PI) / 2;
    g.add(a);
  }

  const hl = new MeshStandardMaterial({ color: "#fff8e2", emissive: "#ffe9b0", emissiveIntensity: 0.85 }),
    tl = new MeshStandardMaterial({ color: "#c0120c", emissive: "#ff2212", emissiveIntensity: 0.7 });
  for (const sx of [-1, 1]) {
    const a = new Mesh(new BoxGeometry(0.4, 0.13, 0.06), hl);
    a.position.set(sx * (W / 2 - 0.34), P[n - 3] + 0.17, P[n - 4] - 0.03);
    g.add(a);
    const b = new Mesh(new BoxGeometry(0.38, 0.12, 0.06), tl);
    b.position.set(sx * (W / 2 - 0.33), P[3] + 0.2, P[2] + 0.04);
    g.add(b);
  }
  if (bar) {
    let top = 0;
    for (let i = 1; i < n; i += 2) top = Math.max(top, P[i]);
    const lb = new Mesh(
      new BoxGeometry(1.1, 0.12, 0.3),
      new MeshStandardMaterial({ color: "#2a62ff", emissive: "#2a62ff", emissiveIntensity: 0.9 })
    );
    lb.position.set(0, top + 0.07, -0.2);
    g.add(lb);
  }
  g.userData.wheels = wheels;
  g.userData.wr = R;
  g.userData.wb = wb;
  return g;
}

export function buildBike(color: string): Group {
  const g = new Group();
  const fm = new MeshStandardMaterial({ color, roughness: 0.35, metalness: 0.6 }),
    dk = new MeshStandardMaterial({ color: "#15171a", roughness: 0.8 }),
    sp = new MeshStandardMaterial({ color: "#b9bec4", roughness: 0.35, metalness: 0.75 });
  for (const z of [0.55, -0.55]) {
    const w = new Mesh(new TorusGeometry(0.33, 0.032, 8, 24), dk);
    w.rotation.y = Math.PI / 2;
    w.position.set(0, 0.36, z);
    w.castShadow = true;
    g.add(w);
    for (let k = 0; k < 6; k++) {
      const s = new Mesh(new CylinderGeometry(0.006, 0.006, 0.64, 4), sp);
      s.position.set(0, 0.36, z);
      s.rotation.x = (k * Math.PI) / 6;
      g.add(s);
    }
  }
  const up = new Vector3(0, 1, 0);
  const tube = (x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, r: number, m: MeshStandardMaterial) => {
    const a = new Vector3(x1, y1, z1),
      b = new Vector3(x2, y2, z2),
      t = new Mesh(new CylinderGeometry(r, r, a.distanceTo(b), 8), m);
    t.position.copy(a).add(b).multiplyScalar(0.5);
    t.quaternion.setFromUnitVectors(up, b.clone().sub(a).normalize());
    t.castShadow = true;
    g.add(t);
  };
  tube(0, 0.36, -0.55, 0, 0.62, -0.1, 0.025, fm);
  tube(0, 0.62, -0.1, 0, 0.95, 0.35, 0.03, fm);
  tube(0, 0.95, -0.2, 0, 0.95, 0.35, 0.025, fm);
  tube(0, 0.62, -0.1, 0, 0.98, -0.22, 0.025, fm);
  tube(0, 0.36, -0.55, 0, 0.95, -0.2, 0.02, fm);
  tube(0, 0.36, 0.55, 0, 1.05, 0.33, 0.025, fm);
  tube(-0.25, 1.06, 0.33, 0.25, 1.06, 0.33, 0.02, dk);
  const saddle = new Mesh(new BoxGeometry(0.16, 0.05, 0.28), dk);
  saddle.position.set(0, 1, -0.24);
  g.add(saddle);
  g.userData.wheels = [];
  g.userData.wr = 0.36;
  g.userData.wb = 1.1;
  return g;
}
