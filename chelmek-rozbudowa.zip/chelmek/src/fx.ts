import {
  BufferAttribute,
  BufferGeometry,
  Color,
   DataTexture,
  DoubleSide,
  Float32BufferAttribute,
  Group,
  InstancedMesh,
  Matrix4,
  Mesh,
  MeshLambertMaterial,
  PlaneGeometry,
  Points,
  Quaternion,
  ShaderMaterial,
  Vector2,
  Vector3,
  Vector4,
} from "three";
import { U } from "./env";
import { hash01 } from "./geo";
import { Terrain } from "./terrain";

function tuft(blades: number, w: number): BufferGeometry {
  const pos: number[] = [],
    col2: number[] = [],
    nor: number[] = [],
    idx: number[] = [];
  const root = [0.06, 0.18, 0.04],
    tip = [0.34, 0.54, 0.14],
    pts = [
      [-w, 0],
      [w, 0],
      [-w * 0.6, 0.5],
      [w * 0.6, 0.5],
      [0, 1],
    ];
  for (let b = 0; b < blades; b++) {
    const a = (b / blades) * Math.PI + 0.3,
      cx = Math.cos(a),
      sz = Math.sin(a),
      ox = (hash01(b, 1) - 0.5) * 0.16,
      oz = (hash01(b, 2) - 0.5) * 0.16,
      lean = (hash01(b, 3) - 0.5) * 0.32,
      o = pos.length / 3;
    for (const p of pts) {
      const yy = p[1];
      pos.push(ox + cx * p[0] + lean * yy * yy * sz, yy, oz + sz * p[0] - lean * yy * yy * cx);
      nor.push(0, 1, 0);
      col2.push(
        root[0] + (tip[0] - root[0]) * yy,
        root[1] + (tip[1] - root[1]) * yy,
        root[2] + (tip[2] - root[2]) * yy
      );
    }
    idx.push(o, o + 1, o + 2, o + 1, o + 3, o + 2, o + 2, o + 3, o + 4);
  }
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new Float32BufferAttribute(nor, 3));
  g.setAttribute("color", new Float32BufferAttribute(col2, 3));
  g.setIndex(idx);
  return g;
}

function flower(): BufferGeometry {
  const pos = [-0.08, 0, 0, 0.08, 0, 0, 0, 1, 0, 0, 1.02, 0],
    col2 = [0.08, 0.25, 0.06, 0.08, 0.25, 0.06, 0.1, 0.3, 0.08, 1, 0.9, 0.3],
    nor = [0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],
    idx = [0, 1, 2];
  for (let k = 0; k < 6; k++) {
    const a = (k / 6) * 6.2832;
    pos.push(Math.cos(a) * 0.5, 1 + 0.06 * Math.sin(a * 2), Math.sin(a) * 0.5);
    col2.push(1, 1, 1);
    nor.push(0, 1, 0);
  }
  for (let k = 0; k < 6; k++) idx.push(3, 4 + k, 4 + ((k + 1) % 6));
  const g = new BufferGeometry();
  g.setAttribute("position", new Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new Float32BufferAttribute(nor, 3));
  g.setAttribute("color", new Float32BufferAttribute(col2, 3));
  g.setIndex(idx);
  return g;
}

function wrapPatch(m: MeshLambertMaterial, un: any, bend: number, minMask: number) {
  m.onBeforeCompile = (sh) => {
    Object.assign(sh.uniforms, un);
    sh.vertexShader = sh.vertexShader
      .replace(
        "#include <common>",
        `#include <common>
uniform vec3 uCam;
uniform float uSize;
uniform float uTime;
uniform float uWind;
uniform sampler2D uGround;
uniform sampler2D uHeight;
uniform vec4 uGO;
uniform vec4 uHO;
uniform vec2 uHN;`
      )
      .replace(
        "#include <project_vertex>",
        `vec4 gp = instanceMatrix * vec4( transformed, 1.0 );
vec2 gB = instanceMatrix[3].xz;
vec2 gW = mod( gB - uCam.xz, uSize ) - 0.5 * uSize + uCam.xz;
float gM = texture2D( uGround, ( gW - uGO.xy ) * uGO.zw ).a;
float gD = length( gW - uCam.xz ) / ( 0.5 * uSize );
float gS = smoothstep( ${minMask.toFixed(2)}, ${(minMask + 0.2).toFixed(2)}, gM ) * ( 1.0 - smoothstep( 0.72, 0.98, gD ) );
vec3 gL = ( gp.xyz - vec3( gB.x, 0.0, gB.y ) ) * gS;
float gH = texture2D( uHeight, ( ( gW - uHO.xy ) * uHO.z + 0.5 ) * uHN ).r + uHO.w;
float gP = uTime * 1.6 + gW.x * 0.35 + gW.y * 0.27;
float gK = position.y * position.y * uWind * ${bend.toFixed(2)} * gS;
gL.x += ( sin( gP ) * 0.12 + sin( gP * 2.3 + gW.y ) * 0.05 ) * gK;
gL.z += cos( gP * 0.9 ) * 0.09 * gK;
gp = vec4( gW.x + gL.x, gH + gL.y, gW.y + gL.z, 1.0 );
vec4 mvPosition = viewMatrix * gp;
gl_Position = projectionMatrix * mvPosition;`
      )
      .replace("#include <worldpos_vertex>", `vec4 worldPosition = gp;`);
    sh.fragmentShader = sh.fragmentShader.replace(
      "#include <normal_fragment_begin>",
      `#include <normal_fragment_begin>
normal = normalize( vNormal ); nonPerturbedNormal = normal;`
    );
  };
  m.customProgramCacheKey = () => "wrap" + bend + "_" + minMask;
}

function field(
  geo: BufferGeometry,
  mat: MeshLambertMaterial,
  n: number,
  size: number,
  seed: number,
  sx0: number,
  sx1: number,
  sy0: number,
  sy1: number,
  pal: number[][]
): InstancedMesh {
  const im = new InstancedMesh(geo, mat, n),
    m4 = new Matrix4(),
    q = new Quaternion(),
    p = new Vector3(),
    s = new Vector3(),
    up = new Vector3(0, 1, 0),
    c = new Color();
  for (let i = 0; i < n; i++) {
    p.set(hash01(i, seed, 1) * size, 0, hash01(i, seed, 2) * size);
    q.setFromAxisAngle(up, hash01(i, seed, 3) * 6.283);
    const a = sx0 + (sx1 - sx0) * hash01(i, seed, 4);
    s.set(a, sy0 + (sy1 - sy0) * hash01(i, seed, 5), a);
    m4.compose(p, q, s);
    im.setMatrixAt(i, m4);
    const pc = pal[(hash01(i, seed, 6) * pal.length) | 0];
    c.setRGB(pc[0], pc[1], pc[2]);
    im.setColorAt(i, c);
  }
  im.frustumCulled = false;
  im.castShadow = false;
  im.receiveShadow = true;
  return im;
}

export function buildFx(t: Terrain, ground: DataTexture, height: DataTexture, q: any) {
  const group = new Group();
  const un = {
    uCam: { value: new Vector3() },
    uSize: { value: q.gsize },
    uTime: U.time,
    uWind: U.wind,
    uGround: { value: ground },
    uHeight: { value: height },
    uGO: { value: new Vector4(t.x0, t.z0, 1 / (t.mw * t.mc), 1 / (t.mh * t.mc)) },
    uHO: { value: new Vector4(t.x0, t.z0, 1 / t.cell, t.hBase) },
    uHN: { value: new Vector2(1 / t.nx, 1 / t.nz) },
  };
  const gm = new MeshLambertMaterial({ vertexColors: true, side: DoubleSide });
  wrapPatch(gm, un, 1, 0.35);
  group.add(
    field(tuft(4, 0.52), gm, q.grass, q.gsize, 11, 0.07, 0.13, 0.32, 0.78, [
      [1, 1, 1],
      [1.15, 1.1, 0.8],
      [0.85, 1, 0.85],
      [1.25, 1.15, 0.7],
      [0.9, 0.95, 0.9],
    ])
  );
  const fm = new MeshLambertMaterial({ vertexColors: true, side: DoubleSide });
  wrapPatch(fm, un, 0.6, 0.78);
  group.add(
    field(flower(), fm, q.flowers, q.gsize, 23, 0.09, 0.14, 0.25, 0.5, [
      [1, 1, 1],
      [1, 0.85, 0.15],
      [0.62, 0.4, 0.9],
      [0.95, 0.2, 0.15],
      [1, 0.6, 0.75],
      [0.45, 0.6, 1],
    ])
  );

  const seed = new Float32Array(q.parts * 4);
  for (let i = 0; i < seed.length; i++) seed[i] = hash01(i, 77, 5);
  const pg = new BufferGeometry();
  pg.setAttribute("position", new BufferAttribute(new Float32Array(q.parts * 3), 3));
  pg.setAttribute("aSeed", new BufferAttribute(seed, 4));
  const pu = {
    uCam: un.uCam,
    uTime: U.time,
    uBox: { value: new Vector3(50, 16, 50) },
    uMix: { value: new Vector3(0, 1, 0) },
    uScale: { value: 600 },
    uTint: { value: new Vector3(1, 1, 1) },
  };
  const pmat = new ShaderMaterial({
    uniforms: pu,
    transparent: true,
    depthWrite: false,
    vertexShader: `attribute vec4 aSeed;
uniform vec3 uCam; uniform float uTime; uniform vec3 uBox; uniform vec3 uMix; uniform float uScale; uniform vec3 uTint;
varying vec3 vCol; varying float vA;
void main() {
  float kind = aSeed.w;
  vec3 vel = kind < 0.4 ? vec3( 0.6, -0.9, 0.3 ) : kind < 0.75 ? vec3( 0.5, 0.12, 0.2 ) : vec3( 0.25, 0.03, 0.1 );
  vec3 p = aSeed.xyz * uBox + vel * uTime + vec3( sin( uTime * 0.7 + aSeed.x * 40.0 ), 0.0, cos( uTime * 0.6 + aSeed.z * 40.0 ) ) * 0.8;
  p = mod( p - uCam, uBox ) - 0.5 * uBox + uCam;
  float w = kind < 0.4 ? uMix.x : kind < 0.75 ? uMix.y : uMix.z;
  vCol = ( kind < 0.4 ? mix( vec3( 0.85, 0.55, 0.15 ), vec3( 0.55, 0.65, 0.2 ), fract( aSeed.x * 7.0 ) ) : kind < 0.75 ? vec3( 1.0, 0.96, 0.84 ) : vec3( 0.85, 0.78, 0.65 ) ) * uTint;
  vec4 mv = viewMatrix * vec4( p, 1.0 );
  float d = - mv.z;
  vA = w * smoothstep( 0.5 * uBox.x, 0.35 * uBox.x, d ) * smoothstep( 0.3, 1.5, d ) * ( kind < 0.4 ? 0.95 : kind < 0.75 ? 0.7 : 0.35 );
  gl_PointSize = ( kind < 0.4 ? 0.09 : 0.04 ) * uScale / max( d, 0.1 );
  gl_Position = projectionMatrix * mv;
}`,
    fragmentShader: `varying vec3 vCol; varying float vA;
void main() {
  float r = length( gl_PointCoord - 0.5 );
  if ( r > 0.5 ) discard;
  gl_FragColor = vec4( vCol, vA * smoothstep( 0.5, 0.18, r ) );
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`,
  });
  const pts = new Points(pg, pmat);
  pts.frustumCulled = false;
  group.add(pts);

  const cu = {
    uCam: un.uCam,
    uTime: U.time,
    uCol: { value: new Vector3(2.1, 2.1, 2.15) },
    uCover: { value: 0.64 },
  };
  const cmat = new ShaderMaterial({
    uniforms: cu,
    transparent: true,
    depthWrite: false,
    side: DoubleSide,
    vertexShader: `uniform vec3 uCam;
varying vec2 vW;
void main() {
  vec3 p = vec3( uCam.x + position.x * 16000.0, uCam.y + 900.0, uCam.z + position.y * 16000.0 );
  vW = p.xz;
  gl_Position = projectionMatrix * viewMatrix * vec4( p, 1.0 );
  gl_Position.z = gl_Position.w * 0.9999;
}`,
    fragmentShader: `uniform vec3 uCam; uniform float uTime; uniform vec3 uCol; uniform float uCover;
varying vec2 vW;
float h( vec2 p ) { return fract( sin( dot( p, vec2( 127.1, 311.7 ) ) ) * 43758.5453 ); }
float n( vec2 p ) { vec2 i = floor( p ), f = fract( p ); f = f * f * ( 3.0 - 2.0 * f ); return mix( mix( h( i ), h( i + vec2( 1.0, 0.0 ) ), f.x ), mix( h( i + vec2( 0.0, 1.0 ) ), h( i + vec2( 1.0, 1.0 ) ), f.x ), f.y ); }
float fbm( vec2 p ) { float a = 0.5, s = 0.0; for ( int i = 0; i < 5; i ++ ) { s += a * n( p ); p = p * 2.03 + 17.0; a *= 0.5; } return s; }
void main() {
  vec2 p = vW * 0.00042 + vec2( uTime * 0.006, uTime * 0.0025 );
  float d = fbm( p ) + 0.25 * fbm( p * 3.1 + 5.0 );
  float c = smoothstep( uCover, uCover + 0.28, d );
  float fade = 1.0 - smoothstep( 5000.0, 15000.0, length( vW - uCam.xz ) );
  vec3 col = uCol * mix( 1.05, 0.68, smoothstep( uCover + 0.04, uCover + 0.52, d ) );
  gl_FragColor = vec4( col, c * fade * 0.92 );
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`,
  });
  const clouds = new Mesh(new PlaneGeometry(2, 2), cmat);
  clouds.frustumCulled = false;
  clouds.renderOrder = -10;
  group.add(clouds);

  const mixNow = new Vector3(0, 1, 0);
  return {
    group,
    update(cam: Vector3, mix: number[], hpx: number) {
      un.uCam.value.copy(cam);
      mixNow.x += (mix[0] - mixNow.x) * 0.03;
      mixNow.y += (mix[1] - mixNow.y) * 0.03;
      mixNow.z += (mix[2] - mixNow.z) * 0.03;
      pu.uMix.value.copy(mixNow);
      pu.uScale.value = hpx * 0.866;
    },
    setLight(c: number[]) {
      cu.uCol.value.set(c[0], c[1], c[2]);
      const k = Math.min(1, (c[0] + c[1] + c[2]) / 6.3);
      pu.uTint.value.set(0.25 + 0.75 * k, 0.25 + 0.75 * k, 0.3 + 0.7 * k);
    },
  };
}
